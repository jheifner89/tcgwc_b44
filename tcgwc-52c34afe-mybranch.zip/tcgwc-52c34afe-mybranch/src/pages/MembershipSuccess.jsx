
import React, { useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function MembershipSuccess() {
  useEffect(() => {
    // You could add logic here to verify the payment with Stripe if needed
    // This is a trigger for redeployment.
  }, []);

  return (
    <div className="bg-gradient-to-b from-slate-50 to-slate-100 min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <Card className="bg-white rounded-2xl shadow-xl border-0 max-w-lg w-full">
        <CardHeader className="p-8 text-center">
          <div className="w-16 h-16 bg-green-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
          <CardTitle className="text-3xl font-extrabold text-slate-900">
            Welcome to the Club!
          </CardTitle>
        </CardHeader>
        <CardContent className="p-8 pt-0 text-center">
          <p className="text-lg text-slate-600 mb-6">
            Your membership has been activated successfully. You now have full access to our distributor catalog.
          </p>
          <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
            <p className="text-green-800 text-sm">
              🎉 <strong>Congratulations!</strong> You can now browse products, make requests, and place orders.
            </p>
          </div>
          <Link to={createPageUrl("Dashboard")}>
            <Button className="w-full h-12 rounded-xl bg-slate-900 hover:bg-slate-800 text-lg font-semibold">
              Go to Dashboard
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
