
import React, { useState, useEffect, useCallback } from "react";
import { useUser } from "@/layout";
import { Request } from "@/api/entities";
import { Invoice } from "@/api/entities";
import { Order } from "@/api/entities";
import { Product } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  ClipboardList,
  Receipt,
  Package,
  DollarSign,
  TrendingUp,
  Clock,
  ArrowRight,
} from "lucide-react";
import MessageCenter from "@/components/messages/MessageCenter";
import { toast } from "sonner";

export default function Dashboard() {
  const { user, loading: userLoading } = useUser();
  const [stats, setStats] = useState({
    pendingRequests: 0,
    unpaidInvoices: 0,
    activeOrders: 0,
    accountCredit: 0
  });
  const [spendHistory, setSpendHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadDashboardData = useCallback(async () => {
    if (!user) return; // Ensure user is available before proceeding
    setLoading(true); // Always set loading to true when starting
    try {
      // User data is now obtained from the useUser hook, no need to fetch User.me()
      const [requests, invoices, orders] = await Promise.all([
        Request.filter({ member_id: user.id }),
        Invoice.filter({ member_id: user.id }),
        Order.filter({ member_id: user.id })
      ]);

      setStats({
        pendingRequests: requests.filter(r => r.status === 'pending').length,
        unpaidInvoices: invoices.filter(i => ['issued', 'overdue'].includes(i.status)).length,
        activeOrders: orders.filter(o => !['In Inventory', 'Cancelled'].includes(o.status)).length,
        accountCredit: user.account_credit || 0
      });

      await loadSpendHistory(user.id, orders);
    } catch (error) {
      console.error("Error loading dashboard:", error);
    } finally {
      setLoading(false);
    }
  }, [user]); // Only depend on 'user', not 'loading'

  useEffect(() => {
    if (user) {
      loadDashboardData();
    } else if (!userLoading) {
      // If user data has finished loading and no user is found (e.g., not logged in),
      // set overall loading to false to display the dashboard content (e.g., login prompt or empty state)
      setLoading(false);
    }
  }, [user, userLoading, loadDashboardData]);

  const loadSpendHistory = async (userId, orders) => {
    try {
      // Calculate 180-day period: from end of today back 180 days
      const todayEnd = new Date();
      todayEnd.setUTCHours(23, 59, 59, 999); // End of today in UTC
      
      const oneEightyDaysAgoEnd = new Date(todayEnd);
      oneEightyDaysAgoEnd.setUTCDate(oneEightyDaysAgoEnd.getUTCDate() - 180);
      oneEightyDaysAgoEnd.setUTCHours(23, 59, 59, 999); // End of that day in UTC
      
      const startDate = oneEightyDaysAgoEnd.toISOString().split('T')[0];
      const endDate = todayEnd.toISOString().split('T')[0];

      const excludedStatuses = ['Cancelled'];

      // Filter for orders that are within the 180-day window (not cancelled)
      const activeSpendOrders = orders.filter(order => {
        if (!order.order_date || excludedStatuses.includes(order.status)) {
          return false;
        }
        
        // Include orders from startDate through endDate (inclusive)
        return order.order_date >= startDate && order.order_date <= endDate;
      });
      
      if (activeSpendOrders.length === 0) {
        setSpendHistory([]);
        return;
      }

      // Get unique product IDs to fetch product details
      const productIds = [...new Set(activeSpendOrders.map(order => order.product_id))];

      // Fetch product details to get product lines
      const products = await Promise.all(
        productIds.map(async (productId) => {
          try {
            return await Product.get(productId);
          } catch (error) {
            console.warn(`Could not fetch product ${productId}:`, error);
            return null;
          }
        })
      );

      // Create a lookup map for product lines
      const productLineMap = {};
      products.forEach(product => {
        if (product) {
          productLineMap[product.id] = product.product_line || 'Uncategorized';
        }
      });

      // Calculate drop-off boundary (30 days from now - these orders will expire soon)
      const thirtyDaysFromNow = new Date();
      thirtyDaysFromNow.setUTCDate(thirtyDaysFromNow.getUTCDate() + 30);
      thirtyDaysFromNow.setUTCHours(23, 59, 59, 999);
      const dropOffDate = thirtyDaysFromNow.toISOString().split('T')[0];

      // Group orders by product line and calculate spend + drop-off amounts
      const spendByLine = {};
      activeSpendOrders.forEach(order => {
        const productLine = productLineMap[order.product_id] || 'Uncategorized';
        
        // Calculate when this order's spend will expire (180 days from order date)
        const orderDate = new Date(order.order_date + 'T23:59:59.999Z');
        const expirationDate = new Date(orderDate);
        expirationDate.setUTCDate(expirationDate.getUTCDate() + 180);
        const expirationDateString = expirationDate.toISOString().split('T')[0];

        if (!spendByLine[productLine]) {
          spendByLine[productLine] = {
            totalSpend: 0,
            droppingOff: 0
          };
        }

        spendByLine[productLine].totalSpend += order.total_price;

        // If expiration date is within the next 30 days, it's dropping off
        if (expirationDateString <= dropOffDate) {
          spendByLine[productLine].droppingOff += order.total_price;
        }
      });

      // Convert to array and sort by spending amount
      const spendArray = Object.entries(spendByLine)
        .map(([productLine, data]) => ({
          productLine,
          totalSpend: data.totalSpend,
          droppingOff: data.droppingOff,
          remaining: data.totalSpend - data.droppingOff
        }))
        .sort((a, b) => b.totalSpend - a.totalSpend);
      
      setSpendHistory(spendArray);
    } catch (error) {
      console.error("Error calculating spend history:", error);
      setSpendHistory([]);
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      pending: "bg-yellow-100 text-yellow-800",
      requested: "bg-blue-100 text-blue-800",
      active: "bg-green-100 text-green-800",
      paid: "bg-green-100 text-green-800",
      shipped: "bg-blue-100 text-blue-800",
      delivered: "bg-green-100 text-green-800",
      issued: "bg-red-100 text-red-800",
      overdue: "bg-red-200 text-red-900"
    };
    return colors[status] || "bg-gray-100 text-gray-800";
  };

  if (loading || userLoading) { // Also show loading if user is still being fetched
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-64"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-200 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // If loading is false but no user is available, it means the user is not logged in.
  // In a real application, you might redirect to a login page or show a "Please log in" message.
  if (!user && !userLoading) {
    return (
      <div className="p-8 text-center text-slate-600">
        <h1 className="text-2xl font-bold mb-4">Access Denied</h1>
        <p>Please log in to view the dashboard.</p>
        <Link to={createPageUrl("login")}>
          <Button className="mt-4">Go to Login</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="p-6 md:p-8 min-h-full">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-slate-900 mb-2">
                Welcome back, {user?.full_name?.split(' ')[0]}
              </h1>
              <p className="text-slate-600">
                Here's what's happening with your trading card distribution account.
              </p>
            </div>
            <div className="flex items-center gap-4">
              {user && <MessageCenter userId={user.id} />}
            </div>
          </div>
        </div>

        {/* Membership Status Alert */}
        {user?.membership_status !== 'active' && user?.role !== 'admin' && (
          <div className="mb-8 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Clock className="w-5 h-5 text-blue-600" />
                <div>
                  <h3 className="font-medium text-blue-900">Activate Your Membership</h3>
                  <p className="text-blue-700 text-sm">
                    Choose a plan to get full access to our product catalog and start ordering.
                  </p>
                </div>
              </div>
              <Link to={createPageUrl("Membership")}>
                <Button variant="outline" className="bg-white hover:bg-slate-50 border-blue-200">
                  Choose Plan <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </div>
          </div>
        )}

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-white border-0 shadow-sm hover:shadow-md transition-shadow duration-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500 mb-1">Pending Requests</p>
                  <p className="text-2xl font-bold text-slate-900">{stats.pendingRequests}</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                  <ClipboardList className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white border-0 shadow-sm hover:shadow-md transition-shadow duration-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500 mb-1">Unpaid Invoices</p>
                  <p className="text-2xl font-bold text-slate-900">{stats.unpaidInvoices}</p>
                </div>
                <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center">
                  <Receipt className="w-6 h-6 text-red-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white border-0 shadow-sm hover:shadow-md transition-shadow duration-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500 mb-1">Active Orders</p>
                  <p className="text-2xl font-bold text-slate-900">{stats.activeOrders}</p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                  <Package className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white border-0 shadow-sm hover:shadow-md transition-shadow duration-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500 mb-1">Account Credit</p>
                  <p className="text-2xl font-bold text-slate-900">${stats.accountCredit.toFixed(2)}</p>
                </div>
                <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-emerald-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Spend History */}
        <div className="grid lg:grid-cols-1 gap-8">
          <Card className="bg-white border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="text-xl font-semibold text-slate-900">Spend History</CardTitle>
              <p className="text-sm text-slate-600">Your spending by product line (upcoming expirations)</p>
            </CardHeader>
            <CardContent>
              {spendHistory.length > 0 ? (
                <div className="space-y-6">
                  {spendHistory.map((item, index) => {
                    const maxSpend = Math.max(...spendHistory.map(s => s.totalSpend));
                    const totalPercentage = maxSpend > 0 ? (item.totalSpend / maxSpend) * 100 : 0;
                    const droppingOffPercentage = maxSpend > 0 ? (item.droppingOff / maxSpend) * 100 : 0;
                    const remainingPercentage = totalPercentage - droppingOffPercentage;

                    return (
                      <div key={index} className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium text-slate-700">{item.productLine}</span>
                          <div className="text-right">
                            <span className="text-sm font-bold text-slate-900">${item.totalSpend.toFixed(2)}</span>
                            {item.droppingOff > 0 && (
                              <div className="text-xs text-slate-500">
                                ${item.droppingOff.toFixed(2)} expiring soon
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="relative w-full bg-slate-100 rounded-full h-3">
                          {/* Remaining spend (will continue) */}
                          <div
                            className="bg-slate-600 h-3 rounded-l-full transition-all duration-300"
                            style={{ width: `${remainingPercentage}%` }}
                          ></div>
                          {/* Dropping off spend (overlay) */}
                          {item.droppingOff > 0 && (
                            <div
                              className="bg-red-200 h-3 rounded-r-full absolute top-0 transition-all duration-300"
                              style={{
                                left: `${remainingPercentage}%`,
                                width: `${droppingOffPercentage}%`
                              }}
                            ></div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-8">
                  <TrendingUp className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-500">No spending data</p>
                  <p className="text-sm text-slate-400">Your spending history will appear once you place orders</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
