
import React, { useState, useEffect, useCallback } from "react";
import { Shipment } from "@/api/entities";
import { ShipmentItem } from "@/api/entities";
import { useUser } from "@/layout"; // Use the user hook
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Loader2, Truck, FileDown, Package } from "lucide-react"; // Updated lucide-react imports
import { toast } from "sonner";
import ShipmentDetailsModal from "@/components/shipments/ShipmentDetailsModal";
import PaginationControls from "@/components/ui/PaginationControls";
import { downloadPackingSlipPdf } from "@/api/functions";

export default function MyShipments() {
  const { user, loading: userLoading } = useUser(); // Use useUser hook
  const [shipments, setShipments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedShipment, setSelectedShipment] = useState(null); // Replaced viewingShipment
  const [shipmentItems, setShipmentItems] = useState([]); // New state for items of selected shipment
  const [downloading, setDownloading] = useState(null); // State to track which shipment's slip is downloading
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10); // Changed default items per page

  const loadShipments = useCallback(async () => {
    if (!user) return; // Ensure user exists before trying to load shipments
    setLoading(true);
    try {
      const shipmentData = await Shipment.filter({ member_id: user.id }, "-created_date");
      setShipments(shipmentData);
    } catch (error) {
      console.error("Error loading shipments:", error);
      toast.error("Failed to load your shipments.");
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    // Load shipments only when user data is available
    if (user) {
      loadShipments();
    } else if (!userLoading) {
      // If user is null and not loading, then no user is logged in
      setLoading(false);
    }
  }, [user, userLoading, loadShipments]); // Depend on user, userLoading, and loadShipments

  const handleViewDetails = async (shipment) => {
    setSelectedShipment(shipment); // Set the selected shipment for the modal
    try {
      // Load shipment items specifically for the selected shipment
      const items = await ShipmentItem.filter({ shipment_id: shipment.id });
      setShipmentItems(items);
    } catch (error) {
      console.error("Error loading shipment items:", error);
      toast.error("Failed to load shipment details.");
      setShipmentItems([]); // Clear items if loading fails
    }
  };

  const handleDownloadPackingSlip = async (shipment) => {
    setDownloading(shipment.id); // Indicate which shipment is being downloaded
    try {
      await downloadPackingSlipPdf(shipment.id);
      toast.success("Packing slip downloaded successfully!");
    } catch (error) {
      console.error("Error downloading packing slip:", error);
      toast.error("Failed to download packing slip.");
    } finally {
      setDownloading(null); // Reset downloading state
    }
  };

  const getStatusBadgeVariant = (status) => {
    switch (status) {
      case "Pending": return "bg-yellow-100 text-yellow-800";
      case "Preparing": return "bg-blue-100 text-blue-800";
      case "Shipped": return "bg-purple-100 text-purple-800";
      case "Cancelled": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  // Pagination now directly uses the 'shipments' array as there's no client-side filtering state
  const paginatedShipments = shipments.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  return (
    <div className="p-6 md:p-8 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">My Shipments</h1>
            <p className="text-slate-600">Track your shipments.</p>
          </div>
          {/* Create shipment buttons removed as per updated requirements */}
          {/* <div className="flex gap-2">
            {user?.is_reseller && (
              <Button onClick={() => setIsCreateDropShipmentModalOpen(true)}>
                <Send className="w-4 h-4 mr-2" />
                Create Drop Shipment
              </Button>
            )}
            <Button onClick={() => setIsCreateModalOpen(true)}>
              <PlusCircle className="w-4 h-4 mr-2" />
              Create New Shipment
            </Button>
          </div> */}
        </div>

        {/* Filter Bar removed as per updated requirements */}
        {/* <Card className="mb-6 bg-white border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="status-filter">Filter by Status</Label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger id="status-filter" className="border-slate-200 mt-1">
                    <SelectValue placeholder="All Statuses" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    {uniqueStatuses.map(status => (
                      <SelectItem key={status} value={status}>{status}</SelectItem>
                    )}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card> */}

        <Card className="bg-white border-0 shadow-sm">
          <CardHeader>
            <CardTitle>Shipment History</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Shipment ID</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date Created</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading || userLoading ? (
                    <TableRow><TableCell colSpan="4" className="text-center py-16"><Loader2 className="w-8 h-8 text-slate-400 mx-auto animate-spin" /></TableCell></TableRow>
                  ) : paginatedShipments.length > 0 ? (
                    paginatedShipments.map(shipment => (
                      <TableRow key={shipment.id}>
                        <TableCell className="font-medium">{shipment.shipment_id}</TableCell>
                        <TableCell><Badge className={getStatusBadgeVariant(shipment.status)}>{shipment.status}</Badge></TableCell>
                        <TableCell>{new Date(shipment.created_date).toLocaleDateString()}</TableCell>
                        <TableCell className="text-right flex items-center justify-end gap-2">
                          {/* Replaced DropdownMenu with direct buttons */}
                          <Button variant="ghost" size="icon" onClick={() => handleViewDetails(shipment)} title="View Details">
                            <Package className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDownloadPackingSlip(shipment)}
                            disabled={downloading === shipment.id}
                            title="Download Packing Slip"
                          >
                            {downloading === shipment.id ? (
                              <Loader2 className="w-4 h-4 animate-spin" />
                            ) : (
                              <FileDown className="w-4 h-4" />
                            )}
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow><TableCell colSpan="4" className="text-center py-16">
                      <Truck className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                      <h3 className="font-semibold text-slate-800">No Shipments Found</h3>
                      <p className="text-slate-500 text-sm">
                        Create a new shipment to get started.
                      </p>
                    </TableCell></TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
          <PaginationControls
            totalItems={shipments.length} // Uses shipments.length directly
            itemsPerPage={itemsPerPage}
            setItemsPerPage={setItemsPerPage}
            currentPage={currentPage}
            setCurrentPage={setCurrentPage}
          />
        </Card>
      </div>

      {/* Create and Edit Modals, and Confirmation Dialog removed */}
      {/* {isCreateModalOpen && (
        <CreateShipmentModal
          isOpen={isCreateModalOpen}
          onClose={() => setIsCreateModalOpen(false)}
          onShipmentCreated={() => loadPageData(false)}
        />
      )}

      {isCreateDropShipmentModalOpen && (
        <CreateDropShipmentModal
          isOpen={isCreateDropShipmentModalOpen}
          onClose={() => setIsCreateDropShipmentModalOpen(false)}
          onShipmentCreated={() => loadPageData(false)}
        />
      )} */}

      {selectedShipment && (
        <ShipmentDetailsModal
          shipment={selectedShipment}
          shipmentItems={shipmentItems} // Pass shipment items
          onClose={() => setSelectedShipment(null)}
        />
      )}

      {/* {editingShipment && (
        <EditShipmentModal
          shipment={editingShipment}
          onClose={() => setEditingShipment(null)}
          onShipmentUpdated={() => loadPageData(false)}
        />
      )}

      <ConfirmationDialog
        open={!!deletingShipment}
        onOpenChange={() => setDeletingShipment(null)}
        title="Delete Shipment"
        description={`Are you sure you want to delete shipment ${deletingShipment?.shipment_id}? The items will be returned to your inventory. This cannot be undone.`}
        onConfirm={handleDeleteShipment}
        variant="destructive"
        confirmText="Yes, Delete"
      /> */}
    </div>
  );
}
