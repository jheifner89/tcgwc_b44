
import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Package, ArrowRight } from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { createStripeCheckout } from "@/api/functions";

const MEMBERSHIP_FEATURES = [
    "Access to exclusive distributor catalog",
    "Competitive pricing on all products",
    "Priority allocation on new releases",
    "Advanced inventory management",
    "Dedicated email support",
    "Bulk ordering capabilities"
];

export default function MembershipPage() {
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const [isRedirecting, setIsRedirecting] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    checkUserStatus();
  }, []);

  const checkUserStatus = async () => {
    try {
      const userData = await User.me();
      
      // Redirect if user is already active
      if (userData.membership_status === 'active') {
        navigate(createPageUrl("Dashboard"));
        return;
      }
      
      setUser(userData);
    } catch (error) {
      console.error("Error fetching user data:", error);
      toast.error("Could not verify user status.");
    } finally {
      setLoading(false);
    }
  };

  const handleSubscribe = async () => {
    setIsRedirecting(true);
    try {
      const response = await createStripeCheckout({});
      
      if (response.status === 200) {
        const { checkout_url } = response.data;
        if (checkout_url) {
          // Standard redirect flow - user goes to Stripe and comes back
          window.location.href = checkout_url;
        } else {
          throw new Error("No checkout URL received");
        }
      } else {
        throw new Error(response.data?.error || "Failed to create checkout session");
      }
    } catch (error) {
      console.error("Stripe Checkout Error:", error);
      toast.error("Failed to initiate subscription. Please try again or contact support.");
      setIsRedirecting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen bg-slate-50">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-slate-900"></div>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-b from-slate-50 to-slate-100 min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <Card className="bg-white rounded-2xl shadow-xl border-0 max-w-2xl w-full">
        <CardHeader className="p-8 text-center">
          <div className="w-16 h-16 bg-slate-900 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <Package className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="text-3xl font-extrabold text-slate-900">
            Unlock Your Membership
          </CardTitle>
          <CardDescription className="mt-4 text-lg text-slate-600">
            Gain full access to our distributor product catalog and start placing orders today.
          </CardDescription>
        </CardHeader>
        <CardContent className="p-8 pt-0">
          <div className="bg-slate-50 rounded-xl p-6 mb-6">
            <h3 className="font-semibold text-slate-800 mb-4">Membership Includes:</h3>
            <ul className="space-y-3">
              {MEMBERSHIP_FEATURES.map((feature, index) => (
                <li key={index} className="flex items-center">
                  <CheckCircle2 className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                  <span className="text-slate-700">{feature}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-center">
            <p className="text-blue-800 text-sm">
              <strong>Secure Payment:</strong> You'll be redirected to Stripe's secure checkout to complete your subscription.
            </p>
          </div>
        </CardContent>
        <CardFooter className="p-8">
          <Button
            onClick={handleSubscribe}
            disabled={isRedirecting}
            className="w-full h-14 rounded-xl bg-slate-900 hover:bg-slate-800 text-lg font-semibold"
          >
            {isRedirecting ? (
              <>
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-3" />
                Redirecting to Checkout...
              </>
            ) : (
              <>
                Activate Membership
                <ArrowRight className="w-5 h-5 ml-3" />
              </>
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
