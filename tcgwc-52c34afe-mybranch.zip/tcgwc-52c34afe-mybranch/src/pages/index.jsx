import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Products from "./Products";

import Membership from "./Membership";

import MembershipSuccess from "./MembershipSuccess";

import MembershipCancelled from "./MembershipCancelled";

import MyRequests from "./MyRequests";

import AdminDashboard from "./AdminDashboard";

import AdminRequests from "./AdminRequests";

import AdminProducts from "./AdminProducts";

import AdminUsers from "./AdminUsers";

import AdminInvoices from "./AdminInvoices";

import AdminOrders from "./AdminOrders";

import Register from "./Register";

import CompleteProfile from "./CompleteProfile";

import AdminTools from "./AdminTools";

import MyInvoices from "./MyInvoices";

import ViewInvoice from "./ViewInvoice";

import MyOrders from "./MyOrders";

import MyShipments from "./MyShipments";

import AdminShipments from "./AdminShipments";

import AdminEditInvoice from "./AdminEditInvoice";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Products: Products,
    
    Membership: Membership,
    
    MembershipSuccess: MembershipSuccess,
    
    MembershipCancelled: MembershipCancelled,
    
    MyRequests: MyRequests,
    
    AdminDashboard: AdminDashboard,
    
    AdminRequests: AdminRequests,
    
    AdminProducts: AdminProducts,
    
    AdminUsers: AdminUsers,
    
    AdminInvoices: AdminInvoices,
    
    AdminOrders: AdminOrders,
    
    Register: Register,
    
    CompleteProfile: CompleteProfile,
    
    AdminTools: AdminTools,
    
    MyInvoices: MyInvoices,
    
    ViewInvoice: ViewInvoice,
    
    MyOrders: MyOrders,
    
    MyShipments: MyShipments,
    
    AdminShipments: AdminShipments,
    
    AdminEditInvoice: AdminEditInvoice,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Products" element={<Products />} />
                
                <Route path="/Membership" element={<Membership />} />
                
                <Route path="/MembershipSuccess" element={<MembershipSuccess />} />
                
                <Route path="/MembershipCancelled" element={<MembershipCancelled />} />
                
                <Route path="/MyRequests" element={<MyRequests />} />
                
                <Route path="/AdminDashboard" element={<AdminDashboard />} />
                
                <Route path="/AdminRequests" element={<AdminRequests />} />
                
                <Route path="/AdminProducts" element={<AdminProducts />} />
                
                <Route path="/AdminUsers" element={<AdminUsers />} />
                
                <Route path="/AdminInvoices" element={<AdminInvoices />} />
                
                <Route path="/AdminOrders" element={<AdminOrders />} />
                
                <Route path="/Register" element={<Register />} />
                
                <Route path="/CompleteProfile" element={<CompleteProfile />} />
                
                <Route path="/AdminTools" element={<AdminTools />} />
                
                <Route path="/MyInvoices" element={<MyInvoices />} />
                
                <Route path="/ViewInvoice" element={<ViewInvoice />} />
                
                <Route path="/MyOrders" element={<MyOrders />} />
                
                <Route path="/MyShipments" element={<MyShipments />} />
                
                <Route path="/AdminShipments" element={<AdminShipments />} />
                
                <Route path="/AdminEditInvoice" element={<AdminEditInvoice />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}