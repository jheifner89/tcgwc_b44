
import React, { useState, useEffect, useCallback } from "react";
import { Product } from "@/api/entities";
import { Request } from "@/api/entities";
import { useUser } from "@/layout"; // Changed: Imported useUser hook
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuLabel,
  DropdownMenuSeparator
} from "@/components/ui/dropdown-menu";
import {
  Search,
  ShoppingCart,
  Package,
  Filter,
  ChevronDown
} from "lucide-react";
import { toast } from "sonner";
import PaginationControls from "@/components/ui/PaginationControls";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { proxyProductRequest } from "@/api/functions";

export default function Products() {
  const { user, loading: userLoading } = useUser(); // Changed: Using useUser hook for user state and loading
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [loading, setLoading] = useState(true); // Now only reflects product loading, userLoading is separate
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedDistributor, setSelectedDistributor] = useState("all");
  const [selectedAvailability, setSelectedAvailability] = useState(["Open", "Pre-Order", "Special Offer"]);
  const [showInStockOnly, setShowInStockOnly] = useState(false);
  const [requestQuantities, setRequestQuantities] = useState({});
  const [requesting, setRequesting] = useState({});
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(25);

  const loadData = async () => {
    try {
      // Removed: User.me() call, as user data is now managed by useUser hook
      console.log("Loading products data...");

      // Load all approved products with a high limit, sorted by name
      const approvedProducts = await Product.filter({ approved: true }, 'name', 10000);
      console.log("Approved products loaded:", approvedProducts.length);
      
      setProducts(approvedProducts);
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setLoading(false);
    }
  };

  const filterProducts = useCallback(() => {
    let filtered = [...products];
    console.log("Starting filter with products:", products.length);

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(product =>
        product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.sku?.toLowerCase().includes(searchTerm.toLowerCase())
      );
      console.log("After search filter:", filtered.length);
    }

    // Category filter
    if (selectedCategory !== "all") {
      filtered = filtered.filter(product => product.product_line === selectedCategory);
      console.log("After category filter:", filtered.length);
    }

    // Distributor filter
    if (selectedDistributor !== "all") {
      filtered = filtered.filter(product => product.distributor === selectedDistributor);
      console.log("After distributor filter:", filtered.length);
    }

    // Availability filter - always apply this filter. If empty, it shows nothing.
    filtered = filtered.filter(product => 
      product.availability && selectedAvailability.map(s => s.toLowerCase()).includes(product.availability.toLowerCase())
    );
    console.log("After availability filter:", filtered.length);

    // In Stock filter
    if (showInStockOnly) {
      filtered = filtered.filter(product => product.in_stock === true);
      console.log("After in stock filter:", filtered.length);
    }

    // Sorting is now handled by the database query

    console.log("Final filtered products:", filtered.length);
    setFilteredProducts(filtered);
    setCurrentPage(1);
  }, [products, searchTerm, selectedCategory, selectedDistributor, selectedAvailability, showInStockOnly]);

  useEffect(() => {
    if (!userLoading) { // Changed: Only load data once user data is available
        loadData();
    }
  }, [userLoading]); // Dependency added for userLoading

  useEffect(() => {
    filterProducts();
  }, [filterProducts]);

  // Check if product orders are still allowed
  const areOrdersAllowed = (product) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // If it's a special offer or pre-order, check the orders due date
    if (["Pre-Order", "Special Offer"].includes(product.availability)) {
      if (product.orders_due_date) {
        const ordersDueDate = new Date(product.orders_due_date);
        return ordersDueDate >= today;
      }
      return true; // If no orders due date set, allow orders
    }

    return true; // For "Open" products, always allow orders
  };

  // Check if product should be shown as available for ordering
  const isProductAvailable = (product) => {
    return product.in_stock && areOrdersAllowed(product);
  };

  // Get stock status display
  const getStockStatus = (product) => {
    if (!areOrdersAllowed(product)) {
      return { text: "Closed", className: "text-red-600 font-semibold" };
    }
    if (product.in_stock) {
      return { text: "In Stock", className: "text-green-600 font-semibold" };
    }
    return { text: "Out of Stock", className: "text-red-600 font-semibold" };
  };

  const handleQuantityChange = (productId, quantity) => {
    setRequestQuantities(prev => ({
      ...prev,
      [productId]: Math.max(0, quantity)
    }));
  };

  const submitRequest = async (product) => {
    const quantity = requestQuantities[product.id] || 1;

    if (quantity < 1) {
      toast.error("Quantity must be at least 1");
      return;
    }

    if (!areOrdersAllowed(product)) {
      toast.error("Orders are no longer being accepted for this product");
      return;
    }

    setRequesting(prev => ({ ...prev, [product.id]: true }));
    const impersonationDataString = sessionStorage.getItem('impersonationData');

    try {
      if (impersonationDataString && user) {
        const impersonationToken = JSON.parse(impersonationDataString);
        console.log("Making impersonated request for:", user.full_name);
        
        const response = await proxyProductRequest({ product, quantity, impersonationToken });
        
        if (response.status !== 200) {
          throw new Error(response.data?.error || 'Request failed');
        }
        
        toast.success(`Request submitted for ${user.full_name}`);
      } else if (user) {
        // Check for an existing request for this product by this user
        const existingRequests = await Request.filter({
          member_id: user.id,
          product_id: product.id,
        });

        if (existingRequests.length > 0) {
          // Update the existing request
          const existingRequest = existingRequests[0];
          const newQuantity = existingRequest.quantity + quantity;
          await Request.update(existingRequest.id, { quantity: newQuantity });
          toast.success(`Updated request. New quantity: ${newQuantity}`);
        } else {
          // Create a new request, capturing product data
          await Request.create({
            member_id: user.id,
            product_id: product.id,
            quantity: quantity,
            product_name: product.name,
            product_sku: product.sku,
            wholesale_price: product.wholesale_price,
          });
          toast.success("Product request submitted successfully!");
        }
      } else {
        toast.error("User not found. Please log in.");
      }

      // Reset quantity input for this product
      setRequestQuantities(prev => ({ ...prev, [product.id]: 0 }));
    } catch (error) {
      console.error("Error submitting request:", error);
      toast.error(error.message || "Failed to submit request. Please try again.");
    } finally {
      setRequesting(prev => ({ ...prev, [product.id]: false }));
    }
  };

  const handleAvailabilityChange = (availability, checked) => {
    if (checked) {
      setSelectedAvailability(prev => [...prev, availability]);
    } else {
      setSelectedAvailability(prev => prev.filter(a => a !== availability));
    }
  };

  const categories = [...new Set(products.map(p => p.product_line).filter(Boolean))];
  const distributors = [...new Set(products.map(p => p.distributor).filter(Boolean))];

  const paginatedProducts = filteredProducts.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  if (loading || userLoading) { // Changed: Added userLoading to the loading check
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-64"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-64 bg-gray-200 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // User check now relies on the 'user' object from useUser
  if (user?.membership_status !== 'active' && user?.role !== 'admin') {
    console.log("User membership check failed:", {
      membership_status: user?.membership_status,
      role: user?.role
    });
    return (
      <div className="p-8 flex items-center justify-center min-h-[60vh]">
        <div className="text-center max-w-md">
          <Package className="w-16 h-16 text-slate-300 mx-auto mb-4" />
          <h2 className="text-2xl font-semibold text-slate-900 mb-2">Membership Required</h2>
          <p className="text-slate-600">
            You need an active membership to access our distributor products.
            Please contact support to activate your account.
          </p>
        </div>
      </div>
    );
  }

  console.log("Rendering products page with filtered products:", filteredProducts.length);

  return (
    <div className="p-6 md:p-8 min-h-full">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Product Catalog</h1>
          <p className="text-slate-600">Browse and request products from our trusted distributors.</p>
        </div>

        {/* Filters */}
        <Card className="mb-8 bg-white border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              {/* Search */}
              <div className="relative lg:col-span-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                <Input
                  placeholder="Search products..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9 border-slate-200"
                />
              </div>

              {/* Category Filter */}
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="border-slate-200">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {categories.map(category => (
                    <SelectItem key={category} value={category}>{category}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Distributor Filter */}
              <Select value={selectedDistributor} onValueChange={setSelectedDistributor}>
                <SelectTrigger className="border-slate-200">
                  <SelectValue placeholder="All Distributors" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Distributors</SelectItem>
                  {distributors.map(distributor => (
                    <SelectItem key={distributor} value={distributor}>{distributor}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Availability Multi-Select Dropdown */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="border-slate-200 flex justify-between">
                    <span>
                      <Filter className="w-4 h-4 mr-2 inline-block" />
                      Availability ({selectedAvailability.length})
                    </span>
                    <ChevronDown className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56">
                  <DropdownMenuLabel>Filter by Availability</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  {["Open", "Pre-Order", "Special Offer"].map(option => (
                    <DropdownMenuCheckboxItem
                      key={option}
                      checked={selectedAvailability.includes(option)}
                      onCheckedChange={(checked) => handleAvailabilityChange(option, checked)}
                    >
                      {option}
                    </DropdownMenuCheckboxItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>

              {/* In Stock Filter */}
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="in-stock-filter"
                  checked={showInStockOnly}
                  onCheckedChange={setShowInStockOnly}
                />
                <Label htmlFor="in-stock-filter" className="text-sm font-medium">
                  In Stock Only
                </Label>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Products List */}
        <div className="space-y-4">
          {paginatedProducts.map((product) => {
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            const overrideEndDate = product.override_end_date ? new Date(product.override_end_date) : null;
            const isOverrideActive = product.override_price && overrideEndDate && overrideEndDate >= today;
            const productAvailable = isProductAvailable(product);
            const stockStatus = getStockStatus(product);

            return (
              <div key={product.id} className="bg-white border-0 shadow-sm hover:shadow-md transition-all duration-200 rounded-lg p-4 flex flex-col sm:flex-row items-center gap-6">
                {/* Image */}
                <div className="w-32 h-32 flex-shrink-0 bg-white rounded-md flex items-center justify-center p-2 border">
                  {product.image_url ? (
                    <img
                      src={product.image_url}
                      alt={product.name}
                      className="max-w-full max-h-full object-contain"
                    />
                  ) : (
                    <Package className="w-12 h-12 text-slate-400" />
                  )}
                </div>

                {/* Details */}
                <div className="flex-grow w-full">
                  <h3 className="font-semibold text-slate-900 text-lg mb-2">{product.name}</h3>

                  <div className="flex flex-wrap gap-2 mb-3">
                    {product.product_line && (
                      <Badge variant="secondary" className="text-xs">{product.product_line}</Badge>
                    )}
                    <Badge variant="outline" className="text-xs">{product.distributor}</Badge>
                    <Badge
                      variant={product.availability === 'Open' ? 'default' : 'secondary'}
                      className="text-xs"
                    >
                      {product.availability}
                    </Badge>
                    {/* Show orders due date for special offers and pre-orders */}
                    {["Pre-Order", "Special Offer"].includes(product.availability) && product.orders_due_date && (
                      <Badge variant="outline" className="text-xs">
                        Orders due: {new Date(product.orders_due_date).toLocaleDateString()}
                      </Badge>
                    )}
                  </div>

                  {/* Pricing Section */}
                  <div className="flex items-baseline gap-2 border-t border-slate-100 pt-2">
                    <span className={`text-2xl font-bold ${isOverrideActive ? 'text-green-600' : 'text-slate-800'}`}>
                      ${(isOverrideActive ? product.override_price : product.wholesale_price)?.toFixed(2)}
                    </span>
                  </div>
                </div>

                {/* Actions */}
                <div className="w-full sm:w-auto flex flex-col items-stretch sm:items-end gap-2 flex-shrink-0">
                  <div className="flex items-center gap-2">
                    <Input
                      type="number"
                      min="1"
                      value={requestQuantities[product.id] || 1}
                      onChange={(e) => handleQuantityChange(product.id, parseInt(e.target.value, 10) || 0)}
                      className="w-20 border-slate-200"
                      disabled={!productAvailable}
                    />
                    <Button
                      onClick={() => submitRequest(product)}
                      disabled={requesting[product.id] || !productAvailable}
                      className="flex-1 bg-slate-900 hover:bg-slate-800 text-white"
                    >
                      {requesting[product.id] ? (
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <>
                          <ShoppingCart className="w-4 h-4 mr-2" />
                          Request
                        </>
                      )}
                    </Button>
                  </div>
                  <div className="text-sm text-center sm:text-right text-slate-500 pr-1">
                    Stock: <span className={stockStatus.className}>
                      {stockStatus.text}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Pagination Controls */}
        {filteredProducts.length > 0 && (
          <div className="mt-6">
            <PaginationControls
              totalItems={filteredProducts.length}
              itemsPerPage={itemsPerPage}
              setItemsPerPage={setItemsPerPage}
              currentPage={currentPage}
              setCurrentPage={setCurrentPage}
              className="bg-white rounded-lg shadow-sm"
            />
          </div>
        )}

        {filteredProducts.length === 0 && !loading && (
          <div className="text-center py-12">
            <Package className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-slate-900 mb-2">No products found</h3>
            <p className="text-slate-600">Try adjusting your search or filter criteria.</p>
          </div>
        )}
      </div>
    </div>
  );
}
