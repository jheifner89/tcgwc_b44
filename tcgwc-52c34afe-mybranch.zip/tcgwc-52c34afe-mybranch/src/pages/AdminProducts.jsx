
import React, { useState, useEffect, useRef, useCallback } from "react";
import { Product } from "@/api/entities";
import { User } from "@/api/entities";
import AdminHeader from "@/components/admin/AdminHeader";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
import { CheckCircle2, XCircle, PlusCircle, Download, Upload, MoreHorizontal, Edit, Trash2, AlertCircle, ShieldCheck, ShieldAlert, ChevronDown, Settings, Search, BarChart4 } from "lucide-react";
import { toast } from "sonner";
import { exportProductsToCsv } from "@/api/functions";
import { importProductsFromCsv } from "@/api/functions";
import { getPaginatedProducts } from "@/api/functions";
import ProductFormModal from "@/components/products/ProductFormModal";
import AllocationModal from "@/components/products/AllocationModal";
import ConfirmationDialog from "@/components/ui/ConfirmationDialog";
import PaginationControls from "@/components/ui/PaginationControls";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useDebounce } from "@/components/hooks/useDebounce";

export default function AdminProducts() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [confirmDialog, setConfirmDialog] = useState({ open: false, title: "", description: "", onConfirm: null, variant: "default", confirmText: "Confirm" });
  const fileInputRef = useRef(null);
  
  const [allocationModal, setAllocationModal] = useState({ isOpen: false, product: null });

  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(25);
  const [totalProducts, setTotalProducts] = useState(0);
  const [selectedProductIds, setSelectedProductIds] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedProductLine, setSelectedProductLine] = useState("all");
  const [allProductLines, setAllProductLines] = useState([]);
  
  const debouncedSearchTerm = useDebounce(searchTerm, 500);

  const loadProducts = useCallback(async () => {
    if (!isAdmin) return; // Ensure products are only loaded if admin status is confirmed
    setLoading(true);
    setSelectedProductIds([]);

    try {
      const { data, error } = await getPaginatedProducts({
        page: currentPage,
        limit: itemsPerPage,
        searchTerm: debouncedSearchTerm,
        productLine: selectedProductLine,
      });

      if (error) {
        throw new Error(error.details || 'Failed to load products');
      }

      setProducts(data.products);
      setTotalProducts(data.total);
    } catch (error) {
      console.error("Error loading products:", error);
      toast.error(error.message || "Failed to load products.");
    } finally {
      setLoading(false);
    }
  }, [isAdmin, currentPage, itemsPerPage, debouncedSearchTerm, selectedProductLine]);

  // Check admin status and load product lines once on component mount
  useEffect(() => {
    const checkAdminAndLoadInitialData = async () => {
      try {
        const userData = await User.me();
        if (userData.role !== 'admin') {
          toast.error("Access denied. Admin privileges required.");
          setIsAdmin(false);
          setLoading(false);
          return;
        }
        setIsAdmin(true);
        
        // Load product lines for the dropdown regardless of previous state, as this runs once.
        const allProds = await Product.list('name', 10000);
        const uniqueLines = [...new Set(allProds.map(p => p.product_line).filter(Boolean))];
        setAllProductLines(uniqueLines);
      } catch (e) {
        toast.error("You must be logged in to view this page.");
        setLoading(false);
      }
    };
    checkAdminAndLoadInitialData();
  }, []); // Empty dependency array means this effect runs only once on mount.

  // Load products when filters or pagination change, or when isAdmin status is confirmed.
  useEffect(() => {
    if (isAdmin) { // Only attempt to load products if user is confirmed as admin
      loadProducts();
    }
  }, [isAdmin, loadProducts]);


  const handleDownloadCsv = async () => {
    toast.info("Generating CSV file...");
    try {
      const response = await exportProductsToCsv();
      const blob = new Blob([response.data], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `products_export_${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
      toast.success("CSV export downloaded.");
    } catch (error) {
      toast.error("Failed to export products.");
    }
  };

  const handleUploadCsv = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    toast.info("Uploading and processing CSV...");
    try {
      const fileText = await file.text();
      const response = await importProductsFromCsv({ fileContent: fileText });

      if (response.status === 200) {
        const { created, updated, errors } = response.data;
        let successMessage = `Import complete: ${created} created, ${updated} updated.`;
        toast.success(successMessage);
        
        if (errors && errors.length > 0) {
          const errorDetails = errors.map(err => 
            `• SKU ${err.sku || 'N/A'}: ${err.error || 'Unknown error'}`
          ).join('\n');

          toast.warning(
            `${errors.length} rows failed to import.`, 
            {
              description: (
                <pre className="mt-2 w-full rounded-md bg-slate-100 p-4 max-h-60 overflow-y-auto">
                  <code className="text-slate-800 text-xs">{errorDetails}</code>
                </pre>
              ),
              duration: 15000, // Give user more time to read
              closeButton: true,
            }
          );
          console.error("Import errors:", errors);
        }
        
        setCurrentPage(1);
        loadProducts();
      } else {
        throw new Error(response.data?.error || "Import failed");
      }
    } catch (error) {
      console.error("CSV Import Error:", error);
      const errorMessage = error.response?.data?.details || error.message;
      toast.error("Error processing CSV: " + errorMessage);
    } finally {
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  const handleAddProduct = () => {
    setEditingProduct(null);
    setIsModalOpen(true);
  };

  const handleEditProduct = (product) => {
    setEditingProduct(product);
    setIsModalOpen(true);
  };
  
  const handleOpenAllocation = (product) => {
    setAllocationModal({ isOpen: true, product: product });
  };

  const handleDeleteProduct = (product) => {
    setConfirmDialog({
      open: true,
      title: "Delete Product",
      description: `Are you sure you want to delete "${product.name}"? This action cannot be undone.`,
      onConfirm: async () => {
        try {
          await Product.delete(product.id);
          toast.success("Product deleted successfully.");
          loadProducts();
        } catch (error) {
          toast.error("Failed to delete product.");
        }
      },
      variant: "destructive",
      confirmText: "Delete Product"
    });
  };

  const handleSelectAll = (checked) => {
    if (checked) {
      setSelectedProductIds(products.map(p => p.id));
    } else {
      setSelectedProductIds([]);
    }
  };

  const handleSelectOne = (productId) => {
    setSelectedProductIds(prev =>
      prev.includes(productId)
        ? prev.filter(id => id !== productId)
        : [...prev, productId]
    );
  };
  
  const handleBulkAction = (action) => {
    if (selectedProductIds.length === 0) {
      toast.info("No products selected.");
      return;
    }
    
    let title, description, onConfirm, variant = 'default', confirmText;
    
    switch (action) {
      case 'setInStock':
        title = "Set In Stock";
        description = `Are you sure you want to mark ${selectedProductIds.length} product(s) as 'In Stock'?`;
        confirmText = "Mark as In Stock";
        onConfirm = () => bulkUpdate({ in_stock: true });
        break;
      case 'setOutOfStock':
        title = "Set Out of Stock";
        description = `Are you sure you want to mark ${selectedProductIds.length} product(s) as 'Out of Stock'?`;
        confirmText = "Mark as Out of Stock";
        onConfirm = () => bulkUpdate({ in_stock: false });
        break;
      case 'setApproved':
        title = "Approve Products";
        description = `Are you sure you want to approve ${selectedProductIds.length} product(s) for the portal?`;
        confirmText = "Approve Products";
        onConfirm = () => bulkUpdate({ approved: true });
        break;
      case 'setUnapproved':
        title = "Unapprove Products";
        description = `Are you sure you want to unapprove ${selectedProductIds.length} product(s)? They will be hidden from users.`;
        confirmText = "Unapprove Products";
        onConfirm = () => bulkUpdate({ approved: false });
        break;
      case 'delete':
        title = "Delete Products";
        description = `Are you sure you want to permanently delete ${selectedProductIds.length} product(s)? This action cannot be undone.`;
        confirmText = "Delete Products";
        variant = "destructive";
        onConfirm = bulkDelete;
        break;
      default:
        return;
    }
    
    setConfirmDialog({ open: true, title, description, onConfirm, variant, confirmText });
  };
  
  const bulkUpdate = async (updateData) => {
    const totalProducts = selectedProductIds.length;
    toast.info(`Updating ${totalProducts} products...`);
    
    try {
      let updatedCount = 0;
      let errorCount = 0;
      const batchSize = 10; // Process 10 at a time
      
      // Process in batches with delays
      for (let i = 0; i < selectedProductIds.length; i += batchSize) {
        const batch = selectedProductIds.slice(i, i + batchSize);
        
        const updatePromises = batch.map(async (id) => {
          try {
            await Product.update(id, updateData);
            return { success: true };
          } catch (error) {
            console.error(`Failed to update product ${id}:`, error);
            return { success: false, error: error.message };
          }
        });
        
        const results = await Promise.all(updatePromises);
        
        // Count successes and failures
        results.forEach(result => {
          if (result.success) {
            updatedCount++;
          } else {
            errorCount++;
          }
        });
        
        // Update progress
        const progress = Math.min(i + batchSize, totalProducts);
        toast.info(`Updated ${progress}/${totalProducts} products...`);
        
        // Add delay between batches (except for the last batch)
        if (i + batchSize < selectedProductIds.length) {
          await new Promise(resolve => setTimeout(resolve, 1000)); // 1 second delay
        }
      }
      
      if (errorCount === 0) {
        toast.success(`All ${updatedCount} products updated successfully.`);
      } else {
        toast.warning(`${updatedCount} products updated, ${errorCount} failed.`);
      }
      
      loadProducts();
    } catch (error) {
      toast.error("Failed to update products.");
      console.error("Bulk update error:", error);
    }
  };
  
  const bulkDelete = async () => {
    const totalProducts = selectedProductIds.length;
    toast.info(`Deleting ${totalProducts} products...`);
    
    try {
      let deletedCount = 0;
      let errorCount = 0;
      const batchSize = 10; // Process 10 at a time
      
      // Process in batches with delays
      for (let i = 0; i < selectedProductIds.length; i += batchSize) {
        const batch = selectedProductIds.slice(i, i + batchSize);
        
        const deletePromises = batch.map(async (id) => {
          try {
            await Product.delete(id);
            return { success: true };
          } catch (error) {
            console.error(`Failed to delete product ${id}:`, error);
            return { success: false, error: error.message };
          }
        });
        
        const results = await Promise.all(deletePromises);
        
        // Count successes and failures
        results.forEach(result => {
          if (result.success) {
            deletedCount++;
          } else {
            errorCount++;
          }
        });
        
        // Update progress
        const progress = Math.min(i + batchSize, totalProducts);
        toast.info(`Deleted ${progress}/${totalProducts} products...`);
        
        // Add delay between batches (except for the last batch)
        if (i + batchSize < selectedProductIds.length) {
          await new Promise(resolve => setTimeout(resolve, 1000)); // 1 second delay
        }
      }
      
      if (errorCount === 0) {
        toast.success(`All ${deletedCount} products deleted successfully.`);
      } else {
        toast.warning(`${deletedCount} products deleted, ${errorCount} failed.`);
      }
      
      loadProducts();
    } catch (error) {
      toast.error("Failed to delete products.");
      console.error("Bulk delete error:", error);
    }
  };

  if (!isAdmin && !loading) {
    return (
      <div className="p-6 md:p-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Product Management</h1>
          <AdminHeader />
          <div className="p-8 flex flex-col items-center justify-center text-center h-[50vh]">
            <AlertCircle className="w-12 h-12 text-red-500 mb-4" />
            <h2 className="text-2xl font-bold">Access Denied</h2>
            <p className="text-slate-600">You do not have permission to view this page.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 md:p-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-slate-900 mb-2">Product Management</h1>
        <AdminHeader />
        
        <div className="mb-4 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
            <Input
              placeholder="Search products by name or SKU..."
              value={searchTerm}
              onChange={(e) => {
                setCurrentPage(1);
                setSearchTerm(e.target.value);
              }}
              className="pl-9"
            />
          </div>
          
          <Select 
            value={selectedProductLine} 
            onValueChange={(value) => {
              setCurrentPage(1);
              setSelectedProductLine(value);
            }}
          >
            <SelectTrigger>
              <SelectValue placeholder="All Product Lines" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Product Lines</SelectItem>
              {allProductLines.map(line => (
                <SelectItem key={line} value={line}>{line}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <div className="text-sm text-slate-500 flex items-center">
            Total Products: {totalProducts}
          </div>
        </div>

        <div className="flex justify-between items-center my-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" disabled={selectedProductIds.length === 0}>
                  <Settings className="w-4 h-4 mr-2" />
                  Bulk Actions ({selectedProductIds.length})
                  <ChevronDown className="w-4 h-4 ml-2" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuLabel>Update Stock</DropdownMenuLabel>
                <DropdownMenuItem onClick={() => handleBulkAction('setInStock')}>Set In Stock</DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleBulkAction('setOutOfStock')}>Set Out of Stock</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuLabel>Update Approval</DropdownMenuLabel>
                <DropdownMenuItem onClick={() => handleBulkAction('setApproved')}>Set Approved</DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleBulkAction('setUnapproved')}>Set Unapproved</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => handleBulkAction('delete')} className="text-red-600 focus:text-red-500">
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete Selected
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

          <div className="flex justify-end gap-2">
            <input type="file" ref={fileInputRef} className="hidden" onChange={handleUploadCsv} accept=".csv" />
            <Button variant="outline" onClick={() => fileInputRef.current.click()}>
              <Upload className="w-4 h-4 mr-2" /> Import CSV
            </Button>
            <Button variant="outline" onClick={handleDownloadCsv}>
              <Download className="w-4 h-4 mr-2" /> Export CSV
            </Button>
            <Button onClick={handleAddProduct}>
              <PlusCircle className="w-4 h-4 mr-2" /> Add Product
            </Button>
          </div>
        </div>


        <Card className="bg-white border-0 shadow-sm">
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12 px-4">
                       <Checkbox
                        checked={selectedProductIds.length === products.length && products.length > 0}
                        onCheckedChange={handleSelectAll}
                        aria-label="Select all on this page"
                      />
                    </TableHead>
                    <TableHead>Product Name</TableHead>
                    <TableHead>Wholesale Price</TableHead>
                    <TableHead>Distributor</TableHead>
                    <TableHead>Availability</TableHead>
                    <TableHead>In Stock</TableHead>
                    <TableHead>Approved</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? (
                     <TableRow><TableCell colSpan="8" className="text-center py-8">
                       <div className="flex items-center justify-center">
                         <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-slate-900 mr-3"></div> Loading products...
                       </div>
                     </TableCell></TableRow>
                  ) : products.length === 0 ? (
                    <TableRow><TableCell colSpan="8" className="text-center py-8">No products found for the selected filters.</TableCell></TableRow>
                  ) : products.map(product => (
                      <TableRow key={product.id} data-state={selectedProductIds.includes(product.id) && "selected"}>
                        <TableCell className="px-4">
                          <Checkbox
                            checked={selectedProductIds.includes(product.id)}
                            onCheckedChange={() => handleSelectOne(product.id)}
                            aria-label={`Select product ${product.name}`}
                          />
                        </TableCell>
                        <TableCell className="font-medium">{product.name}</TableCell>
                        <TableCell>${product.wholesale_price?.toFixed(2)}</TableCell>
                        <TableCell>{product.distributor}</TableCell>
                        <TableCell><Badge variant="secondary">{product.availability}</Badge></TableCell>
                        <TableCell>
                          {product.in_stock ? <CheckCircle2 className="w-5 h-5 text-green-500" /> : <XCircle className="w-5 h-5 text-red-500" />}
                        </TableCell>
                        <TableCell>
                          {product.approved ? <ShieldCheck className="w-5 h-5 text-green-500" /> : <ShieldAlert className="w-5 h-5 text-yellow-500" />}
                        </TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon"><MoreHorizontal className="w-4 h-4" /></Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => handleEditProduct(product)}><Edit className="w-4 h-4 mr-2" />Edit</DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleOpenAllocation(product)}>
                                <BarChart4 className="w-4 h-4 mr-2" />
                                Calculate Allocations
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem onClick={() => handleDeleteProduct(product)} className="text-red-600 focus:text-red-500"><Trash2 className="w-4 h-4 mr-2" />Delete</DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
          <CardFooter>
            {totalProducts > 0 && (
              <PaginationControls
                totalItems={totalProducts}
                itemsPerPage={itemsPerPage}
                setItemsPerPage={setItemsPerPage}
                currentPage={currentPage}
                setCurrentPage={setCurrentPage}
                className="w-full"
              />
            )}
          </CardFooter>
        </Card>
      </div>

      {isModalOpen && (
        <ProductFormModal
          product={editingProduct}
          onClose={() => setIsModalOpen(false)}
          onSave={() => {
            setIsModalOpen(false);
            loadProducts();
          }}
        />
      )}
      
      {allocationModal.isOpen && (
        <AllocationModal
          product={allocationModal.product}
          isOpen={allocationModal.isOpen}
          onClose={() => setAllocationModal({ isOpen: false, product: null })}
          onComplete={loadProducts}
        />
      )}

      <ConfirmationDialog
        open={confirmDialog.open}
        onOpenChange={(open) => setConfirmDialog(prev => ({ ...prev, open }))}
        title={confirmDialog.title}
        description={confirmDialog.description}
        onConfirm={confirmDialog.onConfirm}
        confirmText={confirmDialog.confirmText || "Confirm"}
        variant={confirmDialog.variant}
      />
    </div>
  );
}
