
import React, { useState, useEffect, useCallback } from "react";
import { Request } from "@/api/entities";
import { useUser } from "@/layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import ConfirmationDialog from "@/components/ui/ConfirmationDialog";
import { MoreHorizontal, Edit, Trash2, Package, Save } from "lucide-react";
import { toast } from "sonner";
import PaginationControls from "@/components/ui/PaginationControls";
import { proxyUserRequestActions } from "@/api/functions";

export default function MyRequests() {
  const { user, loading: userLoading } = useUser();
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);

  // State for modals
  const [editingRequest, setEditingRequest] = useState(null);
  const [quantity, setQuantity] = useState(0);
  const [deletingRequest, setDeletingRequest] = useState(null);
  const [saving, setSaving] = useState(false);

  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(25);

  const loadPageData = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const requestData = await Request.filter({
        member_id: user.id,
      }, "-created_date");
      setRequests(requestData);
    } catch (error) {
      console.error("Error loading data:", error);
      toast.error("Failed to load your requests.");
    } finally {
      setLoading(false);
    }
  }, [user]); // 'user' is a dependency for useCallback

  useEffect(() => {
    if (user) {
        loadPageData();
    } else if (!userLoading) {
        // If user loading is finished and there's no user, stop loading.
        setLoading(false);
    }
  }, [user, userLoading, loadPageData]); // 'loadPageData' is now a stable dependency

  const handleOpenEdit = (request) => {
    setEditingRequest(request);
    setQuantity(request.quantity);
  };

  const handleUpdateQuantity = async () => {
    if (quantity < 1) {
      toast.error("Quantity must be at least 1.");
      return;
    }
    setSaving(true);
    const impersonationDataString = sessionStorage.getItem('impersonationData');

    try {
      if (impersonationDataString) {
        const impersonationToken = JSON.parse(impersonationDataString);
        await proxyUserRequestActions({
          action: 'updateQuantity',
          payload: { requestId: editingRequest.id, quantity },
          impersonationToken
        });
      } else {
        await Request.update(editingRequest.id, { quantity });
      }
      toast.success("Request quantity updated.");
      setEditingRequest(null);
      loadPageData();
    } catch (error) {
      toast.error("Failed to update quantity.");
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteRequest = async () => {
    const impersonationDataString = sessionStorage.getItem('impersonationData');
    try {
      if (impersonationDataString) {
        const impersonationToken = JSON.parse(impersonationDataString);
        await proxyUserRequestActions({
          action: 'delete',
          payload: { requestId: deletingRequest.id },
          impersonationToken
        });
      } else {
        await Request.delete(deletingRequest.id);
      }
      toast.success("Request has been deleted.");
      setDeletingRequest(null);
      loadPageData();
    } catch (error) {
      toast.error("Failed to delete request.");
    }
  };

  const paginatedRequests = requests.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  return (
    <div className="p-6 md:p-8 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">My Product Requests</h1>
          <p className="text-slate-600">Review and manage your product requests before they are invoiced.</p>
        </div>

        <Card className="bg-white border-0 shadow-sm">
          <CardHeader>
            <CardTitle>My Requests ({requests.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Product</TableHead>
                    <TableHead>Requested Quantity</TableHead>
                    <TableHead>Price at Request</TableHead>
                    <TableHead>Request Date</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? (
                    <TableRow>
                      <TableCell colSpan="5" className="text-center py-8">
                        Loading your requests...
                      </TableCell>
                    </TableRow>
                  ) : paginatedRequests.length > 0 ? (
                    paginatedRequests.map(req => (
                      <TableRow key={req.id}>
                        <TableCell className="font-medium">{req.product_name}</TableCell>
                        <TableCell>{req.quantity}</TableCell>
                        <TableCell>
                          ${req.wholesale_price.toFixed(2)}
                        </TableCell>
                        <TableCell>{new Date(req.created_date).toLocaleDateString()}</TableCell>
                        <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <MoreHorizontal className="w-4 h-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={() => handleOpenEdit(req)}>
                                  <Edit className="w-4 h-4 mr-2" />
                                  Change Quantity
                                </DropdownMenuItem>
                                <DropdownMenuItem 
                                  onClick={() => setDeletingRequest(req)} 
                                  className="text-red-500 focus:text-red-500 focus:bg-red-50"
                                >
                                  <Trash2 className="w-4 h-4 mr-2" />
                                  Delete Request
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan="5" className="text-center py-16">
                        <Package className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                        <h3 className="font-semibold text-slate-800">No Open Requests</h3>
                        <p className="text-slate-500 text-sm">You haven't requested any products yet.</p>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
           <PaginationControls
              totalItems={requests.length}
              itemsPerPage={itemsPerPage}
              setItemsPerPage={setItemsPerPage}
              currentPage={currentPage}
              setCurrentPage={setCurrentPage}
            />
        </Card>

        {/* Edit Quantity Dialog */}
        {editingRequest && (
          <Dialog open={!!editingRequest} onOpenChange={() => setEditingRequest(null)}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Change Request Quantity</DialogTitle>
                <DialogDescription>
                  Update the requested quantity for <strong>{editingRequest.product_name}</strong>.
                </DialogDescription>
              </DialogHeader>
              <div className="py-4">
                <Label htmlFor="quantity">Quantity</Label>
                <Input
                  id="quantity"
                  type="number"
                  min="1"
                  value={quantity}
                  onChange={(e) => setQuantity(parseInt(e.target.value) || 1)}
                  className="mt-2"
                />
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setEditingRequest(null)}>Cancel</Button>
                <Button onClick={handleUpdateQuantity} disabled={saving} className="bg-green-600 hover:bg-green-700 text-white">
                  {saving ? 'Saving...' : <><Save className="w-4 h-4 mr-2"/>Save</>}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}

        {/* Delete Confirmation Dialog */}
        <ConfirmationDialog
          open={!!deletingRequest}
          onOpenChange={() => setDeletingRequest(null)}
          title="Delete Product Request"
          description={`Are you sure you want to delete your request for "${deletingRequest?.product_name}"? This action cannot be undone.`}
          onConfirm={handleDeleteRequest}
          confirmText="Yes, Delete Request"
          variant="destructive"
        />
      </div>
    </div>
  );
}
