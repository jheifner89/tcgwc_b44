import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { XCircle, ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function MembershipCancelled() {
  return (
    <div className="bg-gradient-to-b from-slate-50 to-slate-100 min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <Card className="bg-white rounded-2xl shadow-xl border-0 max-w-lg w-full">
        <CardHeader className="p-8 text-center">
          <div className="w-16 h-16 bg-red-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <XCircle className="w-8 h-8 text-red-600" />
          </div>
          <CardTitle className="text-3xl font-extrabold text-slate-900">
            Payment Cancelled
          </CardTitle>
        </CardHeader>
        <CardContent className="p-8 pt-0 text-center">
          <p className="text-lg text-slate-600 mb-6">
            Your membership signup was cancelled. No charges were made to your account.
          </p>
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-6">
            <p className="text-amber-800 text-sm">
              You can try again anytime or contact support if you need assistance.
            </p>
          </div>
          <Link to={createPageUrl("Membership")}>
            <Button className="w-full h-12 rounded-xl bg-slate-900 hover:bg-slate-800 text-lg font-semibold">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Try Again
            </Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}