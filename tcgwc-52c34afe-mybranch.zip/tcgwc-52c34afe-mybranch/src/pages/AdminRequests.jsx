
import React, { useState, useEffect } from "react";
import { Request } from "@/api/entities";
import { User } from "@/api/entities";
import { Invoice } from "@/api/entities";
import { InvoiceLineItem } from "@/api/entities";
import AdminHeader from "@/components/admin/AdminHeader";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { MoreHorizontal, Edit, Trash2, Save, AlertCircle, FileText, ChevronDown } from "lucide-react";
import { toast } from "sonner";
import { createMessage } from "@/components/utils/messaging";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import ConfirmationDialog from "@/components/ui/ConfirmationDialog";
import PaginationControls from "@/components/ui/PaginationControls";

export default function AdminRequests() {
    const [requests, setRequests] = useState([]);
    const [userMap, setUserMap] = useState({}); // Added userMap state
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();
    
    // Selection state
    const [selectedRequestIds, setSelectedRequestIds] = useState([]);
    const [selectedMemberId, setSelectedMemberId] = useState(null);

    // Modal states
    const [editingRequest, setEditingRequest] = useState(null);
    const [deletingRequest, setDeletingRequest] = useState(null);
    const [newQuantity, setNewQuantity] = useState(0);
    const [reason, setReason] = useState("");
    const [confirmingInvoice, setConfirmingInvoice] = useState(false);
    const [saving, setSaving] = useState(false);
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(25);

    useEffect(() => {
        loadRequests();
    }, []);

    const loadRequests = async (showLoading = true) => {
        if (showLoading) setLoading(true);
        try {
            const currentUser = await User.me();
            if (currentUser.role !== 'admin') {
                toast.error("Access Denied");
                return;
            }
            // Fetch requests and all users concurrently
            const [requestData, userData] = await Promise.all([
              Request.list("-created_date"),
              User.list()
            ]);

            // Create a map for quick user lookup by ID
            const users = userData.reduce((acc, user) => {
              acc[user.id] = user;
              return acc;
            }, {});
            
            setUserMap(users); // Set the user map
            setRequests(requestData);
            setCurrentPage(1); // Reset to first page on new data load
        } catch (error) {
            toast.error("Failed to load requests.");
        } finally {
            if (showLoading) setLoading(false);
        }
    };
    
    const handleSelectRequest = (requestId, memberId) => {
        if (selectedRequestIds.length > 0 && memberId !== selectedMemberId) {
            toast.error("You can only select requests for the same member.");
            return;
        }

        const newSelectedIds = [...selectedRequestIds];
        const currentIndex = newSelectedIds.indexOf(requestId);

        if (currentIndex === -1) {
            newSelectedIds.push(requestId);
        } else {
            newSelectedIds.splice(currentIndex, 1);
        }

        setSelectedRequestIds(newSelectedIds);
        setSelectedMemberId(newSelectedIds.length > 0 ? memberId : null);
    };

    const handleConvertToInvoice = () => {
        if (selectedRequestIds.length === 0) {
            toast.error("Please select at least one request.");
            return;
        }
        setConfirmingInvoice(true);
    };

    const confirmConvertToInvoice = async () => {
        setSaving(true);
        setConfirmingInvoice(false);
        toast.info("Creating invoice...");

        try {
            // Get the requests to process
            const requestsToProcess = requests.filter(r => selectedRequestIds.includes(r.id));
            
            if (requestsToProcess.length === 0) {
                throw new Error("No requests selected");
            }

            // Ensure all requests belong to the same member
            const memberId = requestsToProcess[0].member_id;
            if (!requestsToProcess.every(r => r.member_id === memberId)) {
                throw new Error("All requests must belong to the same member");
            }

            // Get member information
            const member = userMap[memberId];
            if (!member) {
                throw new Error("Member information not found");
            }

            // Calculate totals and prepare line items
            let subtotal = 0;
            const lineItemsData = requestsToProcess.map(reqItem => {
                const totalPrice = reqItem.quantity * reqItem.wholesale_price;
                subtotal += totalPrice;
                return {
                    product_id: reqItem.product_id,
                    sku: reqItem.product_sku || 'N/A', 
                    product_name: reqItem.product_name,
                    quantity: reqItem.quantity,
                    unit_price: reqItem.wholesale_price,
                    total_price: totalPrice,
                };
            });

            // Create the invoice
            const newInvoice = await Invoice.create({
                invoice_number: `INV-${Date.now()}`,
                member_id: memberId,
                member_email: member.email,
                status: 'draft',
                subtotal: subtotal,
                total: subtotal,
                due_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            });

            // Create line items
            for (const itemData of lineItemsData) {
                await InvoiceLineItem.create({
                    ...itemData,
                    invoice_id: newInvoice.id
                });
            }

            // Delete the original requests (as admin, you should have permission to delete any request)
            for (const requestId of selectedRequestIds) {
                try {
                    await Request.delete(requestId);
                } catch (error) {
                    console.error(`Failed to delete request ${requestId}:`, error);
                    // Continue with other deletions
                }
            }

            toast.success(`Invoice #${newInvoice.invoice_number} created successfully.`);
            setSelectedRequestIds([]);
            setSelectedMemberId(null);
            
            // Navigate to the new invoice
            navigate(createPageUrl(`AdminEditInvoice?id=${newInvoice.id}`));

        } catch (error) {
            console.error("Invoice creation error:", error);
            toast.error(error.message || "Failed to create invoice.");
        } finally {
            setSaving(false);
            // Reload requests to reflect changes
            await loadRequests(false);
        }
    };

    const handleEditRequest = (request) => {
        setEditingRequest(request);
        setNewQuantity(request.quantity);
        setReason("");
    };

    const handleDeleteRequest = (request) => {
        setDeletingRequest(request);
        setReason("");
    };

    const confirmEditRequest = async () => {
        if (!reason.trim()) {
            toast.error("Please provide a reason for the quantity change.");
            return;
        }
        
        if (newQuantity < 1) {
            toast.error("Quantity must be at least 1.");
            return;
        }

        setSaving(true);
        try {
            const oldQuantity = editingRequest.quantity;
            
            // Update the request
            await Request.update(editingRequest.id, { quantity: newQuantity });
            
            // Create message for the user
            await createMessage({
                userId: editingRequest.member_id,
                title: "Request Quantity Updated",
                content: `Your request for ${editingRequest.product_name} has had its quantity adjusted from ${oldQuantity} to ${newQuantity} for the following reason: ${reason}`
            });
            
            toast.success("Request quantity updated and user notified.");
            setEditingRequest(null);
            
            // Refresh the requests list
            await loadRequests(false);
        } catch (error) {
            console.error("Error updating request:", error);
            toast.error("Failed to update request.");
        } finally {
            setSaving(false);
        }
    };

    const confirmDeleteRequest = async () => {
        if (!reason.trim()) {
            toast.error("Please provide a reason for deleting this request.");
            return;
        }

        setSaving(true);
        try {
            // Create message for the user before deleting
            await createMessage({
                userId: deletingRequest.member_id,
                title: "Request Deleted",
                content: `Your request for ${deletingRequest.product_name} has been deleted for the following reason: ${reason}`
            });
            
            // Delete the request
            await Request.delete(deletingRequest.id);
            
            toast.success("Request deleted and user notified.");
            setDeletingRequest(null);
            
            // Refresh the requests list
            await loadRequests(false);
        } catch (error) {
            console.error("Error deleting request:", error);
            toast.error("Failed to delete request.");
        } finally {
            setSaving(false);
        }
    };

    const paginatedRequests = requests.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

    return (
        <div className="p-6 md:p-8">
            <div className="max-w-7xl mx-auto">
                <h1 className="text-3xl font-bold text-slate-900 mb-2">All Requests</h1>
                <AdminHeader />
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between">
                        <CardTitle>All Member Requests ({requests.length})</CardTitle>
                        <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                                <Button variant="outline" disabled={selectedRequestIds.length === 0 || saving}>
                                    Bulk Actions <ChevronDown className="w-4 h-4 ml-2" />
                                </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={handleConvertToInvoice} disabled={selectedRequestIds.length === 0 || saving}>
                                    <FileText className="w-4 h-4 mr-2" />
                                    Convert to Invoice
                                </DropdownMenuItem>
                            </DropdownMenuContent>
                        </DropdownMenu>
                    </CardHeader>
                    <CardContent>
                        <div className="overflow-x-auto">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead className="w-12"></TableHead>
                                        <TableHead>Member</TableHead>
                                        <TableHead>Product</TableHead>
                                        <TableHead>Quantity</TableHead>
                                        <TableHead>Wholesale Price</TableHead>
                                        <TableHead>Date</TableHead>
                                        <TableHead className="text-right">Actions</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {loading ? (
                                        <TableRow>
                                            <TableCell colSpan="7" className="text-center py-8">Loading...</TableCell>
                                        </TableRow>
                                    ) : paginatedRequests.length > 0 ? (
                                        paginatedRequests.map(req => (
                                            <TableRow 
                                                key={req.id} 
                                                className={selectedRequestIds.includes(req.id) ? "bg-slate-50" : ""}
                                            >
                                                <TableCell>
                                                    <Checkbox
                                                        checked={selectedRequestIds.includes(req.id)}
                                                        onCheckedChange={() => handleSelectRequest(req.id, req.member_id)}
                                                        disabled={selectedMemberId && req.member_id !== selectedMemberId}
                                                    />
                                                </TableCell>
                                                {/* Display member's full name or email using the userMap */}
                                                <TableCell className="font-medium">{userMap[req.member_id]?.full_name || userMap[req.member_id]?.email || 'Unknown User'}</TableCell>
                                                <TableCell>{req.product_name}</TableCell>
                                                <TableCell>{req.quantity}</TableCell>
                                                <TableCell>
                                                    ${req.wholesale_price.toFixed(2)}
                                                </TableCell>
                                                <TableCell>{new Date(req.created_date).toLocaleDateString()}</TableCell>
                                                <TableCell className="text-right">
                                                    <DropdownMenu>
                                                        <DropdownMenuTrigger asChild>
                                                            <Button variant="ghost" size="icon">
                                                                <MoreHorizontal className="w-4 h-4" />
                                                            </Button>
                                                        </DropdownMenuTrigger>
                                                        <DropdownMenuContent align="end">
                                                            <DropdownMenuItem onClick={() => handleEditRequest(req)}>
                                                                <Edit className="w-4 h-4 mr-2" />
                                                                Change Quantity
                                                            </DropdownMenuItem>
                                                            <DropdownMenuItem 
                                                                onClick={() => handleDeleteRequest(req)}
                                                                className="text-red-600 focus:text-red-500"
                                                            >
                                                                <Trash2 className="w-4 h-4 mr-2" />
                                                                Delete Request
                                                            </DropdownMenuItem>
                                                        </DropdownMenuContent>
                                                    </DropdownMenu>
                                                </TableCell>
                                            </TableRow>
                                        ))
                                    ) : (
                                        <TableRow>
                                            <TableCell colSpan="7" className="text-center py-8">No open requests found.</TableCell>
                                        </TableRow>
                                    )}
                                </TableBody>
                            </Table>
                        </div>
                    </CardContent>
                    <PaginationControls
                        totalItems={requests.length}
                        itemsPerPage={itemsPerPage}
                        setItemsPerPage={setItemsPerPage}
                        currentPage={currentPage}
                        setCurrentPage={setCurrentPage}
                    />
                </Card>

                {/* Confirmation Dialog for Invoice Creation */}
                <ConfirmationDialog
                    open={confirmingInvoice}
                    onOpenChange={setConfirmingInvoice}
                    title="Convert to Invoice"
                    description={`This will create a new draft invoice and delete the ${selectedRequestIds.length} selected request(s). Are you sure you want to continue?`}
                    onConfirm={confirmConvertToInvoice}
                    confirmText="Yes, Create Invoice"
                    variant="default"
                />

                {/* Edit Request Quantity Modal */}
                {editingRequest && (
                    <Dialog open={!!editingRequest} onOpenChange={() => setEditingRequest(null)}>
                        <DialogContent>
                            <DialogHeader>
                                <DialogTitle>Change Request Quantity</DialogTitle>
                                <DialogDescription>
                                    Update the quantity for <strong>{editingRequest.product_name}</strong> requested by <strong>{userMap[editingRequest.member_id]?.full_name || userMap[editingRequest.member_id]?.email || 'this user'}</strong>
                                </DialogDescription>
                            </DialogHeader>
                            <div className="space-y-4">
                                <div>
                                    <Label htmlFor="quantity">New Quantity</Label>
                                    <Input
                                        id="quantity"
                                        type="number"
                                        min="1"
                                        value={newQuantity}
                                        onChange={(e) => setNewQuantity(parseInt(e.target.value) || 1)}
                                    />
                                    <p className="text-xs text-slate-500 mt-1">Current quantity: {editingRequest.quantity}</p>
                                </div>
                                <div>
                                    <Label htmlFor="reason">Reason for Change *</Label>
                                    <Textarea
                                        id="reason"
                                        value={reason}
                                        onChange={(e) => setReason(e.target.value)}
                                        placeholder="Explain why the quantity is being changed..."
                                        className="mt-1"
                                    />
                                </div>
                            </div>
                            <DialogFooter>
                                <Button variant="outline" onClick={() => setEditingRequest(null)}>
                                    Cancel
                                </Button>
                                <Button onClick={confirmEditRequest} disabled={saving} className="bg-green-600 hover:bg-green-700">
                                    {saving ? (
                                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                                    ) : (
                                        <Save className="w-4 h-4 mr-2" />
                                    )}
                                    Update Quantity
                                </Button>
                            </DialogFooter>
                        </DialogContent>
                    </Dialog>
                )}

                {/* Delete Request Modal */}
                {deletingRequest && (
                    <Dialog open={!!deletingRequest} onOpenChange={() => setDeletingRequest(null)}>
                        <DialogContent>
                            <DialogHeader>
                                <DialogTitle className="flex items-center gap-2">
                                    <AlertCircle className="w-5 h-5 text-red-500" />
                                    Delete Request
                                </DialogTitle>
                                <DialogDescription>
                                    You are about to delete the request for <strong>{deletingRequest.product_name}</strong> by <strong>{userMap[deletingRequest.member_id]?.full_name || userMap[deletingRequest.member_id]?.email || 'this user'}</strong>. This action cannot be undone.
                                </DialogDescription>
                            </DialogHeader>
                            <div className="space-y-4">
                                <div>
                                    <Label htmlFor="deleteReason">Reason for Deletion *</Label>
                                    <Textarea
                                        id="deleteReason"
                                        value={reason}
                                        onChange={(e) => setReason(e.target.value)}
                                        placeholder="Explain why this request is being deleted..."
                                        className="mt-1"
                                    />
                                </div>
                            </div>
                            <DialogFooter>
                                <Button variant="outline" onClick={() => setDeletingRequest(null)}>
                                    Cancel
                                </Button>
                                <Button variant="destructive" onClick={confirmDeleteRequest} disabled={saving}>
                                    {saving ? (
                                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                                    ) : (
                                        <Trash2 className="w-4 h-4 mr-2" />
                                    )}
                                    Delete Request
                                </Button>
                            </DialogFooter>
                        </DialogContent>
                    </Dialog>
                )}
            </div>
        </div>
    );
}
