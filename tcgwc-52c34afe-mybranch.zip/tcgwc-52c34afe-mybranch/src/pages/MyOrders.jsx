
import React, { useState, useEffect, useCallback } from "react";
import { Order } from "@/api/entities";
import { useUser } from "@/layout"; // Import useUser hook
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Loader2, Package } from "lucide-react"; // Loader2 is still needed for order loading
import { toast } from "sonner";
import PaginationControls from "@/components/ui/PaginationControls";

export default function MyOrders() {
  const { user, loading: userLoading } = useUser(); // Get user and userLoading from useUser hook
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true); // This state is for order loading, not user loading
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(25); // Changed default items per page to 25

  const loadOrders = useCallback(async () => {
    if (!user) { // Ensure user exists before trying to fetch orders
      setLoading(false); // Set loading to false if no user is available
      return;
    }
    setLoading(true);
    try {
      // Fetch orders for the current user's ID
      const orderData = await Order.filter({
        member_id: user.id,
      }, "-created_date");
      setOrders(orderData);
    } catch (error) {
      console.error("Error loading orders:", error); // Changed log message
      toast.error("Failed to load your orders.");
    } finally {
      setLoading(false);
    }
  }, [user]); // Depend on 'user' for useCallback

  useEffect(() => {
    // Only attempt to load orders if user data is available
    if (user) {
      loadOrders();
    } else if (!userLoading) {
      // If user is null and userLoading is false, it means user loading is complete but no user was found.
      // In this case, we stop the loading state for orders as there's no user to fetch orders for.
      setLoading(false);
    }
  }, [user, userLoading, loadOrders]); // Depend on user, userLoading, and loadOrders

  // Renamed function as per outline
  const getStatusColor = (status) => {
    switch (status) {
      case "Invoiced":
      case "Payment Pending":
        return "bg-yellow-100 text-yellow-800";
      case "Paid":
        return "bg-blue-100 text-blue-800";
      case "In Inventory":
        return "bg-purple-100 text-purple-800";
      case "Complete":
        return "bg-green-100 text-green-800";
      case "Cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const paginatedOrders = orders.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  return (
    <div className="p-6 md:p-8 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">My Orders</h1>
          <p className="text-slate-600">Track the status of your product orders from payment to fulfillment.</p>
        </div>

        <Card className="bg-white border-0 shadow-sm">
          <CardHeader>
            <CardTitle>All My Orders ({orders.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Order Date</TableHead>
                    <TableHead>Product</TableHead>
                    <TableHead className="text-center">Total Qty</TableHead>
                    <TableHead className="text-center">Shipped Qty</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Total</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? ( // This `loading` state specifically refers to `orders` loading, not `user` loading
                    <TableRow>
                      <TableCell colSpan="6" className="text-center py-16">
                        <Loader2 className="w-8 h-8 text-slate-400 mx-auto animate-spin" />
                      </TableCell>
                    </TableRow>
                  ) : paginatedOrders.length > 0 ? (
                    paginatedOrders.map(order => (
                      <TableRow key={order.id}>
                        <TableCell>{order.order_date ? new Date(order.order_date).toLocaleDateString() : new Date(order.created_date).toLocaleDateString()}</TableCell>
                        <TableCell className="font-medium">{order.product_name}</TableCell>
                        <TableCell className="text-center">{order.quantity}</TableCell>
                        <TableCell className="text-center">{order.shipped_quantity || 0}</TableCell>
                        <TableCell>
                          <Badge className={getStatusColor(order.status)}>
                            {order.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right font-mono">${order.total_price.toFixed(2)}</TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan="6" className="text-center py-16">
                        <Package className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                        <h3 className="font-semibold text-slate-800">No Orders Found</h3>
                        <p className="text-slate-500 text-sm">Once an invoice is issued, your orders will appear here.</p>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
          {!loading && orders.length > 0 && ( // Only show pagination if there are items and not loading
            <PaginationControls
              totalItems={orders.length}
              itemsPerPage={itemsPerPage}
              setItemsPerPage={setItemsPerPage}
              currentPage={currentPage}
              setCurrentPage={setCurrentPage}
            />
          )}
        </Card>
      </div>
    </div>
  );
}
