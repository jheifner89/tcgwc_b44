
import React, { useState, useEffect, useCallback } from 'react';
import AdminHeader from '@/components/admin/AdminHeader';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Trash2, UserPlus } from 'lucide-react';
import { toast } from 'sonner';
import { cleanupAbandonedUsers } from '@/api/functions';
import ConfirmationDialog from '@/components/ui/ConfirmationDialog';
import { Settings } from "@/api/entities";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { US_STATES } from "@/components/utils/tax";
import { ScrollArea } from "@/components/ui/scroll-area";
import { generateSpendReportPdf } from "@/api/functions";
import { Product } from "@/api/entities";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";


export default function AdminTools() {
  const [loading, setLoading] = useState(true);
  const [isCleaning, setIsCleaning] = useState(false);
  const [showCleanupConfirm, setShowCleanupConfirm] = useState(false);
  const [settings, setSettings] = useState(null);
  const [initialSettings, setInitialSettings] = useState(null);
  const [isSaving, setIsSaving] = useState(false);
  const [isGeneratingReport, setIsGeneratingReport] = useState(false);

  // Existing states
  const [selectedProductLine, setSelectedProductLine] = useState('');
  const [productLines, setProductLines] = useState([]);

  const loadSettings = useCallback(async () => {
    try {
      const allSettings = await Settings.list();
      const currentSettings = {
        tcgwc_fee_percentage: parseFloat(allSettings.find(s => s.setting_key === 'tcgwc_fee_percentage')?.setting_value || '5'),
        dropship_fee_percentage: parseFloat(allSettings.find(s => s.setting_key === 'dropship_fee_percentage')?.setting_value || '0'),
        economic_nexus_states: JSON.parse(allSettings.find(s => s.setting_key === 'economic_nexus_states')?.setting_value || '[]'),
      };
      setSettings(currentSettings);
      setInitialSettings(currentSettings); // Store initial settings for comparison if needed
      setLoading(false); // Set loading to false once settings are loaded
    } catch (error) {
      console.error("Error loading settings:", error);
      toast.error("Failed to load settings.");
      setLoading(false); // Ensure loading is false even on error
    }
  }, []);

  const loadData = useCallback(async () => {
    await loadSettings();

    // Load product lines for the spend report dropdown
    try {
      const allProducts = await Product.list('name', 1000);
      const uniqueLines = [...new Set(allProducts.map(p => p.product_line).filter(Boolean))];
      setProductLines(uniqueLines.sort());
    } catch (error) {
      console.error("Error loading product lines:", error);
      toast.error("Failed to load product lines.");
    }
  }, [loadSettings]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleSaveSettings = async () => {
    if (!settings) return; // Should not happen if loading is handled

    setIsSaving(true);
    try {
      // Helper to save/update a setting
      const saveOrUpdateSetting = async (key, value, description) => {
        const existingSetting = await Settings.filter({ setting_key: key });
        if (existingSetting.length > 0) {
          await Settings.update(existingSetting[0].id, { setting_value: value, description });
        } else {
          await Settings.create({ setting_key: key, setting_value: value, description });
        }
      };

      // Save TCGWC Fee Percentage
      await saveOrUpdateSetting(
        'tcgwc_fee_percentage',
        settings.tcgwc_fee_percentage.toString(),
        "Percentage fee added to invoices when issued"
      );

      // Save Dropship Fee Percentage
      await saveOrUpdateSetting(
        'dropship_fee_percentage',
        settings.dropship_fee_percentage.toString(),
        "Percentage fee added to dropship invoices based on total product value"
      );
      
      // Save nexus states
      await saveOrUpdateSetting(
        'economic_nexus_states',
        JSON.stringify(settings.economic_nexus_states),
        "List of states where the business has economic nexus for sales tax."
      );
      
      toast.success("Settings saved successfully!");
      setInitialSettings({...settings}); // Update initial settings after successful save
    } catch (error) {
      console.error("Error saving settings:", error);
      toast.error("Failed to save settings.");
    } finally {
      setIsSaving(false);
    }
  };

  const handleNexusStateChange = (stateAbbr, isChecked) => {
    setSettings(prevSettings => {
      if (!prevSettings) return null;
      const updatedNexusStates = isChecked
        ? [...prevSettings.economic_nexus_states, stateAbbr]
        : prevSettings.economic_nexus_states.filter(s => s !== stateAbbr);
      return { ...prevSettings, economic_nexus_states: updatedNexusStates };
    });
  };

  const handlePrune = async () => {
    setIsCleaning(true);
    toast.info("Starting user cleanup process...");
    try {
      const response = await cleanupAbandonedUsers();
      if (response.status === 200) {
        const { message, deleted_count } = response.data;
        if (deleted_count > 0) {
          toast.success(message || `Successfully pruned ${deleted_count} user(s).`);
        } else {
          toast.success(message || "No abandoned users found to prune.");
        }
      } else {
        throw new Error(response.data?.error || "Cleanup failed.");
      }
    } catch (error) {
      console.error("Cleanup error:", error);
      toast.error(error.message || "An unexpected error occurred.");
    } finally {
      setIsCleaning(false);
    }
  };

  const handleGenerateSpendReport = async () => {
    if (!selectedProductLine) {
      toast.error("Please select a product line");
      return;
    }

    setIsGeneratingReport(true);
    toast.info("Generating your PDF report...");
    try {
      const response = await generateSpendReportPdf({ productLine: selectedProductLine });
      
      if (response.status === 200) {
        const blob = new Blob([response.data], { type: 'application/pdf' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        const safeProductLine = selectedProductLine.replace(/\s+/g, '-');
        const today = new Date().toISOString().split('T')[0];
        a.download = `spend-report-${safeProductLine}-${today}.pdf`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        a.remove();
        toast.success("Report download started!");
      } else {
        const errorText = await response.data.text();
        const errorJson = JSON.parse(errorText);
        throw new Error(errorJson.error || "Failed to generate report");
      }
    } catch (error) {
      console.error("Report generation error:", error);
      toast.error(error.message || "Failed to generate spend report. Please try again.");
    } finally {
      setIsGeneratingReport(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="w-10 h-10 border-4 border-gray-200 border-t-transparent rounded-full animate-spin"></div>
        <p className="ml-4 text-lg text-gray-700">Loading admin tools...</p>
      </div>
    );
  }

  return (
    <div className="p-6 md:p-8">
        <div className="max-w-7xl mx-auto">
            <h1 className="text-3xl font-bold text-slate-900 mb-2">Admin Tools</h1>
            <AdminHeader />
            <div className="grid gap-6 mt-8">
                {/* User Management */}
                <Card>
                    <CardHeader>
                        <CardTitle>User Management</CardTitle>
                        <CardDescription>
                            Manage user accounts and invitations.
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                            <div className="flex items-start gap-3">
                                <UserPlus className="w-5 h-5 text-blue-600 mt-0.5" />
                                <div>
                                    <h3 className="font-medium text-blue-900">Invite New Users</h3>
                                    <p className="text-blue-800 text-sm mt-1">
                                        To add new users to the system, use the <strong>Dashboard → Users → Invite User</strong> functionality. 
                                        This will send them an invitation email and create their account when they accept.
                                    </p>
                                    <p className="text-blue-700 text-xs mt-2">
                                        Note: User records cannot be created directly - they must be invited through the proper invitation system.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                {/* Settings Section */}
                <Card>
                    <CardHeader>
                        <CardTitle>Business Settings</CardTitle>
                        <CardDescription>
                            Configure invoice fees and tax settings.
                        </CardDescription>
                    </CardHeader>
                    <CardContent className="grid md:grid-cols-2 gap-8">
                        <div className="space-y-4">
                            <h3 className="font-medium">Invoice Settings</h3>
                            <div>
                                <Label htmlFor="tcgwc-fee">TCGWC Fee Percentage</Label>
                                <div className="flex gap-2 items-center mt-1">
                                    <Input
                                        id="tcgwc-fee"
                                        type="number"
                                        min="0"
                                        max="100"
                                        step="0.1"
                                        value={settings?.tcgwc_fee_percentage || ''}
                                        onChange={(e) => setSettings(prev => ({...prev, tcgwc_fee_percentage: parseFloat(e.target.value) || 0}))}
                                        className="w-24"
                                    />
                                    <span className="text-sm text-slate-600">%</span>
                                </div>
                                <p className="text-xs text-slate-500 mt-1">
                                    This percentage will be added as a fee to all issued invoices.
                                </p>
                            </div>
                             <div>
                                <Label htmlFor="dropship-fee">Dropship Fee Percentage</Label>
                                <div className="flex gap-2 items-center mt-1">
                                    <Input
                                        id="dropship-fee"
                                        type="number"
                                        min="0"
                                        max="100"
                                        step="0.1"
                                        value={settings?.dropship_fee_percentage || ''}
                                        onChange={(e) => setSettings(prev => ({...prev, dropship_fee_percentage: parseFloat(e.target.value) || 0}))}
                                        className="w-24"
                                    />
                                    <span className="text-sm text-slate-600">%</span>
                                </div>
                                <p className="text-xs text-slate-500 mt-1">
                                    Fee applied to dropship invoices, based on the total product value.
                                </p>
                            </div>
                            <Button
                                onClick={handleSaveSettings}
                                disabled={isSaving || !settings}
                                size="sm"
                            >
                                {isSaving ? "Saving..." : "Save All Settings"}
                            </Button>
                        </div>

                        <div className="space-y-4">
                           <h3 className="font-medium">Economic Nexus States</h3>
                           <p className="text-sm text-slate-500">Select all states where you are required to collect sales tax.</p>
                           <ScrollArea className="h-48 w-full border rounded-md p-4">
                                <div className="grid grid-cols-3 gap-4">
                                    {US_STATES.map(state => (
                                        <div key={state.abbreviation} className="flex items-center space-x-2">
                                            <Checkbox
                                                id={state.abbreviation}
                                                checked={settings?.economic_nexus_states?.includes(state.abbreviation) || false}
                                                onCheckedChange={(checked) => handleNexusStateChange(state.abbreviation, checked)}
                                            />
                                            <label
                                                htmlFor={state.abbreviation}
                                                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                                            >
                                                {state.name}
                                            </label>
                                        </div>
                                    ))}
                                </div>
                           </ScrollArea>
                        </div>
                    </CardContent>
                </Card>

                {/* Spend Report Section */}
                <Card>
                    <CardHeader>
                        <CardTitle>Spend Report</CardTitle>
                        <CardDescription>
                            Generate a PDF of spending rankings by product line for the last 180 days.
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="flex items-end gap-4">
                            <div className="flex-1">
                                <Label htmlFor="product-line-select">Product Line</Label>
                                <Select 
                                    value={selectedProductLine} 
                                    onValueChange={setSelectedProductLine}
                                >
                                    <SelectTrigger className="mt-1">
                                        <SelectValue placeholder="Select a product line" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {productLines.map(line => (
                                            <SelectItem key={line} value={line}>{line}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                            <div>
                                <Button 
                                    onClick={handleGenerateSpendReport}
                                    disabled={isGeneratingReport || !selectedProductLine}
                                    className="mt-6"
                                >
                                    {isGeneratingReport ? (
                                        <>
                                            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                                            Generating...
                                        </>
                                    ) : (
                                        "Generate Report"
                                    )}
                                </Button>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                {/* Existing Data Cleanup Tools Card */}
                <Card>
                    <CardHeader>
                        <CardTitle>Data Cleanup Tools</CardTitle>
                        <CardDescription>
                            Run these tools periodically to maintain system health and remove obsolete data.
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 border rounded-lg gap-4">
                            <div>
                                <h3 className="font-semibold">Prune Abandoned Signups</h3>
                                <p className="text-sm text-slate-600 max-w-lg">
                                    This will permanently delete user accounts that were created more than 24 hours ago but have not verified their email and have not completed their profile setup.
                                </p>
                            </div>
                            <Button
                                variant="destructive"
                                onClick={() => setShowCleanupConfirm(true)}
                                disabled={isCleaning}
                                className="w-full sm:w-auto flex-shrink-0"
                            >
                                {isCleaning ? (
                                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                                ) : (
                                    <Trash2 className="w-4 h-4 mr-2" />
                                )}
                                Prune Users
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            </div>
            <ConfirmationDialog
                open={showCleanupConfirm}
                onOpenChange={setShowCleanupConfirm}
                title="Confirm User Pruning"
                description="This will permanently delete all unverified, incomplete user accounts older than 24 hours. This action cannot be undone."
                onConfirm={handlePrune}
                confirmText="Yes, Prune Users"
                variant="destructive"
            />
        </div>
    </div>
  );
}
