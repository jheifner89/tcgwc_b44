
import React, { useState, useEffect, useCallback } from "react";
import { Invoice } from "@/api/entities";
import { useUser } from "@/layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import {
  Eye,
  FileDown,
  CreditCard,
  Banknote,
  DollarSign,
  Receipt,
  MoreHorizontal,
  Loader2
} from "lucide-react";
import { toast } from "sonner";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { createInvoicePayment } from "@/api/functions";
import { downloadInvoicePdf } from "@/api/functions";
import PaginationControls from "@/components/ui/PaginationControls";

export default function MyInvoices() {
  const { user, loading: userLoading } = useUser();
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [payingInvoice, setPayingInvoice] = useState(null);
  const [downloading, setDownloading] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const navigate = useNavigate();
  const location = useLocation();

  // Show toasts based on URL params from payment redirects
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    if (params.get('payment') === 'success') {
      toast.success("Payment successful!");
      // Clean up URL
      navigate(location.pathname, { replace: true });
    } else if (params.get('payment') === 'cancelled') {
      toast.info("Payment was cancelled.");
      navigate(location.pathname, { replace: true });
    }
  }, [location, navigate]);

  const loadInvoices = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      // Replaced User.me() and filter logic for user.id
      const invoiceData = await Invoice.filter(
          { member_id: user.id },
          "-created_date",
          1000 // High limit, pagination is client-side
      );
      // Filter out draft invoices - only show issued, paid, overdue, cancelled, processing_payment
      const filteredInvoices = invoiceData.filter(inv => inv.status !== 'draft');
      setInvoices(filteredInvoices);
    } catch (error) {
      console.error("Error loading invoices:", error);
      toast.error("Failed to load your invoices.");
    } finally {
      setLoading(false);
    }
  }, [user]); // Only re-create if user changes

  // Load invoices when user data is available or on page/items per page change
  useEffect(() => {
    if (user) {
        loadInvoices();
    } else if (!userLoading) { // If user is null and no longer loading, set loading to false
        setLoading(false);
    }
  }, [user, userLoading, currentPage, itemsPerPage, loadInvoices]); // Added loadInvoices to dependencies

  const getStatusBadge = (status) => {
    const statusClasses = {
      draft: "bg-gray-100 text-gray-800",
      issued: "bg-blue-100 text-blue-800",
      paid: "bg-green-100 text-green-800",
      overdue: "bg-red-100 text-red-800",
      cancelled: "bg-red-600 text-white",
      processing_payment: "bg-yellow-100 text-yellow-800"
    };
    return statusClasses[status?.toLowerCase()] || "bg-gray-100 text-gray-800";
  };

  const isOverdue = (invoice) => {
    if (invoice.status === 'paid' || invoice.status === 'cancelled') return false;
    if (!invoice.due_date) return false;
    return new Date(invoice.due_date) < new Date();
  };

  // Renamed handlePayment to handlePay, updated signature
  const handlePay = async (invoiceId, method) => {
    // Note: processingPayment state removed as per outline, relying on redirects for feedback.
    try {
      const response = await createInvoicePayment({
          invoiceId: invoiceId,
          paymentMethod: method,
      });

      if (response.status === 200) {
        const { checkout_url } = response.data;
        if (checkout_url) {
          window.location.href = checkout_url;
        } else {
          throw new Error("No checkout URL received");
        }
      } else {
        throw new Error(response.data?.error || "Failed to create payment session");
      }
    } catch (error) {
      console.error("Payment Error:", error);
      toast.error(`Failed to initiate ${method.toUpperCase()} payment. Please try again.`);
    }
  };

  const handleDownloadPdf = async (invoice) => {
    setDownloading(invoice.id); // Updated state name
    try {
      const response = await downloadInvoicePdf({ invoiceId: invoice.id });

      if (response.status === 200) {
        // Ensure the response data is treated as a Blob for PDF
        const blob = new Blob([response.data], { type: 'application/pdf' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `invoice-${invoice.invoice_number}.pdf`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        a.remove();
        toast.success("Invoice PDF downloaded successfully!");
      } else {
        throw new Error("Failed to download PDF");
      }
    } catch (error) {
      console.error("Download error:", error);
      toast.error("Failed to download invoice PDF. Please try again.");
    } finally {
      setDownloading(null);
    }
  };

  const unpaidInvoices = invoices.filter(inv => !['paid', 'cancelled'].includes(inv.status));
  const totalOwed = unpaidInvoices.reduce((sum, inv) => sum + inv.total, 0);

  // Calculate paginated invoices
  const paginatedInvoices = invoices.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  if (loading || userLoading) { // Combined loading states
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-64"></div>
          <div className="h-32 bg-gray-200 rounded"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 md:p-8 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">My Invoices</h1>
          <p className="text-slate-600">View and manage your invoices and payment history.</p>
        </div>

        {/* Summary Cards */}
        {unpaidInvoices.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card className="bg-white border-0 shadow-sm">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-500 mb-1">Total Owed</p>
                    <p className="text-2xl font-bold text-slate-900">${totalOwed.toFixed(2)}</p>
                  </div>
                  <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center">
                    <DollarSign className="w-6 h-6 text-red-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white border-0 shadow-sm">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-500 mb-1">Unpaid Invoices</p>
                    <p className="text-2xl font-bold text-slate-900">{unpaidInvoices.length}</p>
                  </div>
                  <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                    <Receipt className="w-6 h-6 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white border-0 shadow-sm">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-500 mb-1">Account Credit</p>
                    <p className="text-2xl font-bold text-slate-900">${(user?.account_credit || 0).toFixed(2)}</p>
                  </div>
                  <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                    <CreditCard className="w-6 h-6 text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Invoices Table */}
        <Card className="bg-white border-0 shadow-sm">
          <CardHeader>
            <CardTitle>Invoice History ({invoices.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Invoice #</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Total</TableHead>
                    <TableHead>Issue Date</TableHead>
                    <TableHead>Due Date</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? (
                    <TableRow>
                      <TableCell colSpan="6" className="text-center py-16">
                        <Loader2 className="w-8 h-8 text-slate-400 mx-auto animate-spin" />
                      </TableCell>
                    </TableRow>
                  ) : paginatedInvoices.length > 0 ? (
                    paginatedInvoices.map(invoice => (
                      <TableRow key={invoice.id} className={isOverdue(invoice) ? "bg-red-50" : ""}>
                        <TableCell className="font-medium">
                          {invoice.invoice_number}
                        </TableCell>
                        <TableCell>
                          <Badge className={getStatusBadge(invoice.status)}>
                            {isOverdue(invoice) ? 'overdue' : invoice.status.replace('_', ' ')}
                          </Badge>
                        </TableCell>
                        <TableCell className="font-semibold">${invoice.total.toFixed(2)}</TableCell>
                        <TableCell>
                          {invoice.issued_date ? new Date(invoice.issued_date).toLocaleDateString() : 'Draft'}
                        </TableCell>
                        <TableCell>
                          {invoice.due_date ? (
                            <span className={isOverdue(invoice) ? "text-red-600 font-medium" : ""}>
                              {new Date(invoice.due_date).toLocaleDateString()}
                            </span>
                          ) : 'N/A'}
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem asChild>
                                <Link to={createPageUrl(`ViewInvoice`) + `?id=${invoice.id}`}>
                                  <Eye className="w-4 h-4 mr-2" />
                                  View Invoice
                                </Link>
                              </DropdownMenuItem>
                              {invoice.status !== 'draft' && (
                                <DropdownMenuItem
                                  onClick={() => handleDownloadPdf(invoice)}
                                  disabled={downloading === invoice.id}
                                >
                                  {downloading === invoice.id ? (
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                  ) : (
                                    <FileDown className="w-4 h-4 mr-2" />
                                  )}
                                  Download PDF
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuItem
                                onClick={() => setPayingInvoice(invoice)}
                                disabled={!['issued', 'overdue'].includes(invoice.status)}
                              >
                                <CreditCard className="w-4 h-4 mr-2" />
                                Pay Invoice
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan="6" className="text-center py-16">
                        <Receipt className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                        <h3 className="font-semibold text-slate-800">No Invoices Yet</h3>
                        <p className="text-slate-500 text-sm">Your invoices will appear here once you start placing orders.</p>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
          {/* Pagination Controls */}
          <PaginationControls
            totalItems={invoices.length}
            itemsPerPage={itemsPerPage}
            setItemsPerPage={setItemsPerPage}
            currentPage={currentPage}
            setCurrentPage={setCurrentPage}
          />
        </Card>
      </div>

      {/* Payment Options Dialog */}
      <Dialog open={!!payingInvoice} onOpenChange={() => setPayingInvoice(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Choose Payment Method</DialogTitle>
            <DialogDescription>
              Select how you'd like to pay for invoice #{payingInvoice?.invoice_number} totaling ${payingInvoice?.total.toFixed(2)}.
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
            <Button
              variant="outline"
              className="h-24 flex flex-col gap-2 text-center"
              onClick={() => handlePay(payingInvoice.id, 'card')}
            >
                <>
                  <CreditCard className="w-6 h-6" />
                  <span className="font-medium">Credit Card</span>
                  <span className="text-xs text-slate-500">3% fee</span>
                </>
            </Button>
            <Button
              variant="outline"
              className="h-24 flex flex-col gap-2 text-center"
              onClick={() => handlePay(payingInvoice.id, 'ach')}
            >
                <>
                  <Banknote className="w-6 h-6" />
                  <span className="font-medium">ACH / Bank Transfer</span>
                  <span className="text-xs text-slate-500">0.5% fee, max $5</span>
                </>
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
