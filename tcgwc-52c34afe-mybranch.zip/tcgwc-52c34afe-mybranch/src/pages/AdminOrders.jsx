
import React, { useState, useEffect } from "react";
import { Order } from "@/api/entities";
import { User } from "@/api/entities";
import AdminHeader from "@/components/admin/AdminHeader";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Loader2, Package, MoreHorizontal, AlertCircle, Search, ChevronDown, ChevronUp, ArrowUpDown, Inbox } from "lucide-react";
import { toast } from "sonner";
import ConfirmationDialog from "@/components/ui/ConfirmationDialog";
import PaginationControls from "@/components/ui/PaginationControls"; // Added import

export default function AdminOrders() {
  const [currentUser, setCurrentUser] = useState(null);
  const [orders, setOrders] = useState([]);
  const [filteredOrders, setFilteredOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  
  // Filter states
  const [filters, setFilters] = useState({
    product: "",
    user: "",
    status: "all"
  });
  
  // Selection states
  const [selectedOrders, setSelectedOrders] = useState([]);
  const [selectAll, setSelectAll] = useState(false);
  
  // Sorting states
  const [sortConfig, setSortConfig] = useState({
    key: 'created_date',
    direction: 'desc'
  });
  const [confirmInventoryDialog, setConfirmInventoryDialog] = useState({ open: false, orders: [] });

  // Pagination states
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(25);

  useEffect(() => {
    loadPageData();
  }, []);

  useEffect(() => {
    filterAndSortOrders();
    // Reset to the first page whenever filters or sorting changes
    setCurrentPage(1); 
  }, [orders, filters, sortConfig]);

  const loadPageData = async () => {
    setLoading(true);
    try {
      const userData = await User.me();
      setCurrentUser(userData);
      
      if (userData.role !== 'admin') {
        toast.error("Access Denied");
        setIsAdmin(false);
        setLoading(false);
        return;
      }
      
      setIsAdmin(true);
      
      // Load all orders for admin view
      const orderData = await Order.list("-created_date");
      setOrders(orderData);
    } catch (error) {
      console.error("Error loading data:", error);
      toast.error("Failed to load orders.");
    } finally {
      setLoading(false);
    }
  };

  const filterAndSortOrders = () => {
    let filtered = [...orders];

    // Apply filters
    if (filters.product) {
      filtered = filtered.filter(order => 
        order.product_name?.toLowerCase().includes(filters.product.toLowerCase()) ||
        order.sku?.toLowerCase().includes(filters.product.toLowerCase())
      );
    }

    if (filters.user) {
      filtered = filtered.filter(order => 
        order.created_by?.toLowerCase().includes(filters.user.toLowerCase())
      );
    }

    if (filters.status !== "all") {
      filtered = filtered.filter(order => order.status === filters.status);
    }

    // Apply sorting
    filtered.sort((a, b) => {
      let aValue = a[sortConfig.key];
      let bValue = b[sortConfig.key];

      // Handle different data types
      if (sortConfig.key === 'order_date' || sortConfig.key === 'created_date') {
        aValue = new Date(aValue || a.created_date);
        bValue = new Date(bValue || b.created_date);
      } else if (sortConfig.key === 'total_price') {
        aValue = parseFloat(aValue) || 0;
        bValue = parseFloat(bValue) || 0;
      } else if (sortConfig.key === 'quantity') {
        aValue = parseInt(aValue) || 0;
        bValue = parseInt(bValue) || 0;
      } else {
        aValue = String(aValue || '').toLowerCase();
        bValue = String(bValue || '').toLowerCase();
      }

      if (aValue < bValue) {
        return sortConfig.direction === 'asc' ? -1 : 1;
      }
      if (aValue > bValue) {
        return sortConfig.direction === 'asc' ? 1 : -1;
      }
      return 0;
    });

    setFilteredOrders(filtered);
    
    // Reset selections when filters change
    setSelectedOrders([]);
    setSelectAll(false);
  };

  const handleSort = (key) => {
    setSortConfig(prevConfig => ({
      key,
      direction: prevConfig.key === key && prevConfig.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const getSortIcon = (columnKey) => {
    if (sortConfig.key !== columnKey) {
      return <ArrowUpDown className="w-4 h-4 ml-1 text-slate-400" />;
    }
    return sortConfig.direction === 'asc' 
      ? <ChevronUp className="w-4 h-4 ml-1 text-slate-600" />
      : <ChevronDown className="w-4 h-4 ml-1 text-slate-600" />;
  };

  const handleSelectAll = (checked) => {
    setSelectAll(checked);
    if (checked) {
      setSelectedOrders(filteredOrders.map(order => order.id));
    } else {
      setSelectedOrders([]);
    }
  };

  const handleSelectOrder = (orderId, checked) => {
    if (checked) {
      setSelectedOrders(prev => [...prev, orderId]);
    } else {
      setSelectedOrders(prev => prev.filter(id => id !== orderId));
      setSelectAll(false);
    }
  };

  const handleMarkInInventory = async () => {
    const { orders: orderIdsToProcess } = confirmInventoryDialog;
    
    // Get full order objects from the state
    const ordersToUpdate = orders.filter(o => orderIdsToProcess.includes(o.id));
    const paidOrders = ordersToUpdate.filter(o => o.status === 'Paid');

    if (paidOrders.length === 0) {
      toast.warning("No 'Paid' orders were selected or eligible to process.");
      setConfirmInventoryDialog({ open: false, orders: [] });
      return;
    }

    toast.info(`Processing ${paidOrders.length} eligible order(s)...`);
    
    try {
      const results = await Promise.all(
        paidOrders.map(async (order) => {
          // Update the order status to "In Inventory"
          await Order.update(order.id, { status: "In Inventory" });
          return { success: true, orderId: order.id };
        })
      );
      
      const successfulCount = results.filter(r => r.success).length;
      toast.success(`${successfulCount} order(s) marked as 'In Inventory'.`);

      // Deselect and reload data
      setSelectedOrders([]);
      setSelectAll(false);
      setConfirmInventoryDialog({ open: false, orders: [] });
      loadPageData();

    } catch (error) {
      console.error("Error marking orders as in inventory:", error);
      toast.error("An error occurred while processing orders. Please check the console and try again.");
    }
  };

  const getStatusBadgeVariant = (status) => {
    switch (status) {
      case "Invoiced":
      case "Payment Pending":
        return "bg-yellow-100 text-yellow-800";
      case "Paid":
        return "bg-blue-100 text-blue-800";
      case "In Inventory":
        return "bg-purple-100 text-purple-800";
      case "Complete":
        return "bg-green-100 text-green-800";
      case "Cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const uniqueStatuses = [...new Set(orders.map(order => order.status))].sort();

  // Apply pagination to the filtered and sorted orders
  const paginatedOrders = filteredOrders.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  if (loading) {
    return (
      <div className="p-6 md:p-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">All Orders</h1>
          <AdminHeader />
          <div className="flex items-center justify-center h-64">
            <Loader2 className="w-8 h-8 text-slate-400 animate-spin" />
          </div>
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="p-6 md:p-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">All Orders</h1>
          <AdminHeader />
          <div className="p-8 flex flex-col items-center justify-center text-center h-[50vh]">
            <AlertCircle className="w-12 h-12 text-red-500 mb-4" />
            <h2 className="text-2xl font-bold">Access Denied</h2>
            <p className="text-slate-600">You do not have permission to view this page.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 md:p-8 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">All Orders</h1>
          <p className="text-slate-600">Manage and track all member orders across the platform.</p>
        </div>
        
        <AdminHeader />

        {/* Filter Bar */}
        <Card className="bg-white border-0 shadow-sm mt-8 mb-6">
          <CardContent className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Product Filter */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                <Input
                  placeholder="Search by product or SKU..."
                  value={filters.product}
                  onChange={(e) => setFilters(prev => ({ ...prev, product: e.target.value }))}
                  className="pl-9 border-slate-200"
                />
              </div>

              {/* User Filter */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                <Input
                  placeholder="Search by member email..."
                  value={filters.user}
                  onChange={(e) => setFilters(prev => ({ ...prev, user: e.target.value }))}
                  className="pl-9 border-slate-200"
                  autoComplete="new-password"
                />
              </div>

              {/* Status Filter */}
              <Select value={filters.status} onValueChange={(value) => setFilters(prev => ({ ...prev, status: value }))}>
                <SelectTrigger className="border-slate-200">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent className="w-full">
                  <SelectItem value="all">All Statuses</SelectItem>
                  {uniqueStatuses.map(status => (
                    <SelectItem key={status} value={status}>{status}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Bulk Actions */}
              <div className="flex items-center justify-start lg:justify-end">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button 
                      variant="outline" 
                      disabled={selectedOrders.length === 0}
                      className="border-slate-200"
                    >
                      Bulk Actions ({selectedOrders.length})
                      <ChevronDown className="w-4 h-4 ml-2" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem
                      onClick={() => setConfirmInventoryDialog({ open: true, orders: selectedOrders })}
                      disabled={selectedOrders.length === 0}
                    >
                      <Inbox className="w-4 h-4 mr-2" />
                      Mark as In Inventory
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white border-0 shadow-sm">
          <CardHeader>
            <CardTitle>Order Management ({filteredOrders.length} of {orders.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">
                      <Checkbox
                        checked={selectAll}
                        onCheckedChange={handleSelectAll}
                        disabled={paginatedOrders.length === 0}
                      />
                    </TableHead>
                    <TableHead 
                      className="cursor-pointer hover:bg-slate-50"
                      onClick={() => handleSort('order_date')}
                    >
                      <div className="flex items-center">
                        Order Date
                        {getSortIcon('order_date')}
                      </div>
                    </TableHead>
                    <TableHead 
                      className="cursor-pointer hover:bg-slate-50"
                      onClick={() => handleSort('created_by')}
                    >
                      <div className="flex items-center">
                        Member
                        {getSortIcon('created_by')}
                      </div>
                    </TableHead>
                    <TableHead 
                      className="cursor-pointer hover:bg-slate-50"
                      onClick={() => handleSort('product_name')}
                    >
                      <div className="flex items-center">
                        Product
                        {getSortIcon('product_name')}
                      </div>
                    </TableHead>
                    <TableHead 
                      className="text-center cursor-pointer hover:bg-slate-50"
                      onClick={() => handleSort('quantity')}
                    >
                      <div className="flex items-center justify-center">
                        Quantity
                        {getSortIcon('quantity')}
                      </div>
                    </TableHead>
                    <TableHead 
                      className="cursor-pointer hover:bg-slate-50"
                      onClick={() => handleSort('status')}
                    >
                      <div className="flex items-center">
                        Status
                        {getSortIcon('status')}
                      </div>
                    </TableHead>
                    <TableHead 
                      className="text-right cursor-pointer hover:bg-slate-50"
                      onClick={() => handleSort('total_price')}
                    >
                      <div className="flex items-center justify-end">
                        Total
                        {getSortIcon('total_price')}
                      </div>
                    </TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? (
                    <TableRow>
                      <TableCell colSpan="8" className="text-center py-16">
                        <Loader2 className="w-8 h-8 text-slate-400 mx-auto animate-spin" />
                      </TableCell>
                    </TableRow>
                  ) : paginatedOrders.length > 0 ? ( // Changed from filteredOrders to paginatedOrders
                    paginatedOrders.map(order => (
                      <TableRow key={order.id}>
                        <TableCell>
                          <Checkbox
                            checked={selectedOrders.includes(order.id)}
                            onCheckedChange={(checked) => handleSelectOrder(order.id, checked)}
                          />
                        </TableCell>
                        <TableCell>
                          {order.order_date ? new Date(order.order_date).toLocaleDateString() : new Date(order.created_date).toLocaleDateString()}
                        </TableCell>
                        <TableCell className="font-medium">{order.created_by}</TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{order.product_name}</div>
                            <div className="text-sm text-slate-500">{order.sku}</div>
                          </div>
                        </TableCell>
                        <TableCell className="text-center">{order.quantity}</TableCell>
                        <TableCell>
                          <Badge className={getStatusBadgeVariant(order.status)}>
                            {order.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right font-mono">${order.total_price.toFixed(2)}</TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem
                                onClick={() => setConfirmInventoryDialog({ open: true, orders: [order.id] })}
                                disabled={order.status !== 'Paid'}
                              >
                                <Inbox className="w-4 h-4 mr-2" />
                                Mark as In Inventory
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan="8" className="text-center py-16">
                        <Package className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                        <h3 className="font-semibold text-slate-800">No Orders Found</h3>
                        <p className="text-slate-500 text-sm">
                          {Object.values(filters).some(filter => filter && filter !== 'all') 
                            ? 'Try adjusting your filters to see more orders.'
                            : 'No orders have been created yet.'
                          }
                        </p>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
          <PaginationControls
            totalItems={filteredOrders.length}
            itemsPerPage={itemsPerPage}
            setItemsPerPage={setItemsPerPage}
            currentPage={currentPage}
            setCurrentPage={setCurrentPage}
          />
        </Card>
      </div>
      <ConfirmationDialog
        open={confirmInventoryDialog.open}
        onOpenChange={(open) => setConfirmInventoryDialog({ ...confirmInventoryDialog, open })}
        title="Confirm Inventory Action"
        description={`Are you sure you want to mark ${confirmInventoryDialog.orders.length} order(s) as "In Inventory"? This will update the order status to show these items are ready.`}
        onConfirm={handleMarkInInventory}
        confirmText="Yes, Mark as In Inventory"
        variant="default"
        icon={Inbox}
      />
    </div>
  );
}
