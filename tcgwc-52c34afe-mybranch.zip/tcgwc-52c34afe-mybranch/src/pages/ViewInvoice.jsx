
import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import {
  Card,
  CardContent,
  CardHeader,
  CardFooter,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { toast } from 'sonner';
import { Invoice } from '@/api/entities';
import { InvoiceLineItem } from '@/api/entities';
import { User } from '@/api/entities';
import { Loader2, ArrowLeft, CreditCard, Landmark } from 'lucide-react';
import { createPageUrl } from "@/utils";
import { createInvoicePayment } from "@/api/functions";

export default function ViewInvoice() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const invoiceId = searchParams.get('id');

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [invoice, setInvoice] = useState(null);
  const [lineItems, setLineItems] = useState([]);
  const [user, setUser] = useState(null);
  const [isPayDialogOpen, setIsPayDialogOpen] = useState(false); // Renamed from showPayDialog
  const [processingPayment, setProcessingPayment] = useState(null); // 'card' | 'ach' | null

  const loadInvoiceData = useCallback(async () => {
    if (!invoiceId) {
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);
    
    try {
      if (!invoiceId) {
        throw new Error("No invoice ID provided in URL parameters.");
      }

      const [currentUser, invoiceData] = await Promise.all([
        User.me(),
        Invoice.get(invoiceId),
      ]);
      
      setUser(currentUser);

      if (!invoiceData) {
        throw new Error("Invoice not found.");
      }

      if (invoiceData.member_id !== currentUser.id && currentUser.role !== 'admin') {
        throw new Error("You are not authorized to view this invoice.");
      }

      const lineItemsData = await InvoiceLineItem.filter({ invoice_id: invoiceId });
      
      setInvoice(invoiceData);
      setLineItems(lineItemsData);

    } catch (err) {
      console.error("Failed to load invoice data:", err);
      toast.error(err.message);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [invoiceId]);

  useEffect(() => {
    loadInvoiceData();
  }, [loadInvoiceData]); 
  
  useEffect(() => {
    if (searchParams.get('payment') === 'success') {
      toast.success("Payment Initiated!", {
        description: "Your payment is being processed. Thank you!",
      });
      navigate(createPageUrl('ViewInvoice') + `?id=${invoiceId}`, { replace: true });
    }
  }, [searchParams, invoiceId, navigate]);
  
  const getStatusBadge = (status) => {
    switch (status?.toLowerCase()) {
      case "draft": return "bg-gray-100 text-gray-800";
      case "issued": return "bg-blue-100 text-blue-800";
      case "paid": return "bg-green-100 text-green-800";
      case "overdue": return "bg-red-100 text-red-800";
      case "cancelled": return "bg-red-600 text-white";
      case "processing_payment": return "bg-yellow-100 text-yellow-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const handlePayment = async (method) => {
    if (!invoice) return;
    
    setProcessingPayment(method);
    try {
      const response = await createInvoicePayment({ 
          invoiceId: invoice.id,
          paymentMethod: method,
      });
      
      if (response.status === 200) {
        const { checkout_url } = response.data;
        if (checkout_url) {
          window.location.href = checkout_url;
        } else {
          throw new Error("No checkout URL received");
        }
      } else {
        throw new Error(response.data?.error || "Failed to create payment session");
      }
    } catch (error) {
      console.error("Payment Error:", error);
      toast.error(`Failed to initiate ${method.toUpperCase()} payment. Please try again.`);
      setProcessingPayment(null);
    }
  };

  if (loading) {
    return (
      <div className="p-8 flex items-center justify-center h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-slate-500" />
      </div>
    );
  }

  if (error || !invoice) {
    return (
      <div className="p-8 flex items-center justify-center h-screen">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-slate-900">Could Not Load Invoice</h2>
          <p className="text-slate-600 mt-2">{error || "The invoice you're looking for could not be found."}</p>
          <Button className="mt-4" onClick={() => navigate(createPageUrl("MyInvoices"))}>
            <ArrowLeft className="w-4 h-4 mr-2"/>
            Back to Invoices
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 p-6 md:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-4">
          <Button variant="ghost" onClick={() => navigate(createPageUrl("MyInvoices"))}>
            <ArrowLeft className="w-4 h-4 mr-2"/>
            Back to Invoices
          </Button>
        </div>

        <Card className="w-full bg-white border-0 shadow-sm">
          <CardHeader className="border-b p-6">
            <div className="flex flex-col md:flex-row justify-between md:items-start">
              <div>
                <h1 className="text-2xl font-bold text-slate-900 mb-1">Invoice</h1>
                <p className="text-slate-500 font-mono">Invoice Number: {invoice.invoice_number}</p>
              </div>
              <Badge className={`${getStatusBadge(invoice.status)} mt-2 md:mt-0`}>{invoice.status.replace('_', ' ')}</Badge>
            </div>
          </CardHeader>
          
          <CardContent className="p-6">
            {invoice.status === 'paid' && invoice.payment_date && (
              <div className="p-6 border-b bg-green-50 mb-8 rounded-md">
                <h3 className="text-sm font-semibold text-slate-800 mb-2">Payment Information</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-xs text-slate-500">Payment Date</p>
                    <p className="font-medium text-slate-900">{new Date(invoice.payment_date).toLocaleDateString()}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">Payment Method</p>
                    <p className="font-medium text-slate-900">
                      {invoice.payment_method === 'manual' 
                        ? invoice.payment_method_details || 'Manual Payment'
                        : invoice.payment_method_details && invoice.payment_method_last4 
                            ? `${invoice.payment_method_details} ending in ${invoice.payment_method_last4}`
                            : invoice.payment_method?.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase()) || 'Unknown Method'
                      }
                    </p>
                  </div>
                </div>
              </div>
            )}

            <div className="grid grid-cols-2 md:grid-cols-3 gap-y-4 gap-x-8 text-sm mb-8">
              <div>
                <p className="text-slate-500">Bill To</p>
                <p className="font-medium text-slate-900">{user?.full_name}</p>
                {user?.address && (
                  <>
                    <p className="text-slate-600">{user.address.street}</p>
                    {user.address.suite && <p className="text-slate-600">{user.address.suite}</p>}
                    <p className="text-slate-600">{user.address.city}, {user.address.state} {user.address.zip}</p>
                  </>
                )}
                <p className="text-slate-600 mt-1">{user?.email}</p>
              </div>
              <div>
                <p className="text-slate-500">Issued Date</p>
                <p className="font-medium text-slate-900">{new Date(invoice.issued_date).toLocaleDateString()}</p>
              </div>
              <div>
                <p className="text-slate-500">Due Date</p>
                <p className="font-medium text-slate-900">{new Date(invoice.due_date).toLocaleDateString()}</p>
              </div>
            </div>

            {/* Line Items */}
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-2/3">Description</TableHead>
                  <TableHead className="text-right">Price</TableHead>
                  <TableHead className="text-right">Qty</TableHead>
                  <TableHead className="text-right">Total</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {lineItems.map(item => (
                  <TableRow key={item.id}>
                    <TableCell className="font-medium">{item.product_name}</TableCell>
                    <TableCell className="text-right">${item.unit_price?.toFixed(2)}</TableCell>
                    <TableCell className="text-right">{item.quantity}</TableCell>
                    <TableCell className="text-right">${(item.total_price || 0).toFixed(2)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>

            {/* Notes and Totals (Moved from previous CardFooter) */}
            <div className="p-6 mt-8 pt-8 border-t flex justify-between items-start">
              <div className="text-sm text-slate-500">
                  <h4 className="font-semibold text-slate-600 mb-2">Notes</h4>
                  <div className="w-80 min-h-[80px] p-3 border border-slate-200 bg-slate-50 rounded-md whitespace-pre-wrap">
                    {invoice.notes || <span className="text-slate-400 italic">No notes</span>}
                  </div>
              </div>
              <div className="w-1/3 space-y-2 text-sm ml-auto">
                <div className="flex justify-between"><span className="text-slate-600">Subtotal:</span> <span>${invoice.subtotal?.toFixed(2)}</span></div>
                {invoice.tcgwc_fee > 0 && (
                  <div className="flex justify-between"><span className="text-slate-600">TCGWC Fee ({invoice.tcgwc_fee_percentage}%):</span> <span>${invoice.tcgwc_fee.toFixed(2)}</span></div>
                )}
                {invoice.sales_tax > 0 && (
                  <div className="flex justify-between"><span className="text-slate-600">Sales Tax:</span> <span>${invoice.sales_tax.toFixed(2)}</span></div>
                )}
                {invoice.account_credit_applied > 0 && (
                  <div className="flex justify-between"><span className="text-slate-600">Account Credit Applied:</span> <span>-${invoice.account_credit_applied.toFixed(2)}</span></div>
                )}
                {invoice?.manual_adjustment !== 0 && (
                  <div className="flex justify-between">
                    <span className="text-slate-600">
                      Adjustment{invoice?.adjustment_reason && ` (${invoice.adjustment_reason})`}:
                    </span>
                    <span className={`font-medium ${invoice?.manual_adjustment > 0 ? 'text-red-600' : 'text-green-600'}`}>
                      {invoice?.manual_adjustment > 0 ? '+' : ''}${invoice?.manual_adjustment?.toFixed(2)}
                    </span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-lg pt-2 border-t"><span className="text-slate-800">Total:</span> <span className="text-slate-900">${invoice.total?.toFixed(2)}</span></div>
              </div>
            </div>

          </CardContent>
          
          <CardFooter className="bg-slate-50/50 p-6 border-t flex flex-col sm:flex-row justify-between items-center gap-4">
            <p className="text-sm text-slate-600">
              Questions? Contact us at <a href="mailto:support@example.com" className="font-medium text-blue-600 hover:underline">support@example.com</a>
            </p>
            {['issued', 'overdue'].includes(invoice.status) && (
              <Button onClick={() => setIsPayDialogOpen(true)}>
                <CreditCard className="w-4 h-4 mr-2" />
                Pay Invoice
              </Button>
            )}
          </CardFooter>
        </Card>

        <Dialog open={isPayDialogOpen} onOpenChange={() => !processingPayment && setIsPayDialogOpen(false)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Choose Payment Method</DialogTitle>
              <DialogDescription>
                Select how you'd like to pay for invoice #{invoice?.invoice_number} totaling ${invoice?.total.toFixed(2)}.
              </DialogDescription>
            </DialogHeader>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
              <Button
                variant="outline"
                className="h-24 flex flex-col gap-2 text-center"
                onClick={() => handlePayment('card')}
                disabled={!!processingPayment}
              >
                {processingPayment === 'card' ? (
                  <>
                    <div className="w-6 h-6 border-2 border-slate-400 border-t-transparent rounded-full animate-spin" />
                    <span className="font-medium">Processing...</span>
                  </>
                ) : (
                  <>
                    <CreditCard className="w-6 h-6" />
                    <span className="font-medium">Credit Card</span>
                    <span className="text-xs text-slate-500">3% fee</span>
                  </>
                )}
              </Button>
              <Button
                variant="outline"
                className="h-24 flex flex-col gap-2 text-center"
                onClick={() => handlePayment('ach')}
                disabled={!!processingPayment}
              >
                {processingPayment === 'ach' ? (
                  <>
                    <div className="w-6 h-6 border-2 border-slate-400 border-t-transparent rounded-full animate-spin" />
                    <span className="font-medium">Processing...</span>
                  </>
                ) : (
                  <>
                    <Landmark className="w-6 h-6" />
                    <span className="font-medium">ACH / Bank Transfer</span>
                    <span className="text-xs text-slate-500">0.5% fee, max $5</span>
                  </>
                )}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
