
import React, { useState, useEffect } from 'react';
import AdminHeader from '@/components/admin/AdminHeader';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MoreHorizontal, Edit, Trash2, CheckCircle2, Download, Plus } from "lucide-react";
import { Invoice } from '@/api/entities';
import { InvoiceLineItem } from '@/api/entities';
import { User } from '@/api/entities';
import { Order } from '@/api/entities';
import { toast } from 'sonner';
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import ConfirmationDialog from '@/components/ui/ConfirmationDialog';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { createMessage } from '@/components/utils/messaging';
import PaginationControls from "@/components/ui/PaginationControls";
import { downloadInvoicePdf } from "@/api/functions";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const formatDateForDisplay = (dateString) => {
  if (!dateString) return 'N/A';

  // Take only the date part of a potential ISO string
  const datePart = dateString.split('T')[0];
  
  // Create a date object from the date part. By appending 'Z', we ensure it's parsed as UTC.
  const testDate = new Date(`${datePart}T00:00:00.000Z`);

  // Check if the constructed date is valid
  if (isNaN(testDate.getTime())) {
      return 'Invalid Date';
  }

  // Format the date for display, ensuring the output is based on the UTC date to avoid timezone shifts.
  return testDate.toLocaleDateString(undefined, { timeZone: 'UTC' });
};

export default function AdminInvoices() {
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [actionInvoice, setActionInvoice] = useState(null); // For both void and delete
  const [markPaidInvoice, setMarkPaidInvoice] = useState(null);
  const [paymentDescription, setPaymentDescription] = useState('');
  const [saving, setSaving] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(25);
  const [downloadingInvoice, setDownloadingInvoice] = useState(null);
  const [createInvoiceModal, setCreateInvoiceModal] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState("");
  const [users, setUsers] = useState([]);
  const [creatingInvoice, setCreatingInvoice] = useState(false);

  useEffect(() => {
    loadInvoices();
    loadUsers();
  }, []);

  const loadInvoices = async () => {
    setLoading(true);
    try {
      const currentUser = await User.me();
      if (currentUser.role !== 'admin') {
        toast.error("Access Denied");
        return;
      }
      const invoiceData = await Invoice.list("-created_date");
      setInvoices(invoiceData);
      setCurrentPage(1); // Reset to first page on new data load
    } catch (error) {
      toast.error("Failed to load invoices.");
    } finally {
      setLoading(false);
    }
  };

  const loadUsers = async () => {
    try {
      const userData = await User.list();
      // Filter to only show users with active membership or admins
      const eligibleUsers = userData.filter(user =>
        user.membership_status === 'active' || user.role === 'admin'
      );
      setUsers(eligibleUsers);
    } catch (error) {
      console.error("Failed to load users:", error);
    }
  };

  const handleCreateInvoice = async () => {
    if (!selectedUserId) {
      toast.error("Please select a user first.");
      return;
    }

    setCreatingInvoice(true);
    try {
      const selectedUser = users.find(u => u.id === selectedUserId);
      if (!selectedUser) {
        throw new Error("Selected user not found");
      }

      // Create new draft invoice
      const newInvoice = await Invoice.create({
        invoice_number: `INV-${Date.now()}`,
        member_id: selectedUserId,
        member_email: selectedUser.email,
        status: 'draft',
        subtotal: 0,
        total: 0,
        // Set due date to 30 days from now
        due_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // Store as YYYY-MM-DD
      });

      toast.success(`Draft invoice #${newInvoice.invoice_number} created successfully.`);
      setCreateInvoiceModal(false);
      setSelectedUserId("");

      // Navigate to edit the new invoice
      window.location.href = createPageUrl(`AdminEditInvoice?id=${newInvoice.id}`);

    } catch (error) {
      console.error("Error creating invoice:", error);
      toast.error("Failed to create invoice.");
    } finally {
      setCreatingInvoice(false);
    }
  };

  const handleMarkPaid = async () => {
    if (!markPaidInvoice || !paymentDescription.trim()) {
      toast.error("Payment method description is required.");
      return;
    }

    setSaving(true);
    try {
      // 1. Update invoice status
      await Invoice.update(markPaidInvoice.id, {
        status: 'paid',
        payment_method: 'manual',
        payment_method_details: paymentDescription.trim(),
        payment_date: new Date().toISOString().split('T')[0] // Store as YYYY-MM-DD
      });

      // 2. Update status of associated orders
      const associatedOrders = await Order.filter({ invoice_id: markPaidInvoice.id });
      if (associatedOrders.length > 0) {
        await Promise.all(
          associatedOrders.map(order => Order.update(order.id, { status: 'Paid' }))
        );
      }

      // 3. Send a message to the user
      await createMessage({
        userId: markPaidInvoice.member_id,
        title: `Payment Received - Invoice #${markPaidInvoice.invoice_number}`,
        content: `Your payment for invoice #${markPaidInvoice.invoice_number} totaling $${markPaidInvoice.total.toFixed(2)} has been received and processed. Payment method: ${paymentDescription.trim()}`
      });

      toast.success(`Invoice #${markPaidInvoice.invoice_number} has been marked as paid.`);
      setMarkPaidInvoice(null);
      setPaymentDescription('');
      loadInvoices();
    } catch (error) {
      toast.error("Failed to mark invoice as paid.");
      console.error("Mark Paid Error:", error);
    } finally {
      setSaving(false);
    }
  };

  const handleVoidInvoice = async () => {
    if (!actionInvoice) return;
    try {
        // 1. Update the invoice status to 'cancelled'
        await Invoice.update(actionInvoice.id, { status: 'cancelled' });

        // 2. Find and cancel all associated orders
        const associatedOrders = await Order.filter({ invoice_id: actionInvoice.id });
        if (associatedOrders.length > 0) {
            await Promise.all(
                associatedOrders.map(order => Order.update(order.id, { status: 'Cancelled' }))
            );
        }

        // 3. Send a message to the user
        await createMessage({
            userId: actionInvoice.member_id,
            title: `Invoice #${actionInvoice.invoice_number} Cancelled`,
            content: `Your invoice #${actionInvoice.invoice_number} has been voided by an administrator. Any associated orders have also been cancelled. Please contact us if you have any questions.`
        });

        toast.success(`Invoice #${actionInvoice.invoice_number} has been voided and associated orders cancelled.`);
        setActionInvoice(null);
        loadInvoices();
    } catch (error) {
        toast.error("Failed to void invoice.");
        console.error("Voiding Error:", error);
    }
  };

  const handleDeleteInvoice = async () => {
    if (!actionInvoice) return;
    try {
        // Delete all line items first
        const lineItems = await InvoiceLineItem.filter({ invoice_id: actionInvoice.id });
        await Promise.all(lineItems.map(item => InvoiceLineItem.delete(item.id)));

        // Then delete the invoice
        await Invoice.delete(actionInvoice.id);

        toast.success(`Draft invoice #${actionInvoice.invoice_number} has been deleted.`);
        setActionInvoice(null);
        loadInvoices();
    } catch (error) {
        toast.error("Failed to delete invoice.");
        console.error("Delete Error:", error);
    }
  };

  const handleDownloadPdf = async (invoice) => {
    setDownloadingInvoice(invoice.id);
    try {
      const response = await downloadInvoicePdf({ invoiceId: invoice.id });

      if (response.status === 200) {
        const blob = new Blob([response.data], { type: 'application/pdf' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `invoice-${invoice.invoice_number}.pdf`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        a.remove();
        toast.success("Invoice PDF downloaded successfully!");
      } else {
        throw new Error("Failed to download PDF");
      }
    } catch (error) {
      console.error("Download error:", error);
      toast.error("Failed to download invoice PDF. Please try again.");
    } finally {
      setDownloadingInvoice(null);
    }
  };

  const getStatusBadge = (status) => {
    switch (status?.toLowerCase()) {
      case "draft": return "bg-gray-100 text-gray-800";
      case "issued": return "bg-blue-100 text-blue-800";
      case "paid": return "bg-green-100 text-green-800";
      case "overdue": return "bg-red-100 text-red-800";
      case "cancelled": return "bg-red-600 text-white";
      case "processing_payment": return "bg-yellow-100 text-yellow-800";
      case "sent": return "bg-yellow-100 text-yellow-800"; // Handle legacy status
      default: return "bg-gray-100 text-gray-800";
    }
  };

  // Calculate invoices for the current page
  const paginatedInvoices = invoices.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  return (
    <div className="p-6 md:p-8">
        <div className="max-w-7xl mx-auto">
            <h1 className="text-3xl font-bold text-slate-900 mb-2">All Invoices</h1>
            <AdminHeader />
            <Card className="mt-8">
                <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle>Invoice Management ({invoices.length})</CardTitle>
                    <Button
                        onClick={() => setCreateInvoiceModal(true)}
                        className="bg-slate-900 hover:bg-slate-800 text-white"
                    >
                        <Plus className="w-4 h-4 mr-2" />
                        Create Invoice
                    </Button>
                </CardHeader>
                <CardContent>
                    <div className="overflow-x-auto">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Invoice #</TableHead>
                                    <TableHead>Member Email</TableHead>
                                    <TableHead>Status</TableHead>
                                    <TableHead>Total</TableHead>
                                    <TableHead>Date Issued</TableHead>
                                    <TableHead>Due Date</TableHead>
                                    <TableHead className="text-right">Actions</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {loading ? (
                                    <TableRow>
                                        <TableCell colSpan="7" className="text-center py-8">Loading invoices...</TableCell>
                                    </TableRow>
                                ) : paginatedInvoices.length > 0 ? (
                                    paginatedInvoices.map(invoice => (
                                        <TableRow key={invoice.id}>
                                            <TableCell className="font-medium">{invoice.invoice_number}</TableCell>
                                            <TableCell>{invoice.member_email}</TableCell>
                                            <TableCell>
                                                <Badge className={getStatusBadge(invoice.status)}>{invoice.status.replace('_', ' ')}</Badge>
                                            </TableCell>
                                            <TableCell>${invoice.total.toFixed(2)}</TableCell>
                                            <TableCell>{formatDateForDisplay(invoice.issued_date)}</TableCell>
                                            <TableCell>{formatDateForDisplay(invoice.due_date)}</TableCell>
                                            <TableCell className="text-right">
                                                <DropdownMenu>
                                                    <DropdownMenuTrigger asChild>
                                                        <Button variant="ghost" size="icon">
                                                          <MoreHorizontal className="w-4 h-4" />
                                                        </Button>
                                                    </DropdownMenuTrigger>
                                                    <DropdownMenuContent align="end">
                                                        <DropdownMenuItem asChild>
                                                            <Link to={createPageUrl(`AdminEditInvoice?id=${invoice.id}`)}>
                                                                <Edit className="w-4 h-4 mr-2" />
                                                                {invoice.status === 'draft' ? 'Edit' : 'View'}
                                                            </Link>
                                                        </DropdownMenuItem>
                                                        {invoice.status !== 'draft' && (
                                                            <DropdownMenuItem
                                                                onClick={() => handleDownloadPdf(invoice)}
                                                                disabled={downloadingInvoice === invoice.id}
                                                            >
                                                                {downloadingInvoice === invoice.id ? (
                                                                    <div className="w-4 h-4 border-2 border-slate-400 border-t-transparent rounded-full animate-spin mr-2" />
                                                                ) : (
                                                                    <Download className="w-4 h-4 mr-2" />
                                                                )}
                                                                Download PDF
                                                            </DropdownMenuItem>
                                                        )}
                                                        {invoice.status === 'issued' && (
                                                            <DropdownMenuItem
                                                                onClick={() => setMarkPaidInvoice(invoice)}
                                                            >
                                                                <CheckCircle2 className="w-4 h-4 mr-2"/>
                                                                Mark Paid
                                                            </DropdownMenuItem>
                                                        )}
                                                        {(['draft', 'issued', 'overdue'].includes(invoice.status)) && (
                                                          <>
                                                            <DropdownMenuSeparator />
                                                            <DropdownMenuItem
                                                                onClick={() => setActionInvoice(invoice)}
                                                                className="text-red-600 focus:text-red-500"
                                                            >
                                                                <Trash2 className="w-4 h-4 mr-2"/>
                                                                {invoice.status === 'draft' ? 'Delete Draft' : 'Void Invoice'}
                                                            </DropdownMenuItem>
                                                          </>
                                                        )}
                                                    </DropdownMenuContent>
                                                </DropdownMenu>
                                            </TableCell>
                                        </TableRow>
                                    ))
                                ) : (
                                    <TableRow>
                                        <TableCell colSpan="7" className="text-center py-8">No invoices found.</TableCell>
                                    </TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </div>
                </CardContent>
                <PaginationControls
                  totalItems={invoices.length}
                  itemsPerPage={itemsPerPage}
                  setItemsPerPage={setItemsPerPage}
                  currentPage={currentPage}
                  setCurrentPage={setCurrentPage}
                />
            </Card>
        </div>

        {/* Mark Paid Dialog */}
        <Dialog open={!!markPaidInvoice} onOpenChange={() => !saving && setMarkPaidInvoice(null)}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Mark Invoice as Paid</DialogTitle>
                    <DialogDescription>
                        Mark invoice #{markPaidInvoice?.invoice_number} totaling ${markPaidInvoice?.total.toFixed(2)} as paid.
                    </DialogDescription>
                </DialogHeader>
                <div className="py-4">
                    <Label htmlFor="payment-description">Payment Method Description</Label>
                    <Input
                        id="payment-description"
                        value={paymentDescription}
                        onChange={(e) => setPaymentDescription(e.target.value)}
                        placeholder="e.g., Check #1234, Wire Transfer, Cash, etc."
                        className="mt-2"
                        disabled={saving}
                    />
                    <p className="text-sm text-slate-500 mt-1">
                        Describe how this invoice was paid (check number, wire transfer, cash, etc.)
                    </p>
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={() => setMarkPaidInvoice(null)} disabled={saving}>
                        Cancel
                    </Button>
                    <Button
                        onClick={handleMarkPaid}
                        disabled={saving || !paymentDescription.trim()}
                        className="bg-green-600 hover:bg-green-700 text-white"
                    >
                        {saving ? 'Processing...' : 'Mark as Paid'}
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>

        {/* Create Invoice Modal */}
        <Dialog open={createInvoiceModal} onOpenChange={() => !creatingInvoice && setCreateInvoiceModal(false)}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Create New Invoice</DialogTitle>
                    <DialogDescription>
                        Select a user to create a new draft invoice for.
                    </DialogDescription>
                </DialogHeader>
                <div className="py-4">
                    <Label htmlFor="user-select">Select User</Label>
                    <Select value={selectedUserId} onValueChange={setSelectedUserId} disabled={creatingInvoice}>
                        <SelectTrigger className="mt-2">
                            <SelectValue placeholder="Choose a user..." />
                        </SelectTrigger>
                        <SelectContent>
                            {users.map(user => (
                                <SelectItem key={user.id} value={user.id}>
                                    {user.full_name} ({user.email})
                                    {user.role === 'admin' && <span className="text-xs text-slate-500 ml-2">[Admin]</span>}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={() => setCreateInvoiceModal(false)} disabled={creatingInvoice}>
                        Cancel
                    </Button>
                    <Button
                        onClick={handleCreateInvoice}
                        disabled={creatingInvoice || !selectedUserId}
                        className="bg-slate-900 hover:bg-slate-800 text-white"
                    >
                        {creatingInvoice ? (
                            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                        ) : (
                            <Plus className="w-4 h-4 mr-2" />
                        )}
                        Create Invoice
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>

        <ConfirmationDialog
            open={!!actionInvoice}
            onOpenChange={() => setActionInvoice(null)}
            title={actionInvoice?.status === 'draft' ? "Delete Draft Invoice" : "Void Invoice"}
            description={
                actionInvoice?.status === 'draft'
                    ? `Are you sure you want to delete draft invoice #${actionInvoice?.invoice_number}? This will permanently remove the invoice and all its line items. This action cannot be undone.`
                    : `Are you sure you want to void invoice #${actionInvoice?.invoice_number}? This will mark it as cancelled and cancel all associated orders. This cannot be undone.`
            }
            onConfirm={actionInvoice?.status === 'draft' ? handleDeleteInvoice : handleVoidInvoice}
            confirmText={actionInvoice?.status === 'draft' ? "Yes, Delete Invoice" : "Yes, Void Invoice"}
            variant="destructive"
        />
    </div>
  );
}
