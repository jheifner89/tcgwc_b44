
import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardFooter,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { toast } from 'sonner';
import { Invoice } from '@/api/entities';
import { InvoiceLineItem } from '@/api/entities';
import { User } from '@/api/entities';
import { Order } from '@/api/entities';
import { Product } from '@/api/entities';
import { Settings } from '@/api/entities';
import { useUser } from '@/layout';
import ConfirmationDialog from '@/components/ui/ConfirmationDialog';
import LineItemFormModal from '@/components/invoices/LineItemFormModal';
import AddLineItemModal from '@/components/invoices/AddLineItemModal';
import { Loader2, Save, Send, PlusCircle, Trash2, Edit, MoreVertical, ArrowLeft, FileText } from 'lucide-react';
import { createMessage } from '@/components/utils/messaging'; 
import { STATE_TAX_RATES } from '@/components/utils/tax';

const getPaymentDetailsString = (inv) => {
    if (!inv || inv.status !== 'paid' || !inv.payment_method) return 'N/A';
    
    let details = '';
    const paymentMethodName = inv.payment_method?.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase()) || 'Unknown Method';

    if (inv.payment_method === 'manual') {
        details = inv.payment_method_details || paymentMethodName;
    } else if (inv.payment_method_details && inv.payment_method_last4) {
        details = `${inv.payment_method_details} ending in ${inv.payment_method_last4}`;
    } else {
        details = paymentMethodName;
    }
    return details;
};

// Helper function for badge styling
const getStatusBadge = (status) => {
  switch (status) {
    case 'draft':
      return "bg-gray-100 text-gray-800";
    case 'issued':
      return "bg-blue-100 text-blue-800";
    case 'paid':
      return "bg-green-100 text-green-800";
    case 'overdue':
      return "bg-red-100 text-red-800";
    case 'cancelled':
      return "bg-red-600 text-white";
    default:
      return "bg-gray-100 text-gray-800";
  }
};

const formatDateForDisplay = (dateString) => {
  if (!dateString) return 'N/A';

  // Take only the date part of a potential ISO string
  const datePart = dateString.split('T')[0];

  // Create a date object from the date part. By appending 'T00:00:00.000Z', we ensure it's parsed as UTC.
  const testDate = new Date(`${datePart}T00:00:00.000Z`);

  // Check if the constructed date is valid
  if (isNaN(testDate.getTime())) {
    return 'Invalid Date';
  }

  // Format the date for display, ensuring the output is based on the UTC date to avoid timezone shifts.
  return testDate.toLocaleDateString(undefined, { timeZone: 'UTC' });
};

export default function AdminEditInvoice() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const { user: adminUser } = useUser();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [sending, setSending] = useState(false);

  // Data state
  const [invoice, setInvoice] = useState(null);
  const [member, setMember] = useState(null);

  // Editable state
  const [lineItems, setLineItems] = useState([]);
  const [editableNotes, setEditableNotes] = useState("");
  const [editableIssuedDate, setEditableIssuedDate] = useState('');

  // Calculated Totals
  const [subtotal, setSubtotal] = useState(0);
  const [total, setTotal] = useState(0); 
  const [salesTaxInfo, setSalesTaxInfo] = useState({ amount: 0, rate: 0 });
  const [feePercentage, setFeePercentage] = useState(5);
  const [nexusStates, setNexusStates] = useState([]);

  // Modals and Dialogs
  const [editingLineItem, setEditingLineItem] = useState(null);
  const [isEditLineItemModalOpen, setIsEditLineItemModalOpen] = useState(false);
  const [isAddLineItemModalOpen, setIsAddLineItemModalOpen] = useState(false);
  const [deletingItem, setDeletingItem] = useState(null);
  const [isConfirmOpen, setIsConfirmOpen] = useState(false);
  const [confirmingIssue, setConfirmingIssue] = useState(false);

  // New state for manual pricing modal
  const [manualPriceItem, setManualPriceItem] = useState(null);
  const [manualPrice, setManualPrice] = useState('');
  const [savingManualPrice, setSavingManualPrice] = useState(false);

  const isEditable = invoice?.status === 'draft';

  // --- Data Loading and Calculation ---
  const loadInvoice = useCallback(async (id) => {
    setLoading(true);
    try {
      if (!id) {
        toast.error("No invoice ID provided.");
        navigate("/AdminInvoices");
        return;
      }

      const [invData, allUsers, settingsData] = await Promise.all([
        Invoice.get(id),
        User.list(),
        Settings.list()
      ]);

      if (!invData) {
        toast.error("Invoice not found.");
        navigate("/AdminInvoices");
        return;
      }
      
      const memberData = allUsers.find(u => u.id === invData.member_id);
      if (!memberData) {
        toast.error("Could not find the member associated with this invoice.");
        setLoading(false);
        navigate("/AdminInvoices");
        return;
      }

      const lineItemsData = await InvoiceLineItem.filter({ invoice_id: id });
      const enrichedLineItems = await Promise.all(
        lineItemsData.map(async (item) => {
          if (item.product_id && item.item_type === 'product') {
            try {
              const product = await Product.get(item.product_id);
              return {
                ...item,
                wholesale_price: product.wholesale_price,
                bulk_price: product.bulk_price,
                bulk_quantity: product.bulk_quantity,
              };
            } catch (error) {
              console.warn(`Could not fetch product data for item ${item.id}:`, error);
              return item;
            }
          }
          return item;
        })
      );

      const feeSetting = settingsData.find(s => s.setting_key === 'tcgwc_fee_percentage');
      if (feeSetting) setFeePercentage(parseFloat(feeSetting.setting_value));

      const nexusSetting = settingsData.find(s => s.setting_key === 'economic_nexus_states');
      if (nexusSetting && nexusSetting.setting_value) setNexusStates(JSON.parse(nexusSetting.setting_value));

      setInvoice(invData);
      setLineItems(enrichedLineItems.sort((a,b) => (a.item_type || 'product').localeCompare(b.item_type || 'product')));
      setMember(memberData);

    } catch (error) {
      console.error("Failed to load invoice data:", error);
      toast.error(`Failed to load invoice data. ${error.message}`);
    } finally {
      setLoading(false);
    }
  }, [navigate]);

  useEffect(() => {
    const invoiceId = searchParams.get('id');
    if (invoiceId) {
      loadInvoice(invoiceId);
    } else {
      toast.error("No invoice ID provided.");
      navigate("/AdminInvoices");
    }
  }, [searchParams, loadInvoice, navigate]);

  // New useEffect to initialize editable states when invoice changes
  useEffect(() => {
    if (invoice) {
      setEditableNotes(invoice.notes || "");
      if (invoice.issued_date) {
        setEditableIssuedDate(invoice.issued_date.split('T')[0]);
      } else {
        const today = new Date().toISOString().split('T')[0];
        setEditableIssuedDate(today);
      }
    }
  }, [invoice]);

  useEffect(() => {
    const newSubtotal = lineItems.reduce((acc, item) => acc + (item.total_price || 0), 0);
    setSubtotal(newSubtotal);
  }, [lineItems]);

  useEffect(() => {
    if (isEditable && member) {
        if (member.is_reseller) {
            setSalesTaxInfo({ amount: 0, rate: 0 });
        } else {
            const memberState = member.address?.state;
            if (memberState && nexusStates.includes(memberState)) {
                const rate = STATE_TAX_RATES[memberState] || 0;
                setSalesTaxInfo({ amount: subtotal * rate, rate: rate });
            } else {
                setSalesTaxInfo({ amount: 0, rate: 0 });
            }
        }
    } else if (invoice) {
        setSalesTaxInfo({ amount: invoice.sales_tax || 0, rate: invoice.sales_tax_rate || 0 });
    }

    const feeAmount = !isEditable ? (invoice?.tcgwc_fee || 0) : (subtotal * (feePercentage / 100));
    const taxAmount = !isEditable ? (invoice?.sales_tax || 0) : salesTaxInfo.amount;
    const creditAmount = !isEditable ? (invoice?.account_credit_applied || 0) : 0;
    const adjustment = !isEditable ? (invoice?.manual_adjustment || 0) : 0;
    
    setTotal(subtotal + feeAmount + taxAmount - creditAmount + adjustment);

  }, [subtotal, member, nexusStates, isEditable, invoice, feePercentage, salesTaxInfo.amount]);


  // --- Line Item and Invoice Actions ---

  const handleLineItemChange = (itemId, field, value) => {
    setLineItems(prev => prev.map(item => {
      if (item.id === itemId) {
        const newItem = { ...item, [field]: value };
        
        if (field === 'quantity' && !item.manual_price_override) {
          if (newItem.bulk_price && newItem.bulk_quantity && value >= newItem.bulk_quantity) {
            newItem.unit_price = newItem.bulk_price;
          } else if (newItem.wholesale_price) {
            newItem.unit_price = newItem.wholesale_price;
          }
          newItem.total_price = value * newItem.unit_price;
        } else if (field === 'quantity' && item.manual_price_override) {
          newItem.total_price = value * newItem.unit_price;
        }
        
        return newItem;
      }
      return item;
    }));
  };

  const handleSetManualPrice = (item) => {
    setManualPriceItem(item);
    setManualPrice(item.unit_price.toString());
  };

  const handleSaveManualPrice = async () => {
    if (!manualPrice || parseFloat(manualPrice) <= 0) {
      toast.error("Please enter a valid price.");
      return;
    }

    setSavingManualPrice(true);
    try {
      const newUnitPrice = parseFloat(manualPrice);
      const newTotalPrice = manualPriceItem.quantity * newUnitPrice;

      setLineItems(prev => prev.map(item => 
        item.id === manualPriceItem.id 
          ? { 
              ...item, 
              unit_price: newUnitPrice, 
              total_price: newTotalPrice,
              manual_price_override: true 
            }
          : item
      ));

      toast.success("Manual price set successfully.");
      setManualPriceItem(null);
      setManualPrice('');
    } catch (error) {
      console.error("Failed to set manual price:", error);
      toast.error("Failed to set manual price.");
    } finally {
      setSavingManualPrice(false);
    }
  };

  const handleResetPrice = (item) => {
    let correctPrice = item.wholesale_price;
    if (item.bulk_price && item.bulk_quantity && item.quantity >= item.bulk_quantity) {
      correctPrice = item.bulk_price;
    }

    setLineItems(prev => prev.map(lineItem => 
      lineItem.id === item.id 
        ? { 
            ...lineItem, 
            unit_price: correctPrice, 
            total_price: item.quantity * correctPrice,
            manual_price_override: false 
          }
        : lineItem
    ));

    toast.success("Price reset to automatic pricing.");
  };

  const handleAddLineItem = () => {
    setIsAddLineItemModalOpen(true);
  };

  const handleEditItem = (item) => {
    setEditingLineItem(item);
    setIsEditLineItemModalOpen(true);
  };

  const handleSaveItem = (itemToSave) => {
    const exists = lineItems.some(li => li.id === itemToSave.id);
    if (exists) {
      setLineItems(prev => prev.map(li => li.id === itemToSave.id ? li.id.startsWith('new_') ? {...itemToSave, id: li.id} : itemToSave : li));
    } else {
      setLineItems(prev => [...prev, {...itemToSave, id: `new_${Date.now()}`}]);
    }
    setEditingLineItem(null);
    setIsAddLineItemModalOpen(false);
    setIsEditLineItemModalOpen(false);
  };

  const handleDeleteItem = (item) => {
    setDeletingItem(item);
    setIsConfirmOpen(true);
  };

  const confirmDeleteItem = () => {
    setLineItems(prev => prev.filter(li => li.id !== deletingItem.id));
    setDeletingItem(null);
    setIsConfirmOpen(false);
  };

  // --- Main Save/Issue Actions ---

  const saveChanges = async () => {
    setSaving(true);
    try {
      if (isEditable) {
        const originalLineItems = await InvoiceLineItem.filter({ invoice_id: invoice.id });
        const lineItemIdsToDelete = originalLineItems
          .filter(oli => !lineItems.some(li => li.id === oli.id))
          .map(oli => oli.id);

        const actions = [];

        lineItems.forEach(item => {
          if (String(item.id).startsWith('new_')) {
            const {id, ...createData} = item;
            actions.push(InvoiceLineItem.create({ ...createData, invoice_id: invoice.id }));
          } else {
            actions.push(InvoiceLineItem.update(item.id, item));
          }
        });
        lineItemIdsToDelete.forEach(id => actions.push(InvoiceLineItem.delete(id)));

        await Promise.all(actions);
      }

      const updatedInvoiceDetails = {
        subtotal,
        total, 
        notes: editableNotes,
        sales_tax: salesTaxInfo.amount,
        sales_tax_rate: salesTaxInfo.rate
      };
      await Invoice.update(invoice.id, updatedInvoiceDetails);

      toast.success("Invoice draft saved successfully!");

    } catch (error) {
      console.error("Failed to save invoice draft:", error);
      toast.error("Failed to save invoice draft.");
    } finally {
      setSaving(false);
      await loadInvoice(invoice.id);
    }
  };

  const handleIssueInvoice = async () => {
    setSaving(true);
    try {
      await saveChanges(); // This saves line items and draft invoice details

      // Recalculate totals based on saved line items for final invoice data
      const currentLineItems = await InvoiceLineItem.filter({ invoice_id: invoice.id });
      const currentSubtotal = currentLineItems.reduce((acc, item) => acc + (item.total_price || 0), 0);
      
      let finalSalesTax = { amount: 0, rate: 0 };
      if (member && !member.is_reseller) {
        const memberState = member.address?.state;
        if (memberState && nexusStates.includes(memberState)) {
          const rate = STATE_TAX_RATES[memberState] || 0;
          finalSalesTax = { amount: currentSubtotal * rate, rate: rate };
        }
      }

      const feeAmount = currentSubtotal * (feePercentage / 100);
      let newTotal = currentSubtotal + feeAmount + finalSalesTax.amount;
      let accountCreditApplied = 0;

      const productLineItems = currentLineItems.filter(item => item.item_type === 'product');

      if (productLineItems.length > 0) {
        const ordersToCreate = productLineItems.map(item => ({
            order_number: `ORD-${invoice.invoice_number.replace('INV-', '')}-${String(item.id).slice(-4)}`,
            invoice_id: invoice.id,
            invoice_line_item_id: item.id,
            member_id: member.id,
            product_id: item.product_id,
            sku: item.sku,
            product_name: item.product_name,
            quantity: item.quantity,
            unit_price: item.unit_price,
            total_price: item.total_price,
            status: 'Invoiced',
            order_date: (editableIssuedDate || new Date().toISOString().split('T')[0]), // Use the issued date from editable field
        }));
        await Order.bulkCreate(ordersToCreate);
        toast.info(`${ordersToCreate.length} order(s) created from invoice.`);
      }

      const creditItems = currentLineItems.filter(item => item.item_type === 'credit');
      if (creditItems.length > 0) {
        const totalCreditUsed = creditItems.reduce((sum, item) => sum + Math.abs(item.total_price), 0);
        if (totalCreditUsed > 0) {
          await User.update(member.id, {
              account_credit: Math.max(0, (member.account_credit || 0) - totalCreditUsed)
          });
          newTotal = Math.max(0, newTotal - totalCreditUsed); // Adjust total with credit
          accountCreditApplied = totalCreditUsed;
          toast.info(`Account credit for ${member.full_name} updated by $${totalCreditUsed.toFixed(2)}.`);
        }
      }

      // Determine the final issued date string (either user selected or current date)
      const finalIssuedDateString = editableIssuedDate || new Date().toISOString().split('T')[0];
      const issuedDateObject = new Date(finalIssuedDateString + 'T00:00:00'); // Ensure UTC midnight to avoid timezone issues
      
      // Calculate due date 30 days from the finalIssuedDate
      const dueDateObject = new Date(issuedDateObject.getTime() + 30 * 24 * 60 * 60 * 1000);
      const finalDueDateString = dueDateObject.toISOString().split('T')[0];

      // Prepare final invoice data for update, using calculated values
      const finalInvoiceData = {
        status: 'issued',
        issued_date: finalIssuedDateString,
        due_date: finalDueDateString,
        subtotal: currentSubtotal,
        sales_tax: finalSalesTax.amount,
        sales_tax_rate: finalSalesTax.rate,
        tcgwc_fee: feeAmount,
        tcgwc_fee_percentage: feePercentage,
        total: newTotal,
        account_credit_applied: accountCreditApplied,
        notes: editableNotes, // Ensure notes are also updated if they were changed
      };

      await Invoice.update(invoice.id, finalInvoiceData);
      
      await createMessage({
        userId: member.id,
        title: `New Invoice #${invoice.invoice_number}`,
        content: `You have a new invoice for $${newTotal.toFixed(2)}. Please go to 'My Invoices' to review and pay.`
      });
      
      toast.success("Invoice has been issued!");
      navigate("/AdminInvoices");

    } catch (error) {
      console.error("Failed to issue invoice:", error);
      toast.error("Failed to issue invoice.");
    } finally {
      setSaving(false);
      setConfirmingIssue(false);
    }
  };

  // --- Render Logic ---

  if (loading) {
    return (
      <div className="p-8 flex items-center justify-center h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-slate-500" />
      </div>
    );
  }

  if (!invoice || !member) {
    return (
      <div className="p-8 flex items-center justify-center h-screen">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-slate-900">Invoice not found</h2>
          <p className="text-slate-600 mt-2">The invoice you're looking for could not be loaded.</p>
          <Button className="mt-4" onClick={() => navigate("/AdminInvoices")}>
            Back to Invoices
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 bg-slate-50 min-h-screen">
      {/* Header Section */}
      <div className="max-w-7xl mx-auto mb-6">
          <div className="flex items-center justify-between">
              <Button variant="outline" onClick={() => navigate('/AdminInvoices')} className="flex items-center gap-2">
                  <ArrowLeft className="w-4 h-4"/>
                  Back to All Invoices
              </Button>
              {isEditable && (
                  <div className="flex items-center gap-2">
                      <Button onClick={saveChanges} disabled={saving} variant="secondary">
                          {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
                          Save Draft
                      </Button>
                      <Button onClick={() => setConfirmingIssue(true)} disabled={saving}>
                          <Send className="w-4 h-4 mr-2" />
                          Issue Invoice
                      </Button>
                  </div>
              )}
          </div>
      </div>

      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-8">
            {/* Invoice Header */}
            <Card className="shadow-sm border-0">
                <CardHeader className="flex flex-row items-start justify-between">
                    <div>
                        <h1 className="text-2xl font-bold text-slate-800">
                            {invoice.status === 'draft' ? "Draft Invoice" : `Invoice #${invoice.invoice_number}`}
                        </h1>
                        <p className="text-slate-500">For {member?.full_name || member?.email}</p>
                    </div>
                    <Badge className={getStatusBadge(invoice.status)}>
                        {invoice.status.charAt(0).toUpperCase() + invoice.status.slice(1)}
                    </Badge>
                </CardHeader>
                <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-6">
                    <div>
                        <Label className="text-slate-500">Issued Date</Label>
                        <p className="font-medium text-slate-800">{formatDateForDisplay(invoice.issued_date)}</p>
                    </div>
                    <div>
                        <Label className="text-slate-500">Due Date</Label>
                        <p className="font-medium text-slate-800">{formatDateForDisplay(invoice.due_date)}</p>
                    </div>
                    <div>
                        <Label className="text-slate-500">Total Amount</Label>
                        <p className="font-bold text-2xl text-slate-800">${total.toFixed(2)}</p>
                    </div>
                    {invoice.status === 'paid' && (
                         <div>
                            <Label className="text-slate-500">Payment Details</Label>
                            <p className="font-medium text-slate-800">{getPaymentDetailsString(invoice)}</p>
                        </div>
                    )}
                </CardContent>
            </Card>

          <Card className="w-full bg-white border-0 shadow-sm">
            <CardContent className="p-6">
              <div className="grid grid-cols-2 md:grid-cols-3 gap-y-4 gap-x-8 text-sm mb-8">
                <div>
                    <p className="text-slate-500">Bill To</p>
                    <p className="font-medium text-slate-900">{member.full_name}</p>
                    {member.address && (
                      <>
                        <p className="text-slate-600">{member.address.street}</p>
                        {member.address.suite && <p className="text-slate-600">{member.address.suite}</p>}
                        <p className="text-slate-600">{member.address.city}, {member.address.state} {member.address.zip}</p>
                      </>
                    )}
                    <p className="text-slate-600 mt-1">{member.email}</p>
                </div>
                <div>
                  <p className="text-slate-500">Issued On</p>
                  {isEditable ? (
                    <input
                      type="date"
                      value={editableIssuedDate}
                      onChange={(e) => setEditableIssuedDate(e.target.value)}
                      className="mt-1 text-sm font-medium text-slate-800 border border-slate-200 rounded px-2 py-1"
                    />
                  ) : (
                    <p className="font-medium text-slate-800">{invoice.issued_date ? formatDateForDisplay(invoice.issued_date) : 'N/A'}</p>
                  )}
                </div>
                <div>
                  <p className="text-slate-500">Due On</p>
                  <p className="font-medium text-slate-800">{invoice.due_date ? formatDateForDisplay(invoice.due_date) : 'N/A'}</p>
                </div>
              </div>

              <div className="border rounded-md overflow-hidden mb-8">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-2/3">Description</TableHead>
                      <TableHead className="text-right">Price</TableHead>
                      <TableHead className="text-right">Qty</TableHead>
                      <TableHead className="text-right">Total</TableHead>
                      {isEditable && <TableHead className="w-12"></TableHead>}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {lineItems.map(item => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">
                          {item.product_name}
                          {item.manual_price_override && (
                            <span className="ml-2 text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">Manual Price</span>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          ${item.unit_price?.toFixed(2)}
                        </TableCell>
                        <TableCell className="text-right">
                          {isEditable ? (
                            <Input
                              type="number"
                              value={item.quantity}
                              onChange={(e) => handleLineItemChange(item.id, 'quantity', Number(e.target.value))}
                              className="min-w-[60px] text-right"
                            />
                          ) : (
                            item.quantity
                          )}
                        </TableCell>
                        <TableCell className="text-right">${(item.total_price || 0).toFixed(2)}</TableCell>
                        {isEditable && (
                          <TableCell>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon"><MoreVertical className="w-4 h-4" /></Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent>
                                <DropdownMenuItem onClick={() => handleEditItem(item)}>
                                  <Edit className="w-4 h-4 mr-2"/>Edit Description
                                </DropdownMenuItem>
                                {item.item_type === 'product' && !item.manual_price_override && (
                                  <DropdownMenuItem onClick={() => handleSetManualPrice(item)}>
                                    <Edit className="w-4 h-4 mr-2"/>Set Manual Price
                                  </DropdownMenuItem>
                                )}
                                {item.item_type === 'product' && item.manual_price_override && (
                                  <DropdownMenuItem onClick={() => handleResetPrice(item)}>
                                    <Edit className="w-4 h-4 mr-2"/>Reset Price
                                  </DropdownMenuItem>
                                )}
                                <DropdownMenuItem onClick={() => handleDeleteItem(item)} className="text-red-500">
                                  <Trash2 className="w-4 h-4 mr-2"/>Delete
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        )}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                {isEditable && (
                  <div className="p-4 bg-slate-50 border-t">
                    <Button variant="outline" size="sm" onClick={handleAddLineItem}>
                      <PlusCircle className="w-4 h-4 mr-2"/>
                      Add Line Item
                    </Button>
                  </div>
                )}
              </div>

              <div className="flex justify-between items-start pt-6 border-t">
                <div className="text-sm text-slate-500">
                    <h4 className="font-semibold text-slate-600 mb-2">Notes</h4>
                    {isEditable ? (
                        <Textarea
                            value={editableNotes}
                            onChange={(e) => setEditableNotes(e.target.value)}
                            className="w-80 min-h-[80px]"
                            placeholder="Add notes for this invoice..."
                        />
                    ) : (
                        <div className="w-80 min-h-[80px] p-3 border border-slate-200 bg-slate-50 rounded-md whitespace-pre-wrap">
                            {editableNotes || <span className="text-slate-400 italic">No notes</span>}
                        </div>
                    )}
                </div>
                <div className="w-1/3 space-y-2 text-sm ml-auto">
                    <div className="flex justify-between"><span className="text-slate-600">Subtotal:</span> <span>${subtotal.toFixed(2)}</span></div>
                    {isEditable && subtotal > 0 && (
                      <div className="flex justify-between"><span className="text-slate-600">TCGWC Fee ({feePercentage}%):</span> <span>${(subtotal * (feePercentage / 100)).toFixed(2)}</span></div>
                    )}
                    {isEditable && salesTaxInfo.amount > 0 && (
                      <div className="flex justify-between"><span className="text-slate-600">Sales Tax ({(salesTaxInfo.rate * 100).toFixed(2)}%):</span> <span>${salesTaxInfo.amount.toFixed(2)}</span></div>
                    )}
                    {!isEditable && invoice.tcgwc_fee > 0 && (
                      <div className="flex justify-between"><span className="text-slate-600">TCGWC Fee ({invoice.tcgwc_fee_percentage}%):</span> <span>${invoice.tcgwc_fee.toFixed(2)}</span></div>
                    )}
                    {!isEditable && invoice.sales_tax > 0 && (
                       <div className="flex justify-between"><span className="text-slate-600">Sales Tax ({(invoice.sales_tax_rate * 100).toFixed(2)}%):</span> <span>${invoice.sales_tax.toFixed(2)}</span></div>
                    )}
                    {!isEditable && invoice.account_credit_applied > 0 && (
                      <div className="flex justify-between"><span className="text-slate-600">Account Credit Applied:</span> <span>-${invoice.account_credit_applied.toFixed(2)}</span></div>
                    )}
                    {!isEditable && invoice.manual_adjustment !== 0 && (
                      <div className="flex justify-between"><span className="text-slate-600">Adjustment:</span> <span>{invoice.manual_adjustment >= 0 ? '+' : ''}${invoice.manual_adjustment.toFixed(2)}</span></div>
                    )}
                    <div className="flex justify-between font-bold text-lg pt-2 border-t">
                      <span className="text-slate-800">Total:</span> 
                      <span className="text-slate-900">
                        ${total.toFixed(2)}
                      </span>
                    </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div> {/* End lg:col-span-2 */}

        {/* Right Sidebar - Current structure doesn't include a sidebar, so this is just to fill the gap. */}
        {/* If there was a right sidebar in the original structure, it would go here. */}
        <div className="lg:col-span-1 space-y-8">
            {/* Payment history, Member info, etc. could go here */}
            {/* Keeping it simple as the outline didn't modify this part explicitly. */}
        </div>
      </div> {/* End max-w-7xl grid */}

      <Dialog open={!!manualPriceItem} onOpenChange={() => !savingManualPrice && setManualPriceItem(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Set Manual Price</DialogTitle>
            <DialogDescription>
              Set a custom price for <strong>{manualPriceItem?.product_name}</strong>. This will override automatic bulk/wholesale pricing.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Label htmlFor="manual-price">Unit Price</Label>
            <Input
              id="manual-price"
              type="number"
              step="0.01"
              value={manualPrice}
              onChange={(e) => setManualPrice(e.target.value)}
              placeholder="Enter price per unit"
              className="mt-2"
              disabled={savingManualPrice}
            />
            <p className="text-sm text-slate-500 mt-1">
              Current quantity: {manualPriceItem?.quantity} • Total will be: ${((manualPriceItem?.quantity || 0) * (parseFloat(manualPrice) || 0)).toFixed(2)}
            </p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setManualPriceItem(null)} disabled={savingManualPrice}>
              Cancel
            </Button>
            <Button onClick={handleSaveManualPrice} disabled={savingManualPrice} className="bg-blue-600 hover:bg-blue-700 text-white">
              {savingManualPrice ? 'Setting...' : 'Set Manual Price'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AddLineItemModal
        isOpen={isAddLineItemModalOpen}
        onClose={() => setIsAddLineItemModalOpen(false)}
        onSave={handleSaveItem}
        availableCredit={member?.account_credit || 0}
      />
      <LineItemFormModal
        isOpen={isEditLineItemModalOpen}
        onClose={() => setIsEditLineItemModalOpen(false)}
        onSave={handleSaveItem}
        item={editingLineItem}
      />
      <ConfirmationDialog
        open={isConfirmOpen}
        onOpenChange={setIsConfirmOpen}
        title="Delete Line Item"
        description="Are you sure you want to remove this line item? This action cannot be undone."
        onConfirm={confirmDeleteItem}
        confirmText="Yes, Delete"
        variant="destructive"
      />
      <ConfirmationDialog
        open={confirmingIssue}
        onOpenChange={setConfirmingIssue}
        title="Issue Invoice"
        description={`Are you sure you want to issue invoice #${invoice?.invoice_number}? Once issued, the invoice cannot be edited and will be sent to the member.`}
        onConfirm={handleIssueInvoice}
        confirmText="Yes, Issue Invoice"
        variant="default"
      />
    </div>
  );
}
