
import React, { useState, useEffect } from "react";
import { Shipment } from "@/api/entities";
import { ShipmentItem } from "@/api/entities";
import { Order } from "@/api/entities";
import { User } from "@/api/entities";
import AdminHeader from "@/components/admin/AdminHeader";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { Loader2, Truck, MoreHorizontal, Eye, Edit, Search, AlertCircle, Send, XCircle, FileText, Download } from "lucide-react";
import { toast } from "sonner";
import ShipmentDetailsModal from "@/components/shipments/ShipmentDetailsModal";
import { createMessage } from "@/components/utils/messaging";
import PaginationControls from "@/components/ui/PaginationControls";
import { downloadPackingSlipPdf } from "@/api/functions";
import { createShipmentInvoice } from "@/api/functions";

export default function AdminShipments() {
  const [currentUser, setCurrentUser] = useState(null);
  const [shipments, setShipments] = useState([]);
  const [filteredShipments, setFilteredShipments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [viewingShipment, setViewingShipment] = useState(null);
  const [editingShipment, setEditingShipment] = useState(null);
  const [markingShipped, setMarkingShipped] = useState(null);
  const [cancellingShipment, setCancellingShipment] = useState(null);
  const [downloadingPackingSlip, setDownloadingPackingSlip] = useState(null);
  const [saving, setSaving] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(25);

  // Form states
  const [editForm, setEditForm] = useState({
    status: "",
    tracking_number: "",
    ship_date: ""
  });
  const [trackingNumbers, setTrackingNumbers] = useState("");
  const [shippingCost, setShippingCost] = useState("");
  const [cancellationReason, setCancellationReason] = useState("");

  useEffect(() => {
    loadPageData();
  }, []);

  useEffect(() => {
    filterShipments();
  }, [shipments, searchTerm, statusFilter]);

  const loadPageData = async (showLoading = true) => {
    if (showLoading) setLoading(true);
    try {
      const userData = await User.me();
      setCurrentUser(userData);

      if (userData.role !== 'admin') {
        toast.error("Access Denied");
        setIsAdmin(false);
        if (showLoading) setLoading(false);
        return;
      }

      setIsAdmin(true);

      // Load all shipments for admin view
      const shipmentData = await Shipment.list("-created_date");

      // Get member information for each shipment
      const shipmentsWithMemberInfo = await Promise.all(
        shipmentData.map(async (shipment) => {
          try {
            const member = await User.get(shipment.member_id);
            return {
              ...shipment,
              member_email: member?.email || 'Unknown',
              member_name: member?.full_name || member?.name_or_company || 'Unknown'
            };
          } catch (error) {
            return {
              ...shipment,
              member_email: 'Unknown',
              member_name: 'Unknown'
            };
          }
        })
      );

      setShipments(shipmentsWithMemberInfo);
    } catch (error) {
      console.error("Error loading data:", error);
      toast.error("Failed to load shipments.");
    } finally {
      if (showLoading) setLoading(false);
    }
  };

  const filterShipments = () => {
    let filtered = [...shipments];

    if (searchTerm) {
      filtered = filtered.filter(shipment =>
        shipment.shipment_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        shipment.member_email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        shipment.member_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (shipment.tracking_number && shipment.tracking_number.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    if (statusFilter !== "all") {
      filtered = filtered.filter(shipment => shipment.status === statusFilter);
    }

    setFilteredShipments(filtered);
    setCurrentPage(1);
  };

  const handleEditShipment = (shipment) => {
    setEditingShipment(shipment);
    setEditForm({
      status: shipment.status,
      tracking_number: shipment.tracking_number || "",
      ship_date: shipment.ship_date ? shipment.ship_date.split('T')[0] : ""
    });
  };

  const handleUpdateShipment = async () => {
    if (!editingShipment) return;

    setSaving(true);
    try {
      const updateData = {
        status: editForm.status,
        tracking_number: editForm.tracking_number || null,
        ship_date: editForm.ship_date ? new Date(editForm.ship_date).toISOString() : null
      };

      await Shipment.update(editingShipment.id, updateData);
      toast.success("Shipment updated successfully.");
      setEditingShipment(null);
      loadPageData(false);
    } catch (error) {
      console.error("Error updating shipment:", error);
      toast.error("Failed to update shipment.");
    } finally {
      setSaving(false);
    }
  };

  const handleMarkShipped = async () => {
    if (!markingShipped || !trackingNumbers.trim()) {
      toast.error("Please enter at least one tracking number.");
      return;
    }
    if (!shippingCost || isNaN(parseFloat(shippingCost)) || parseFloat(shippingCost) < 0) {
        toast.error("Please enter a valid shipping cost.");
        return;
    }

    setSaving(true);
    try {
      const formattedTracking = trackingNumbers.split(/[\n,]+/).map(s => s.trim()).filter(Boolean).join(', ');

      await Shipment.update(markingShipped.id, {
        status: "Shipped",
        tracking_number: formattedTracking,
        ship_date: new Date().toISOString()
      });

      await createMessage({
        userId: markingShipped.member_id,
        title: "Your Shipment is on its way!",
        content: `Shipment ${markingShipped.shipment_id} has been shipped. Tracking: ${formattedTracking}`
      });

      const invoiceResponse = await createShipmentInvoice({
          shipmentId: markingShipped.id,
          shippingCost: parseFloat(shippingCost)
      });
      
      if (invoiceResponse.status !== 200) {
          throw new Error(invoiceResponse.data?.error || "Failed to create shipment invoice.");
      }

      toast.success("Shipment marked as shipped and invoice created.");
      setMarkingShipped(null);
      setTrackingNumbers("");
      setShippingCost("");
      await loadPageData(false);
    } catch (error) {
      toast.error(error.message || "Failed to mark shipment as shipped.");
    } finally {
      setSaving(false);
    }
  };

  const handleCancelShipment = async () => {
    if (!cancellingShipment) return;

    if (!cancellationReason.trim()) {
      toast.error("Please provide a reason for cancelling this shipment.");
      return;
    }

    setSaving(true);
    toast.info("Cancelling shipment...");
    try {
      // Revert inventory for each item in the shipment
      const itemsToRevert = await ShipmentItem.filter({ shipment_id: cancellingShipment.id });
      await Promise.all(
        itemsToRevert.map(async (item) => {
          const order = await Order.get(item.order_id);
          if (order) {
            const newShippedQuantity = (order.shipped_quantity || 0) - item.quantity;
            await Order.update(order.id, {
              shipped_quantity: Math.max(0, newShippedQuantity),
              status: "In Inventory"
            });
          }
        })
      );

      // Update shipment status to Cancelled
      await Shipment.update(cancellingShipment.id, { status: "Cancelled" });

      // Notify member
      await createMessage({
        userId: cancellingShipment.member_id,
        title: "Shipment Cancelled",
        content: `Your shipment ${cancellingShipment.shipment_id} has been cancelled. The items have been returned to your inventory.\n\nReason: ${cancellationReason}`
      });

      toast.success("Shipment cancelled and items returned to inventory.");
      setCancellingShipment(null);
      setCancellationReason("");
      await loadPageData(false);

    } catch (error) {
      console.error("Error cancelling shipment:", error);
      toast.error("Failed to cancel shipment.");
    } finally {
      setSaving(false);
    }
  };

  const handleDownloadPackingSlip = async (shipment) => {
    setDownloadingPackingSlip(shipment.id);
    toast.info("Generating Packing Slip PDF...");
    try {
      const response = await downloadPackingSlipPdf({ shipmentId: shipment.id });

      if (response.status !== 200) {
        throw new Error("Failed to generate PDF");
      }

      const blob = new Blob([response.data], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `PackingSlip_${shipment.shipment_id}.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
      toast.success("Packing slip downloaded.");

    } catch (error) {
      console.error("Error downloading packing slip:", error);
      toast.error("Could not generate packing slip.");
    } finally {
      setDownloadingPackingSlip(null);
    }
  };

  const getStatusBadgeVariant = (status) => {
    switch (status) {
      case "Pending": return "bg-yellow-100 text-yellow-800";
      case "Preparing": return "bg-blue-100 text-blue-800"; // Changed from Packed to Preparing
      case "Shipped": return "bg-purple-100 text-purple-800";
      case "Cancelled": return "bg-red-100 text-red-800"; // Removed Delivered
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const uniqueStatuses = [...new Set(shipments.map(shipment => shipment.status))].sort();

  const paginatedShipments = filteredShipments.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);


  if (loading) {
    return (
      <div className="p-6 md:p-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">All Shipments</h1>
          <AdminHeader />
          <div className="flex items-center justify-center h-64">
            <Loader2 className="w-8 h-8 text-slate-400 animate-spin" />
          </div>
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="p-6 md:p-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">All Shipments</h1>
          <AdminHeader />
          <div className="p-8 flex flex-col items-center justify-center text-center h-[50vh]">
            <AlertCircle className="w-12 h-12 text-red-500 mb-4" />
            <h2 className="text-2xl font-bold">Access Denied</h2>
            <p className="text-slate-600">You do not have permission to view this page.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 md:p-8 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">All Shipments</h1>
          <p className="text-slate-600">Manage and track all member shipments across the platform.</p>
        </div>

        <AdminHeader />

        {/* Filter Bar */}
        <Card className="bg-white border-0 shadow-sm mt-8 mb-6">
          <CardContent className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                <Input
                  placeholder="Search shipments, members..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9 border-slate-200"
                />
              </div>

              {/* Status Filter */}
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="border-slate-200">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  {uniqueStatuses.map(status => (
                    <SelectItem key={status} value={status}>{status}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white border-0 shadow-sm">
          <CardHeader>
            <CardTitle>Shipment Management ({filteredShipments.length} of {shipments.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Shipment ID</TableHead>
                    <TableHead>Member</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Created Date</TableHead>
                    <TableHead>Ship Date</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? (
                    <TableRow>
                      <TableCell colSpan="6" className="text-center py-16">
                        <Loader2 className="w-8 h-8 text-slate-400 mx-auto animate-spin" />
                      </TableCell>
                    </TableRow>
                  ) : paginatedShipments.length > 0 ? (
                    paginatedShipments.map(shipment => (
                      <TableRow key={shipment.id}>
                        <TableCell className="font-medium">{shipment.shipment_id}</TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{shipment.member_name}</div>
                            <div className="text-sm text-slate-500">{shipment.member_email}</div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={getStatusBadgeVariant(shipment.status)}>
                            {shipment.status}
                          </Badge>
                        </TableCell>
                        <TableCell>{new Date(shipment.created_date).toLocaleDateString()}</TableCell>
                        <TableCell>{shipment.ship_date ? new Date(shipment.ship_date).toLocaleDateString() : 'N/A'}</TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => setViewingShipment(shipment)}>
                                <Eye className="w-4 h-4 mr-2" />
                                View Details
                              </DropdownMenuItem>
                              {shipment.status === 'Pending' ? (
                                <>
                                  <DropdownMenuItem
                                    onClick={() => handleDownloadPackingSlip(shipment)}
                                    disabled={downloadingPackingSlip === shipment.id}
                                  >
                                    {downloadingPackingSlip === shipment.id ? (
                                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    ) : (
                                      <Download className="w-4 h-4 mr-2" />
                                    )}
                                    Packing Slip
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem onClick={() => setMarkingShipped(shipment)}>
                                    <Send className="w-4 h-4 mr-2" />
                                    Mark Shipped
                                  </DropdownMenuItem>
                                </>
                              ) : (
                                <DropdownMenuItem
                                  onClick={() => handleEditShipment(shipment)}
                                  disabled={shipment.status === 'Shipped'}
                                  className={shipment.status === 'Shipped' ? 'opacity-50 cursor-not-allowed' : ''}
                                >
                                  <Edit className="w-4 h-4 mr-2" />
                                  Edit Shipment
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                className="text-red-500 focus:text-red-500"
                                onClick={() => setCancellingShipment(shipment)}>
                                <XCircle className="w-4 h-4 mr-2" />
                                Cancel Shipment
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan="6" className="text-center py-16">
                        <Truck className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                        <h3 className="font-semibold text-slate-800">No Shipments Found</h3>
                        <p className="text-slate-500 text-sm">
                          {searchTerm || statusFilter !== 'all'
                            ? 'Try adjusting your filters to see more shipments.'
                            : 'No shipments have been created yet.'
                          }
                        </p>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
          <PaginationControls
            totalItems={filteredShipments.length}
            itemsPerPage={itemsPerPage}
            setItemsPerPage={setItemsPerPage}
            currentPage={currentPage}
            setCurrentPage={setCurrentPage}
          />
        </Card>
      </div>

      {/* View Shipment Details Modal */}
      {viewingShipment && (
        <ShipmentDetailsModal
          shipment={viewingShipment}
          onClose={() => setViewingShipment(null)}
        />
      )}

      {/* Edit Shipment Modal */}
      {editingShipment && (
        <Dialog open={!!editingShipment} onOpenChange={() => setEditingShipment(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Shipment</DialogTitle>
              <DialogDescription>
                Update shipment {editingShipment.shipment_id} details.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="status">Status</Label>
                <Select value={editForm.status} onValueChange={(value) => setEditForm(prev => ({ ...prev, status: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Pending">Pending</SelectItem>
                    <SelectItem value="Preparing">Preparing</SelectItem>
                    <SelectItem value="Shipped">Shipped</SelectItem>
                    <SelectItem value="Cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="tracking_number">Tracking Number</Label>
                <Input
                  id="tracking_number"
                  value={editForm.tracking_number}
                  onChange={(e) => setEditForm(prev => ({ ...prev, tracking_number: e.target.value }))}
                  placeholder="Enter tracking number"
                />
              </div>
              <div>
                <Label htmlFor="ship_date">Ship Date</Label>
                <Input
                  id="ship_date"
                  type="date"
                  value={editForm.ship_date}
                  onChange={(e) => setEditForm(prev => ({ ...prev, ship_date: e.target.value }))}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditingShipment(null)} disabled={saving}>
                Cancel
              </Button>
              <Button onClick={handleUpdateShipment} disabled={saving}>
                {saving ? (
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                ) : null}
                Update Shipment
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Mark Shipped Modal */}
      {markingShipped && (
        <Dialog open={!!markingShipped} onOpenChange={() => setMarkingShipped(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Mark Shipment as Shipped</DialogTitle>
              <DialogDescription>
                Enter tracking and cost details for shipment {markingShipped.shipment_id}. An invoice will be generated for shipping & fulfillment fees.
              </DialogDescription>
            </DialogHeader>
            <div className="py-4 space-y-4">
              <div>
                <Label htmlFor="tracking_numbers">Tracking Number(s)</Label>
                <Textarea
                  id="tracking_numbers"
                  value={trackingNumbers}
                  onChange={(e) => setTrackingNumbers(e.target.value)}
                  placeholder="e.g., 94055112062148...&#10;92055902215881..."
                  className="mt-2 min-h-[100px]"
                />
              </div>
              <div>
                <Label htmlFor="shipping-cost">Shipping Cost ($)</Label>
                <Input
                  id="shipping-cost"
                  type="number"
                  value={shippingCost}
                  onChange={(e) => setShippingCost(e.target.value)}
                  placeholder="e.g., 15.50"
                  className="mt-2"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setMarkingShipped(null)}>Cancel</Button>
              <Button onClick={handleMarkShipped} disabled={saving}>
                {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Send className="w-4 h-4 mr-2" />}
                Mark Shipped
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Cancel Shipment Dialog */}
      {cancellingShipment && (
        <Dialog open={!!cancellingShipment} onOpenChange={() => {
          setCancellingShipment(null);
          setCancellationReason("");
        }}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <XCircle className="w-5 h-5 text-red-500" />
                Cancel Shipment
              </DialogTitle>
              <DialogDescription>
                You are about to cancel shipment {cancellingShipment.shipment_id}. Items will be returned to the member's inventory.
              </DialogDescription>
            </DialogHeader>
            <div className="py-4">
              <Label htmlFor="cancellation-reason">Reason for Cancellation *</Label>
              <Textarea
                id="cancellation-reason"
                value={cancellationReason}
                onChange={(e) => setCancellationReason(e.target.value)}
                placeholder="Please explain why this shipment is being cancelled..."
                className="mt-2 min-h-[100px]"
              />
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => {
                setCancellingShipment(null);
                setCancellationReason("");
              }}>
                Cancel
              </Button>
              <Button
                variant="destructive"
                onClick={handleCancelShipment}
                disabled={saving || !cancellationReason.trim()}
              >
                {saving ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <XCircle className="w-4 h-4 mr-2" />
                )}
                Cancel Shipment
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
