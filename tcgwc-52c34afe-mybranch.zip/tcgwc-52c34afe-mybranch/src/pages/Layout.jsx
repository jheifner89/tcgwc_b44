

import React, { useMemo } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User } from "@/api/entities";
import {
  LayoutDashboard,
  Package,
  FileText,
  ClipboardList,
  Receipt,
  LogOut,
  Shield,
  CreditCard,
  Truck
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { createCustomerPortal } from "@/api/functions";
import { toast } from "sonner";
import ImpersonationBar from "@/components/admin/ImpersonationBar";
import VerifyEmailPrompt from "@/components/auth/VerifyEmailPrompt";

const memberNavigation = [
  { name: "Dashboard", href: createPageUrl("Dashboard"), icon: LayoutDashboard },
  { name: "Products", href: createPageUrl("Products"), icon: Package },
  { name: "My Requests", href: createPageUrl("MyRequests"), icon: ClipboardList },
  { name: "My Invoices", href: createPageUrl("MyInvoices"), icon: Receipt },
  { name: "My Orders", href: createPageUrl("MyOrders"), icon: FileText },
  { name: "My Shipments", href: createPageUrl("MyShipments"), icon: Truck },
];

const adminNavigation = [
  { name: "Admin Dashboard", href: createPageUrl("AdminDashboard"), icon: Shield },
];

export const UserContext = React.createContext(null);
export const useUser = () => React.useContext(UserContext);

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [user, setUser] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const [impersonationData, setImpersonationData] = React.useState(null);

  // Pages that don't require authentication
  const authGateExemptPages = useMemo(() => [
    "CompleteProfile",
    "MembershipSuccess", 
    "MembershipCancelled"
  ], []);

  const loadUser = React.useCallback(async () => {
    try {
      const actualUser = await User.me();
      let currentUser = actualUser;
      let currentImpersonationData = null;

      // Check for impersonation token in URL
      const urlParams = new URLSearchParams(window.location.search);
      const impersonateToken = urlParams.get('impersonate');
      
      // Check for stored impersonation data
      const storedImpersonationData = sessionStorage.getItem('impersonationData');
      
      if (impersonateToken) {
        try {
          const decoded = JSON.parse(atob(decodeURIComponent(impersonateToken)));
          if (decoded.expires > Date.now()) {
            const allUsers = await User.list();
            const targetUser = allUsers.find(u => u.id === decoded.targetUserId);

            if (targetUser) {
              currentUser = targetUser;
              currentImpersonationData = { ...decoded, adminUser: actualUser };
              sessionStorage.setItem('impersonationData', JSON.stringify(currentImpersonationData));
              sessionStorage.setItem('impersonatedUser', JSON.stringify(targetUser));
              const cleanUrl = window.location.pathname;
              window.history.replaceState({}, document.title, cleanUrl);
            } else {
              sessionStorage.removeItem('impersonationData');
              sessionStorage.removeItem('impersonatedUser');
            }
          } else {
            sessionStorage.removeItem('impersonationData');
            sessionStorage.removeItem('impersonatedUser');
          }
        } catch (error) {
          console.error("Invalid impersonation token:", error);
          sessionStorage.removeItem('impersonationData');
          sessionStorage.removeItem('impersonatedUser');
        }
      } else if (storedImpersonationData) {
        try {
          const decoded = JSON.parse(storedImpersonationData);
          if (decoded.expires > Date.now()) {
            const storedUserData = sessionStorage.getItem('impersonatedUser');
            
            if (storedUserData) {
              const targetUser = JSON.parse(storedUserData);
              currentUser = targetUser;
              currentImpersonationData = decoded;
            } else {
              const allUsers = await User.list();
              const targetUser = allUsers.find(u => u.id === decoded.targetUserId);

              if (targetUser) {
                currentUser = targetUser;
                currentImpersonationData = decoded;
                sessionStorage.setItem('impersonatedUser', JSON.stringify(targetUser));
              } else {
                sessionStorage.removeItem('impersonationData');
                sessionStorage.removeItem('impersonatedUser');
              }
            }
          } else {
            sessionStorage.removeItem('impersonationData');
            sessionStorage.removeItem('impersonatedUser');
          }
        } catch (error) {
          console.error("Invalid stored impersonation data:", error);
          sessionStorage.removeItem('impersonationData');
          sessionStorage.removeItem('impersonatedUser');
        }
      }
      
      setUser(currentUser);
      setImpersonationData(currentImpersonationData);

    } catch (error) {
      console.log("User not authenticated");
      setUser(null);
      setImpersonationData(null);
      sessionStorage.removeItem('impersonationData');
      sessionStorage.removeItem('impersonatedUser');
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    loadUser();
  }, [loadUser]);

  const handleLogout = async () => {
    sessionStorage.removeItem('impersonationData');
    sessionStorage.removeItem('impersonatedUser');
    await User.logout();
    window.location.reload();
  };

  const handleManageMembership = async () => {
    toast.info("Redirecting to membership portal...");
    try {
      const response = await createCustomerPortal({});

      if (response.status === 200) {
        const { portal_url } = response.data;
        if (portal_url) {
          window.location.href = portal_url;
        } else {
          throw new Error("No portal URL received");
        }
      } else {
        throw new Error(response.data?.error || "Failed to create customer portal");
      }
    } catch (error) {
      console.error("Stripe Portal Error:", error);
      toast.error("Could not open membership portal. Please contact support.");
    }
  };
  
  const value = { user, impersonationData, loading, reloadUser: loadUser };

  // Exempt pages render without layout
  if (authGateExemptPages.includes(currentPageName)) {
    return <UserContext.Provider value={value}>{children}</UserContext.Provider>;
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-slate-900"></div>
      </div>
    );
  }

  // Simple login screen for unauthenticated users
  if (!user) {
    return (
      <UserContext.Provider value={value}>
        <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 text-center">
            <div className="w-16 h-16 bg-slate-900 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <Package className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-slate-900 mb-2">Welcome to TCGWC</h1>
            <p className="text-slate-600 mb-8">Access exclusive distributor products with your membership.</p>
            <Button
              onClick={() => User.loginWithRedirect(window.location.origin + createPageUrl("Dashboard"))}
              className="w-full bg-slate-900 hover:bg-slate-800 text-white h-12 rounded-xl font-medium"
            >
              Sign In / Create Account
            </Button>
            <p className="text-xs text-slate-400 mt-4">
              Secure authentication powered by Base44
            </p>
          </div>
        </div>
      </UserContext.Provider>
    );
  }

  // Email verification check
  if (!user.email_verified) {
    return <VerifyEmailPrompt userEmail={user.email} />;
  }

  // Profile completion check
  if (!user.profile_completed) {
     return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
        <UserContext.Provider value={value}>
            {children}
        </UserContext.Provider>
      </div>
    );
  }

  const isAdmin = user.role === 'admin';
  const navigation = isAdmin ? [...memberNavigation, ...adminNavigation] : memberNavigation;
  const displayUser = user;

  return (
    <UserContext.Provider value={value}>
      <SidebarProvider>
        <div className="min-h-screen flex w-full bg-slate-50 min-w-fit">
          {/* Impersonation Bar */}
          {impersonationData && (
            <div className="fixed top-0 left-0 right-0 z-50">
              <ImpersonationBar 
                targetUser={displayUser?.full_name || displayUser?.email} 
                onExit={() => { 
                  sessionStorage.removeItem('impersonationData');
                  sessionStorage.removeItem('impersonatedUser');
                  setImpersonationData(null); 
                  window.location.reload();
                }}
              />
            </div>
          )}

          <Sidebar className="border-r border-slate-200 bg-white flex-shrink-0" style={{ marginTop: impersonationData ? '48px' : '0' }}>
            <SidebarHeader className="border-b border-slate-200 p-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-red-100 rounded-xl flex items-center justify-center">
                  <Package className="w-6 h-6 text-red-600" />
                </div>
                <div>
                  <h2 className="font-bold text-slate-900 text-lg">TCGWC</h2>
                </div>
              </div>
            </SidebarHeader>

            <SidebarContent className="p-4">
              <SidebarGroup>
                <SidebarGroupLabel className="text-xs font-semibold text-slate-500 uppercase tracking-wider px-3 py-2">
                  Navigation
                </SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu className="space-y-1">
                    {navigation.map((item) => (
                      <SidebarMenuItem key={item.name}>
                        <SidebarMenuButton
                          asChild
                          className={`hover:bg-slate-100 transition-all duration-200 rounded-lg p-3 ${
                            (location.pathname === item.href || (item.name === 'Admin Dashboard' && currentPageName && currentPageName.startsWith('Admin')))
                              ? 'bg-slate-100 text-slate-900 font-medium'
                              : 'text-slate-600'
                          }`}
                        >
                          <Link to={item.href} className="flex items-center gap-3">
                            <item.icon className="w-5 h-5" />
                            <span>{item.name}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))}
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
            </SidebarContent>

            <SidebarFooter className="border-t border-slate-200 p-6">
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center cursor-pointer">
                        <span className="text-slate-600 font-medium text-sm">
                          {displayUser.full_name?.charAt(0)?.toUpperCase()}
                        </span>
                      </div>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent className="w-56" align="end" forceMount>
                      <DropdownMenuLabel className="font-normal">
                        <div className="flex flex-col space-y-1">
                          <p className="text-sm font-medium leading-none">{displayUser.full_name}</p>
                          <p className="text-xs leading-none text-muted-foreground">
                            {displayUser.email}
                          </p>
                        </div>
                      </DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={handleManageMembership} disabled={!displayUser.stripe_customer_id}>
                        <CreditCard className="mr-2 h-4 w-4" />
                        <span>Manage Membership</span>
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={handleLogout}>
                        <LogOut className="mr-2 h-4 w-4" />
                        <span>Log out</span>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>

                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-slate-900 text-sm truncate">{displayUser.full_name}</p>
                    <div className="flex items-center gap-2">
                      <p className="text-xs text-slate-500 truncate">{displayUser.company_name}</p>
                      {!impersonationData && isAdmin && <Badge variant="secondary" className="text-xs">Admin</Badge>}
                    </div>
                  </div>
                </div>

                <div className="bg-slate-50 rounded-lg p-3">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs text-slate-500">Membership</span>
                    {!impersonationData && isAdmin ? (
                       <Badge variant="secondary" className="text-xs bg-purple-100 text-purple-800">Admin Access</Badge>
                    ) : (
                      <Badge
                        variant={displayUser.membership_status === 'active' ? 'default' : 'secondary'}
                        className="text-xs"
                      >
                        {displayUser.membership_status}
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-500">Account Credit</span>
                    <span className="text-sm font-semibold text-slate-900">
                      ${(displayUser.account_credit || 0).toFixed(2)}
                    </span>
                  </div>
                </div>

                <Button
                  variant="ghost"
                  onClick={handleLogout}
                  className="w-full justify-start text-slate-600 hover:text-slate-900 hover:bg-slate-100 md:hidden"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Sign Out
                </Button>
              </div>
            </SidebarFooter>
          </Sidebar>

          <main className="flex-1 flex flex-col bg-slate-50 min-w-0" style={{ marginTop: impersonationData ? '48px' : '0' }}>
            <header className="bg-white border-b border-slate-200 px-6 py-4 md:hidden">
              <div className="flex items-center gap-4">
                <SidebarTrigger className="hover:bg-slate-100 p-2 rounded-lg transition-colors duration-200" />
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-red-100 rounded-lg flex items-center justify-center">
                    <Package className="w-5 h-5 text-red-600" />
                  </div>
                  <h1 className="text-xl font-semibold text-slate-900">TCGWC</h1>
                </div>
              </div>
            </header>

            <div className="flex-1 overflow-auto bg-slate-50">
              {children}
            </div>
          </main>
        </div>
      </SidebarProvider>
    </UserContext.Provider>
  );
}

