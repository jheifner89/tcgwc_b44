import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Package, Building, User as UserIcon, MapPin, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

const US_STATES = [
  "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA", "HI", "ID", "IL", "IN", "IA", "KS",
  "KY", "LA", "ME", "MD", "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM", "NY",
  "NC", "ND", "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY"
];

export default function CompleteProfile() {
  const [formData, setFormData] = useState({
    name_or_company: "",
    street: "",
    suite: "",
    city: "",
    state: "",
    zip: ""
  });
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    checkUserStatus();
  }, []);

  const checkUserStatus = async () => {
    try {
      const userData = await User.me();
      setUser(userData);
      
      // If profile already completed, redirect to dashboard
      if (userData.profile_completed) {
        navigate(createPageUrl("Dashboard"));
        return;
      }

      // Pre-fill any existing data
      if (userData.name_or_company) setFormData(prev => ({ ...prev, name_or_company: userData.name_or_company }));
      if (userData.address) {
        setFormData(prev => ({
          ...prev,
          street: userData.address.street || "",
          suite: userData.address.suite || "",
          city: userData.address.city || "",
          state: userData.address.state || "",
          zip: userData.address.zip || ""
        }));
      }
      
    } catch (error) {
      // User not authenticated, redirect to login
      navigate(createPageUrl("Register"));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.name_or_company.trim()) {
      newErrors.name_or_company = "Name or company is required";
    }
    
    if (!formData.street.trim()) {
      newErrors.street = "Street address is required";
    }
    
    if (!formData.city.trim()) {
      newErrors.city = "City is required";
    }
    
    if (!formData.state) {
      newErrors.state = "State is required";
    }
    
    if (!formData.zip.trim()) {
      newErrors.zip = "ZIP code is required";
    } else if (!/^\d{5}(-\d{4})?$/.test(formData.zip)) {
      newErrors.zip = "Invalid ZIP code format";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setLoading(true);
    try {
      await User.updateMyUserData({
        name_or_company: formData.name_or_company,
        address: {
          street: formData.street,
          suite: formData.suite,
          city: formData.city,
          state: formData.state,
          zip: formData.zip
        },
        profile_completed: true
      });
      
      toast.success("Profile completed successfully!");
      navigate(createPageUrl("Dashboard"));
      
    } catch (error) {
      console.error("Profile completion error:", error);
      toast.error("Failed to save profile. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: "" }));
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-slate-900"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl bg-white border-0 shadow-xl">
        <CardHeader className="text-center pb-8">
          <div className="w-16 h-16 bg-slate-900 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Package className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="text-2xl font-bold text-slate-900">Complete Your Profile</CardTitle>
          <p className="text-slate-600">Help us set up your trading card distribution account</p>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Name/Company */}
            <div className="space-y-2">
              <Label htmlFor="name_or_company">Name or Company *</Label>
              <div className="relative">
                <Building className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  id="name_or_company"
                  value={formData.name_or_company}
                  onChange={(e) => handleChange('name_or_company', e.target.value)}
                  className={`pl-10 ${errors.name_or_company ? 'border-red-500' : ''}`}
                  placeholder="Your name or business name"
                />
              </div>
              {errors.name_or_company && (
                <div className="flex items-center gap-1 text-red-600 text-sm">
                  <AlertCircle className="w-4 h-4" />
                  {errors.name_or_company}
                </div>
              )}
            </div>

            {/* Address Section */}
            <div className="space-y-4">
              <h3 className="font-medium text-slate-900 flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                Business Address
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-2 space-y-2">
                  <Label htmlFor="street">Street Address *</Label>
                  <Input
                    id="street"
                    value={formData.street}
                    onChange={(e) => handleChange('street', e.target.value)}
                    className={errors.street ? 'border-red-500' : ''}
                    placeholder="123 Main Street"
                  />
                  {errors.street && (
                    <div className="flex items-center gap-1 text-red-600 text-sm">
                      <AlertCircle className="w-4 h-4" />
                      {errors.street}
                    </div>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="suite">Suite/Unit</Label>
                  <Input
                    id="suite"
                    value={formData.suite}
                    onChange={(e) => handleChange('suite', e.target.value)}
                    placeholder="Suite 100"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="city">City *</Label>
                  <Input
                    id="city"
                    value={formData.city}
                    onChange={(e) => handleChange('city', e.target.value)}
                    className={errors.city ? 'border-red-500' : ''}
                    placeholder="City"
                  />
                  {errors.city && (
                    <div className="flex items-center gap-1 text-red-600 text-sm">
                      <AlertCircle className="w-4 h-4" />
                      {errors.city}
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="state">State *</Label>
                  <select
                    id="state"
                    value={formData.state}
                    onChange={(e) => handleChange('state', e.target.value)}
                    className={`flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 ${errors.state ? 'border-red-500' : ''}`}
                  >
                    <option value="">Select State</option>
                    {US_STATES.map(state => (
                      <option key={state} value={state}>{state}</option>
                    ))}
                  </select>
                  {errors.state && (
                    <div className="flex items-center gap-1 text-red-600 text-sm">
                      <AlertCircle className="w-4 h-4" />
                      {errors.state}
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="zip">ZIP Code *</Label>
                  <Input
                    id="zip"
                    value={formData.zip}
                    onChange={(e) => handleChange('zip', e.target.value)}
                    className={errors.zip ? 'border-red-500' : ''}
                    placeholder="12345"
                  />
                  {errors.zip && (
                    <div className="flex items-center gap-1 text-red-600 text-sm">
                      <AlertCircle className="w-4 h-4" />
                      {errors.zip}
                    </div>
                  )}
                </div>
              </div>
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full h-12 bg-slate-900 hover:bg-slate-800 text-white font-medium"
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Completing Profile...
                </>
              ) : (
                "Complete Profile"
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}