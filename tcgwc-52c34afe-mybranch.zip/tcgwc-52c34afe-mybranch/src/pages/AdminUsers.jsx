
import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import AdminHeader from "@/components/admin/AdminHeader";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import {
  Users,
  Search,
  Shield,
  Save,
  UserCheck,
  UserX,
  Wallet,
  MoreVertical,
  Trash2,
  FileText as ResellerIcon,
  Eye
} from "lucide-react";
import { toast } from "sonner";
import ConfirmationDialog from "@/components/ui/ConfirmationDialog";
import PaginationControls from "@/components/ui/PaginationControls";
import { createImpersonationSession } from "@/api/functions";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function AdminUsers() {
  const [currentUser, setCurrentUser] = useState(null);
  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [editingUser, setEditingUser] = useState(null);
  const [editUserModal, setEditUserModal] = useState(false);
  const [saving, setSaving] = useState(false);
  const [deletingUser, setDeletingUser] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(25);
  
  // Create user modal state removed

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    setFilteredUsers(
      users.filter((user) =>
        (user.full_name || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (user.email || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (user.name_or_company || '').toLowerCase().includes(searchTerm.toLowerCase())
      )
    );
    setCurrentPage(1);
  }, [searchTerm, users]);

  const loadData = async () => {
    setLoading(true);
    try {
      const me = await User.me();
      setCurrentUser(me);

      if (me.role !== 'admin') {
        setLoading(false);
        return;
      }

      const allUsers = await User.list();
      setUsers(allUsers);
    } catch (error) {
      toast.error(`Failed to load page data: ${error.message}`);
      console.error("Failed to load page data:", error);
    } finally {
      setLoading(false);
    }
  };

  // handleCreateUser function is removed from this component

  const handleViewAsUser = async (user) => {
    try {
      toast.info("Creating impersonation session...");
      const response = await createImpersonationSession({ userId: user.id });

      if (response.status === 200) {
        const { impersonation_url } = response.data;
        window.open(impersonation_url, '_blank');
        toast.success(`Now viewing as ${user.full_name}`);
      } else {
        throw new Error(response.data?.error || "Failed to create impersonation session");
      }
    } catch (error) {
      console.error("Impersonation error:", error);
      toast.error("Failed to create impersonation session. Please try again.");
    }
  };

  const openEditModal = (user) => {
    setEditingUser({ ...user });
    setEditUserModal(true);
  };

  const handleUpdateUser = async () => {
    setSaving(true);
    try {
        const { id, ...dataToUpdate } = editingUser;
        const validUpdateData = {
          full_name: dataToUpdate.full_name,
          email: dataToUpdate.email,
          role: dataToUpdate.role,
          is_reseller: dataToUpdate.is_reseller,
          email_verified: dataToUpdate.email_verified,
          tax_id: dataToUpdate.tax_id,
          stripe_customer_id: dataToUpdate.stripe_customer_id,
          stripe_subscription_id: dataToUpdate.stripe_subscription_id
        };

        await User.update(id, validUpdateData);
        toast.success(`User ${editingUser.email} updated successfully.`);
        setEditUserModal(false);
        await loadData();
    } catch (error) {
        toast.error(`Failed to update user: ${error.message}`);
    } finally {
        setSaving(false);
    }
  };

  const confirmDeleteUser = async () => {
    if (!deletingUser) return;
    try {
      if (deletingUser.role === 'admin') {
        const adminUsers = users.filter(u => u.role === 'admin');
        if (adminUsers.length <= 1) {
          toast.error("Cannot delete the last remaining admin account.");
          setDeletingUser(null);
          return;
        }
      }
      await User.delete(deletingUser.id);
      toast.success(`User ${deletingUser.email} has been deleted.`);
      setDeletingUser(null);
      await loadData();
    } catch (error) {
      toast.error(`Failed to delete user: ${error.message}`);
    }
  };

  const paginatedUsers = filteredUsers.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <p className="text-lg text-slate-600">Loading users...</p>
      </div>
    );
  }

  if (!currentUser || currentUser.role !== 'admin') {
    return (
      <div className="flex items-center justify-center h-screen">
        <p className="text-lg text-red-500">Access Denied: You must be an admin to view this page.</p>
      </div>
    );
  }

  return (
    <div className="p-6 md:p-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-slate-900 mb-2">User Management</h1>
        <AdminHeader />

        <div className="flex justify-between items-center mb-6 mt-8">
          <div className="flex-1 max-w-md">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
              <Input
                placeholder="Search users by name or email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9 border-slate-200"
              />
            </div>
          </div>
          {/* Create User button removed from here */}
        </div>

        <Card className="bg-white border-0 shadow-sm">
          <CardHeader>
            <CardTitle>All Users ({filteredUsers.length})</CardTitle>
            <CardDescription>Search and manage all users in the system.</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Member Since</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {paginatedUsers.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>
                        <div className="font-medium">{user.full_name || user.name_or_company}</div>
                        <div className="text-sm text-slate-500">{user.email}</div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={user.email_verified ? "default" : "secondary"}>
                          {user.email_verified ? 'Verified' : 'Pending'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={user.role === 'admin' ? "destructive" : "outline"}>
                          {user.role}
                        </Badge>
                      </TableCell>
                      <TableCell>{new Date(user.created_date).toLocaleDateString()}</TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon"><MoreVertical className="w-4 h-4" /></Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleViewAsUser(user)}>
                              <Eye className="w-4 h-4 mr-2" />
                              View as User
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => openEditModal(user)}>
                              Edit User
                            </DropdownMenuItem>
                            {currentUser && currentUser.id !== user.id && (
                              <DropdownMenuItem
                                onClick={() => setDeletingUser(user)}
                                className="text-red-500 focus:text-red-500 focus:bg-red-50"
                              >
                                <Trash2 className="w-4 h-4 mr-2" />Delete User
                              </DropdownMenuItem>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
          <PaginationControls
            totalItems={filteredUsers.length}
            itemsPerPage={itemsPerPage}
            setItemsPerPage={setItemsPerPage}
            currentPage={currentPage}
            setCurrentPage={setCurrentPage}
          />
        </Card>

        {/* Create User Modal is removed */}
        
        {/* Edit User Modal */}
        {editingUser && (
          <Dialog open={editUserModal} onOpenChange={setEditUserModal}>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Edit User</DialogTitle>
                <DialogDescription>
                  Update details for {editingUser?.full_name || editingUser?.email}.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="fullName" className="text-right">
                    Full Name
                  </Label>
                  <Input
                    id="fullName"
                    value={editingUser.full_name || editingUser.name_or_company || ''}
                    onChange={(e) => setEditingUser({ ...editingUser, full_name: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="email" className="text-right">
                    Email
                  </Label>
                  <Input
                    id="email"
                    value={editingUser.email || ''}
                    onChange={(e) => setEditingUser({ ...editingUser, email: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="role" className="text-right">
                    Role
                  </Label>
                  <Select
                    value={editingUser.role || ''}
                    onValueChange={(value) => setEditingUser({ ...editingUser, role: value })}
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Select a role" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="user">User</SelectItem>
                      <SelectItem value="admin">Admin</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="is_reseller" className="text-right">
                    Reseller
                  </Label>
                  <Select
                    value={editingUser.is_reseller ? 'true' : 'false'}
                    onValueChange={(value) => setEditingUser({ ...editingUser, is_reseller: value === 'true' })}
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Select reseller status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="false">No (Taxable)</SelectItem>
                      <SelectItem value="true">Yes (Tax Exempt)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="emailVerified" className="text-right">
                    Email Verified
                  </Label>
                  <Select
                    value={editingUser.email_verified ? 'true' : 'false'}
                    onValueChange={(value) => setEditingUser({ ...editingUser, email_verified: value === 'true' })}
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Select verification status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="true">Verified</SelectItem>
                      <SelectItem value="false">Not Verified</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="tax_id" className="text-right">
                    Tax ID
                  </Label>
                  <Input
                    id="tax_id"
                    value={editingUser.tax_id || ''}
                    onChange={(e) => setEditingUser({ ...editingUser, tax_id: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="stripe_customer_id" className="text-right">
                    Stripe Customer ID
                  </Label>
                  <Input
                    id="stripe_customer_id"
                    value={editingUser.stripe_customer_id || ''}
                    onChange={(e) => setEditingUser({ ...editingUser, stripe_customer_id: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="stripe_subscription_id" className="text-right">
                    Stripe Sub ID
                  </Label>
                  <Input
                    id="stripe_subscription_id"
                    value={editingUser.stripe_subscription_id || ''}
                    onChange={(e) => setEditingUser({ ...editingUser, stripe_subscription_id: e.target.value })}
                    className="col-span-3"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setEditUserModal(false)}>Cancel</Button>
                <Button onClick={handleUpdateUser} disabled={saving} className="bg-green-600 hover:bg-green-700 text-white">
                  {saving ? <><Save className="mr-2 h-4 w-4 animate-spin" /> Saving...</> : "Save changes"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}

        <ConfirmationDialog
          open={!!deletingUser}
          onOpenChange={() => setDeletingUser(null)}
          title="Delete User"
          description={`Are you sure you want to delete the user ${deletingUser?.email}? This action cannot be undone.`}
          onConfirm={confirmDeleteUser}
          confirmText="Yes, Delete User"
          variant="destructive"
        />
      </div>
    </div>
  );
}
