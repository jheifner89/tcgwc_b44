import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { calculateAllocation } from '@/api/functions';
import { commitAllocation } from '@/api/functions';
import { toast } from 'sonner';
import { Loader2, CheckCircle, XCircle, Users, BarChart } from 'lucide-react';
import ConfirmationDialog from '../ui/ConfirmationDialog';

export default function AllocationModal({ product, isOpen, onClose, onComplete }) {
  const [step, setStep] = useState(1); // 1: input qty, 2: report, 3: result
  const [availableQty, setAvailableQty] = useState('');
  const [loading, setLoading] = useState(false);
  const [allocationData, setAllocationData] = useState([]);
  const [commitConfirmOpen, setCommitConfirmOpen] = useState(false);
  const [commitResult, setCommitResult] = useState(null);

  const handleCalculate = async () => {
    const qty = parseInt(availableQty, 10);
    if (isNaN(qty) || qty <= 0) {
      toast.error("Please enter a valid quantity greater than zero.");
      return;
    }
    setLoading(true);
    try {
      const { data, error } = await calculateAllocation({ productId: product.id, availableQuantity: qty });
      if (error) throw new Error(error.details || "Calculation failed");

      setAllocationData(data);
      setStep(2);
    } catch (e) {
      toast.error(`Error calculating allocations: ${e.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleCommit = async () => {
    setLoading(true);
    try {
      const { data, error } = await commitAllocation({ productId: product.id, allocations: allocationData });
      if (error) throw new Error(error.details || "Commit failed");
      
      setCommitResult(data);
      setStep(3);
      toast.success("Allocations have been successfully committed.");
    } catch (e) {
      toast.error(`Error committing allocations: ${e.message}`);
    } finally {
      setLoading(false);
      setCommitConfirmOpen(false);
    }
  };

  const resetAndClose = () => {
    setStep(1);
    setAvailableQty('');
    setAllocationData([]);
    setCommitResult(null);
    onClose();
    if(step === 3) onComplete(); // Refresh product list if we completed an allocation
  };
  
  const totalAllocated = allocationData.reduce((sum, item) => sum + item.finalAllocation, 0);

  const renderStep1 = () => (
    <>
      <DialogHeader>
        <DialogTitle>Calculate Allocations for "{product.name}"</DialogTitle>
        <DialogDescription>Enter the total quantity available for allocation among all requesting members.</DialogDescription>
      </DialogHeader>
      <div className="py-4">
        <Label htmlFor="quantity">Available Quantity</Label>
        <Input
          id="quantity"
          type="number"
          value={availableQty}
          onChange={(e) => setAvailableQty(e.target.value)}
          placeholder="e.g., 100"
          className="mt-2"
        />
      </div>
      <DialogFooter>
        <Button variant="outline" onClick={resetAndClose}>Cancel</Button>
        <Button onClick={handleCalculate} disabled={loading}>
          {loading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
          Calculate
        </Button>
      </DialogFooter>
    </>
  );

  const renderStep2 = () => (
    <>
      <DialogHeader>
        <DialogTitle>Allocation Report for "{product.name}"</DialogTitle>
        <DialogDescription>
          Review the calculated allocations based on spend history. Total available: {availableQty}. Total allocated: {totalAllocated}.
        </DialogDescription>
      </DialogHeader>
      <ScrollArea className="h-[50vh] my-4 border rounded-md">
        <Table>
          <TableHeader className="sticky top-0 bg-slate-50">
            <TableRow>
              <TableHead>Member</TableHead>
              <TableHead>Spend</TableHead>
              <TableHead>%</TableHead>
              <TableHead>Requested</TableHead>
              <TableHead>Allocated</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {allocationData.length > 0 ? allocationData.map(item => (
              <TableRow key={item.userId}>
                <TableCell>{item.userName}</TableCell>
                <TableCell>${item.spend.toFixed(2)}</TableCell>
                <TableCell>{(item.percentage * 100).toFixed(2)}%</TableCell>
                <TableCell>{item.originalRequest}</TableCell>
                <TableCell className="font-bold">{item.finalAllocation}</TableCell>
              </TableRow>
            )) : (
              <TableRow>
                <TableCell colSpan="5" className="text-center py-8">
                  No requests found for this product.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </ScrollArea>
      <DialogFooter>
        <Button variant="outline" onClick={() => setStep(1)}>Back</Button>
        <Button variant="destructive" onClick={() => setCommitConfirmOpen(true)} disabled={loading || allocationData.length === 0}>
            {loading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
            Confirm & Commit
        </Button>
      </DialogFooter>
      <ConfirmationDialog
        open={commitConfirmOpen}
        onOpenChange={setCommitConfirmOpen}
        title="Confirm Allocations"
        description="This will permanently adjust member requests to the new allocated quantities and send notifications. This action cannot be undone."
        onConfirm={handleCommit}
        variant="destructive"
        confirmText="Yes, Commit Allocations"
      />
    </>
  );
  
  const renderStep3 = () => (
    <>
      <DialogHeader>
        <DialogTitle>Allocation Complete</DialogTitle>
        <DialogDescription>The allocation process for "{product.name}" has finished.</DialogDescription>
      </DialogHeader>
      <div className="py-8 text-center flex flex-col items-center">
        <CheckCircle className="w-16 h-16 text-green-500 mb-4" />
        <h3 className="text-lg font-semibold text-slate-900">Summary</h3>
        <p className="text-slate-600">
          Updated {commitResult?.updated || 0} requests and cancelled {commitResult?.deleted || 0} requests.
        </p>
      </div>
      <DialogFooter>
        <Button onClick={resetAndClose}>Close</Button>
      </DialogFooter>
    </>
  );

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl">
        {step === 1 && renderStep1()}
        {step === 2 && renderStep2()}
        {step === 3 && renderStep3()}
      </DialogContent>
    </Dialog>
  );
}