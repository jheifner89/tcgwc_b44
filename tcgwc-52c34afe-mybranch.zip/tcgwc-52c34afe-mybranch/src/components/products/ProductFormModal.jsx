
import React, { useState, useEffect } from "react";
import { Product } from "@/api/entities";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Save, X, AlertCircle } from "lucide-react";
import { toast } from "sonner";

const DISTRIBUTORS = ["Southern Hobby", "Magazine Exchange", "Madal"];
const PRODUCT_LINES = [
  "Pokemon EN", "Magic the Gathering", "Riftbound", "Lorcana", 
  "Flesh and Blood", "YuGiOh", "Gundam TCG", "Union Arena", 
  "Weiss Schwarz", "Star Wars Unlimited", "Supplies", "Uncategorized"
];
const AVAILABILITY_OPTIONS = ["Open", "Pre-Order", "Special Offer"];

export default function ProductFormModal({ product, onClose, onSave }) {
  const [formData, setFormData] = useState({
    sku: "",
    name: "",
    distributor: "",
    product_line: "",
    wholesale_price: "",
    override_price: "",
    override_end_date: "",
    orders_due_date: "",
    release_date: "",
    availability: "Open",
    in_stock: true,
    image_url: "",
    product_url: "",
    approved: false // Added 'approved' field
  });
  const [saving, setSaving] = useState(false);
  const [validationErrors, setValidationErrors] = useState({});

  useEffect(() => {
    if (product) {
      setFormData({
        sku: product.sku || "",
        name: product.name || "",
        distributor: product.distributor || "",
        product_line: product.product_line || "",
        wholesale_price: product.wholesale_price?.toString() || "",
        override_price: product.override_price?.toString() || "",
        override_end_date: product.override_end_date || "",
        orders_due_date: product.orders_due_date || "",
        release_date: product.release_date || "",
        availability: product.availability || "Open",
        in_stock: product.in_stock ?? true,
        image_url: product.image_url || "",
        product_url: product.product_url || "",
        approved: product.approved ?? false // Initialize 'approved' from product data
      });
    }
  }, [product]);

  const validateForm = () => {
    const errors = {};

    // Validate override price logic
    if (formData.override_price && parseFloat(formData.override_price) > 0) {
      if (!formData.override_end_date) {
        errors.override_end_date = "Override end date is required when setting an override price";
      } else {
        const endDate = new Date(formData.override_end_date);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        if (endDate <= today) {
          errors.override_end_date = "Override end date must be in the future";
        }
      }
    }

    // Validate orders due date for Pre-Order and Special Offer
    if (["Pre-Order", "Special Offer"].includes(formData.availability)) {
      if (!formData.orders_due_date) {
        errors.orders_due_date = "Orders due date is required for Pre-Order and Special Offer products";
      }
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    // Clear validation error for this field when user starts typing
    if (validationErrors[field]) {
      setValidationErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast.error("Please fix the validation errors before saving.");
      return;
    }
    
    setSaving(true);

    try {
      // Convert numeric fields and ensure null for empty strings for optional fields
      const processedData = {
        ...formData,
        sku: formData.sku || null, // SKU can be optional, store as null if empty
        wholesale_price: parseFloat(formData.wholesale_price),
        override_price: formData.override_price ? parseFloat(formData.override_price) : null,
        override_end_date: formData.override_end_date || null,
        orders_due_date: formData.orders_due_date || null,
        release_date: formData.release_date || null,
        image_url: formData.image_url || null,
        product_url: formData.product_url || null,
        // approved (boolean) is directly passed from formData
      };

      if (product) {
        await Product.update(product.id, processedData);
        toast.success("Product updated successfully!");
      } else {
        await Product.create(processedData);
        toast.success("Product created successfully!");
      }

      onSave();
    } catch (error) {
      console.error("Error saving product:", error);
      toast.error("Failed to save product. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{product ? "Edit Product" : "Add New Product"}</DialogTitle>
          <DialogDescription>
            {product ? "Update the product information below." : "Fill in the product details to add it to your catalog."}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Basic Information */}
            <div className="space-y-2">
              <Label htmlFor="sku">SKU</Label>
              <Input
                id="sku"
                value={formData.sku}
                onChange={(e) => handleInputChange('sku', e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="name">Product Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="distributor">Distributor *</Label>
              <Select value={formData.distributor} onValueChange={(value) => handleInputChange('distributor', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select distributor" />
                </SelectTrigger>
                <SelectContent>
                  {DISTRIBUTORS.map(dist => (
                    <SelectItem key={dist} value={dist}>{dist}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="product_line">Product Line *</Label>
              <Select value={formData.product_line} onValueChange={(value) => handleInputChange('product_line', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select product line" />
                </SelectTrigger>
                <SelectContent>
                  {PRODUCT_LINES.map(line => (
                    <SelectItem key={line} value={line}>{line}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Pricing */}
            <div className="space-y-2">
              <Label htmlFor="wholesale_price">Wholesale Price *</Label>
              <Input
                id="wholesale_price"
                type="number"
                step="0.01"
                value={formData.wholesale_price}
                onChange={(e) => handleInputChange('wholesale_price', e.target.value)}
                required
              />
            </div>

            {/* Override Pricing */}
            <div className="space-y-2">
              <Label htmlFor="override_price">Override Price</Label>
              <Input
                id="override_price"
                type="number"
                step="0.01"
                value={formData.override_price}
                onChange={(e) => handleInputChange('override_price', e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="override_end_date">Override End Date</Label>
              <Input
                id="override_end_date"
                type="date"
                value={formData.override_end_date}
                onChange={(e) => handleInputChange('override_end_date', e.target.value)}
                className={validationErrors.override_end_date ? "border-red-500" : ""}
              />
              {validationErrors.override_end_date && (
                <div className="flex items-center gap-1 text-red-600 text-sm">
                  <AlertCircle className="w-4 h-4" />
                  {validationErrors.override_end_date}
                </div>
              )}
            </div>

            {/* Availability */}
            <div className="space-y-2">
              <Label htmlFor="availability">Availability</Label>
              <Select value={formData.availability} onValueChange={(value) => handleInputChange('availability', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {AVAILABILITY_OPTIONS.map(option => (
                    <SelectItem key={option} value={option}>{option}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="orders_due_date">Orders Due Date</Label>
              <Input
                id="orders_due_date"
                type="date"
                value={formData.orders_due_date}
                onChange={(e) => handleInputChange('orders_due_date', e.target.value)}
                className={validationErrors.orders_due_date ? "border-red-500" : ""}
              />
              {validationErrors.orders_due_date && (
                <div className="flex items-center gap-1 text-red-600 text-sm">
                  <AlertCircle className="w-4 h-4" />
                  {validationErrors.orders_due_date}
                </div>
              )}
              <p className="text-xs text-slate-500">Required for Pre-Order and Special Offer products. Can be past or future date.</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="release_date">Release Date</Label>
              <Input
                id="release_date"
                type="date"
                value={formData.release_date}
                onChange={(e) => handleInputChange('release_date', e.target.value)}
              />
            </div>
          </div>

          {/* Full width fields */}
          <div className="space-y-2">
            <Label htmlFor="image_url">Image URL</Label>
            <Input
              id="image_url"
              value={formData.image_url}
              onChange={(e) => handleInputChange('image_url', e.target.value)}
              placeholder="https://example.com/image.jpg"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="product_url">Product URL</Label>
            <Input
              id="product_url"
              value={formData.product_url}
              onChange={(e) => handleInputChange('product_url', e.target.value)}
              placeholder="URL to distributor's product page"
            />
          </div>

          <div className="flex gap-8 pt-2"> {/* Grouping in_stock and approved checkboxes */}
            <div className="flex items-center space-x-2">
              <Checkbox
                id="in_stock"
                checked={formData.in_stock}
                onCheckedChange={(checked) => handleInputChange('in_stock', checked)}
              />
              <Label htmlFor="in_stock">In Stock</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="approved"
                checked={formData.approved}
                onCheckedChange={(checked) => handleInputChange('approved', checked)}
              />
              <Label htmlFor="approved">Approved for Portal</Label>
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
              ) : (
                <Save className="w-4 h-4 mr-2" />
              )}
              {saving ? "Saving..." : "Save Product"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
