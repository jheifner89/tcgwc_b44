import React, { useState, useEffect } from 'react';
import { Product } from '@/api/entities';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { format } from 'date-fns';
import { Calendar as CalendarIcon, Plus } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { PackagePlus, PenSquare, Search, Loader2, ArrowLeft, CreditCard } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useDebounce } from '@/components/hooks/useDebounce';

const ManualEntryForm = ({ onSave, onBack }) => {
    const [description, setDescription] = useState('');
    const [quantity, setQuantity] = useState(1);
    const [unitPrice, setUnitPrice] = useState(0);

    const handleSave = () => {
        if (!description.trim()) {
            toast.error('Description is required.');
            return;
        }
        onSave({
            id: `new_${Date.now()}`,
            product_name: description,
            quantity: Number(quantity) || 1,
            unit_price: Number(unitPrice) || 0,
            total_price: (Number(quantity) || 1) * (Number(unitPrice) || 0),
            item_type: 'adjustment',
        });
    };

    return (
        <div>
            <DialogHeader className="mb-4">
                <DialogTitle>Add Manual Adjustment</DialogTitle>
                <DialogDescription>Add a fee, credit, or other manual line item.</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
                <div className="space-y-2">
                    <Label htmlFor="description">Description</Label>
                    <Input id="description" value={description} onChange={(e) => setDescription(e.target.value)} />
                </div>
                <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                        <Label htmlFor="quantity">Quantity</Label>
                        <Input id="quantity" type="number" value={quantity} onChange={(e) => setQuantity(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="unitPrice">Unit Price</Label>
                        <Input id="unitPrice" type="number" step="0.01" value={unitPrice} onChange={(e) => setUnitPrice(e.target.value)} />
                    </div>
                </div>
            </div>
            <DialogFooter className="mt-6">
                <Button variant="ghost" onClick={onBack}><ArrowLeft className="w-4 h-4 mr-2"/>Back</Button>
                <Button onClick={handleSave}>Add Adjustment</Button>
            </DialogFooter>
        </div>
    );
};

const ProductSearch = ({ onSave, onBack }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [results, setResults] = useState([]);
    const [loading, setLoading] = useState(false);
    const debouncedSearchTerm = useDebounce(searchTerm, 300);

    useEffect(() => {
        const searchProducts = async () => {
            if (!debouncedSearchTerm) {
                setResults([]);
                return;
            }
            setLoading(true);
            try {
                const productData = await Product.filter({
                    name: { $regex: debouncedSearchTerm, $options: 'i' }
                }, null, 10);
                setResults(productData);
            } catch (error) {
                toast.error("Failed to search products.");
            } finally {
                setLoading(false);
            }
        };
        searchProducts();
    }, [debouncedSearchTerm]);

    const handleSelectProduct = (product) => {
        onSave({
            id: `new_${Date.now()}`,
            product_id: product.id,
            product_name: product.name,
            sku: product.sku,
            quantity: 1,
            unit_price: product.wholesale_price || 0,
            total_price: product.wholesale_price || 0,
            item_type: 'product',
        });
    };

    return (
        <div>
            <DialogHeader className="mb-4">
                <DialogTitle>Add Product to Invoice</DialogTitle>
                <DialogDescription>Search for a product to add as a line item.</DialogDescription>
            </DialogHeader>
            <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400"/>
                <Input placeholder="Search by product name..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-9"/>
            </div>
            <ScrollArea className="h-64 mt-4 border rounded-md">
                {loading && <div className="p-4 text-center text-slate-500 flex items-center justify-center gap-2"><Loader2 className="w-4 h-4 animate-spin"/>Searching...</div>}
                {!loading && results.length === 0 && <div className="p-4 text-center text-slate-500">{debouncedSearchTerm ? 'No products found.' : 'Start typing to search.'}</div>}
                {!loading && results.map(product => (
                    <div key={product.id} onClick={() => handleSelectProduct(product)} className="p-3 border-b hover:bg-slate-50 cursor-pointer">
                        <p className="font-medium">{product.name}</p>
                        <p className="text-sm text-slate-500">${product.wholesale_price.toFixed(2)} - SKU: {product.sku}</p>
                    </div>
                ))}
            </ScrollArea>
             <DialogFooter className="mt-6">
                <Button variant="ghost" onClick={onBack}><ArrowLeft className="w-4 h-4 mr-2"/>Back</Button>
            </DialogFooter>
        </div>
    );
};

const AccountCreditForm = ({ onSave, onBack, availableCredit }) => {
    const [creditAmount, setCreditAmount] = useState(0);

    const handleSave = () => {
        if (creditAmount <= 0) {
            toast.error('Credit amount must be greater than 0.');
            return;
        }
        if (creditAmount > availableCredit) {
            toast.error(`Credit amount cannot exceed available credit of $${availableCredit.toFixed(2)}.`);
            return;
        }
        onSave({
            id: `new_${Date.now()}`,
            product_name: 'Account Credit Used',
            quantity: 1,
            unit_price: -creditAmount, // Negative amount for credit
            total_price: -creditAmount,
            item_type: 'credit',
        });
    };

    return (
        <div>
            <DialogHeader className="mb-4">
                <DialogTitle>Apply Account Credit</DialogTitle>
                <DialogDescription>Apply available account credit to this invoice.</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <p className="text-sm text-blue-800">
                        <strong>Available Credit:</strong> ${availableCredit.toFixed(2)}
                    </p>
                </div>
                <div className="space-y-2">
                    <Label htmlFor="creditAmount">Credit Amount to Apply</Label>
                    <Input 
                        id="creditAmount" 
                        type="number" 
                        step="0.01" 
                        value={creditAmount} 
                        onChange={(e) => setCreditAmount(Number(e.target.value) || 0)}
                        max={availableCredit}
                    />
                </div>
                <Button 
                    variant="outline" 
                    onClick={() => setCreditAmount(availableCredit)}
                    className="w-full"
                >
                    Use All Available Credit (${availableCredit.toFixed(2)})
                </Button>
            </div>
            <DialogFooter className="mt-6">
                <Button variant="ghost" onClick={onBack}><ArrowLeft className="w-4 h-4 mr-2"/>Back</Button>
                <Button onClick={handleSave}>Apply Credit</Button>
            </DialogFooter>
        </div>
    );
};

export default function AddLineItemModal({ isOpen, onClose, onSave, availableCredit = 0 }) {
    const [step, setStep] = useState('selection'); // 'selection', 'manual', 'product', 'credit'

    useEffect(() => {
        if (isOpen) {
            setStep('selection');
        }
    }, [isOpen]);

    const handleSaveAndClose = (item) => {
        onSave(item);
        onClose();
    };

    if (!isOpen) return null;

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent>
                {step === 'selection' && (
                    <div>
                        <DialogHeader className="mb-6 text-center">
                            <DialogTitle>Add a New Line Item</DialogTitle>
                            <DialogDescription>What would you like to add to the invoice?</DialogDescription>
                        </DialogHeader>
                        <div className="grid grid-cols-3 gap-4">
                            <Button variant="outline" className="h-24 flex-col gap-2" onClick={() => setStep('product')}>
                                <PackagePlus className="w-6 h-6"/>
                                Add Product
                            </Button>
                            <Button variant="outline" className="h-24 flex-col gap-2" onClick={() => setStep('manual')}>
                                <PenSquare className="w-6 h-6"/>
                                Manual Adjustment
                            </Button>
                            <Button 
                                variant="outline" 
                                className="h-24 flex-col gap-2" 
                                onClick={() => setStep('credit')}
                                disabled={availableCredit <= 0}
                            >
                                <CreditCard className="w-6 h-6"/>
                                Account Credit
                                {availableCredit <= 0 && <span className="text-xs text-slate-400">No credit available</span>}
                            </Button>
                        </div>
                    </div>
                )}
                {step === 'manual' && <ManualEntryForm onSave={handleSaveAndClose} onBack={() => setStep('selection')} />}
                {step === 'product' && <ProductSearch onSave={handleSaveAndClose} onBack={() => setStep('selection')} />}
                {step === 'credit' && (
                    <AccountCreditForm 
                        onSave={handleSaveAndClose} 
                        onBack={() => setStep('selection')} 
                        availableCredit={availableCredit}
                    />
                )}
            </DialogContent>
        </Dialog>
    );
}