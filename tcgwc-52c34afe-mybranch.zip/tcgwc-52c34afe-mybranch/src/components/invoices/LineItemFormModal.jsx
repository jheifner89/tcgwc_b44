import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Save, X } from 'lucide-react';
import { toast } from 'sonner';

export default function LineItemFormModal({ isOpen, onClose, onSave, item }) {
  const [description, setDescription] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [unitPrice, setUnitPrice] = useState(0);

  useEffect(() => {
    if (item) {
      setDescription(item.product_name || '');
      setQuantity(item.quantity || 1);
      setUnitPrice(item.unit_price || 0);
    } else {
      // Reset for new item
      setDescription('');
      setQuantity(1);
      setUnitPrice(0);
    }
  }, [item, isOpen]);

  const handleSave = () => {
    if (!description.trim()) {
      toast.error('Description is required.');
      return;
    }
    if (isNaN(quantity) || quantity <= 0) {
      toast.error('Quantity must be a positive number.');
      return;
    }
    if (isNaN(unitPrice)) {
      toast.error('Unit price must be a number.');
      return;
    }

    const savedItem = {
      ...item,
      product_name: description,
      quantity: Number(quantity),
      unit_price: Number(unitPrice),
      total_price: Number(quantity) * Number(unitPrice),
      item_type: item?.product_id ? 'product' : 'adjustment',
    };
    onSave(savedItem);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{item?.id ? 'Edit' : 'Add'} Line Item</DialogTitle>
          <DialogDescription>
            {item?.product_id ? "Update the product details." : "Add a manual adjustment or fee."}
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Input
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="quantity">Quantity</Label>
              <Input
                id="quantity"
                type="number"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="unitPrice">Unit Price</Label>
              <Input
                id="unitPrice"
                type="number"
                step="0.01"
                value={unitPrice}
                onChange={(e) => setUnitPrice(e.target.value)}
              />
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            <X className="w-4 h-4 mr-2" /> Cancel
          </Button>
          <Button onClick={handleSave}>
            <Save className="w-4 h-4 mr-2" /> Save Item
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}