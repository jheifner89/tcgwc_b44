import React, { useState } from 'react';
import { User } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Mail } from 'lucide-react';
import { toast } from 'sonner';

export default function VerifyEmailPrompt({ userEmail }) {
  const [loading, setLoading] = useState(false);

  const handleResend = async () => {
    setLoading(true);
    try {
      // Use the SDK method to trigger a resend of the verification email
      const { error } = await User.resendVerification({ email: userEmail });
      if (error) {
        throw new Error(error.message);
      }
      toast.success("A new verification email has been sent.");
    } catch (error) {
      toast.error("Failed to resend email. Please try again later.");
      console.error("Resend error:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await User.logout();
    window.location.reload();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-white border-0 shadow-xl text-center">
        <CardHeader>
          <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Mail className="w-8 h-8 text-blue-600" />
          </div>
          <CardTitle className="text-2xl font-bold text-slate-900">Verify Your Email</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <p className="text-slate-600">
            Before you can continue, please verify your email address. We've sent a confirmation link to <strong className="text-slate-800">{userEmail}</strong>.
          </p>
          <p className="text-sm text-slate-500">
            Please check your inbox (and spam folder) and click the link in the email to activate your account.
          </p>
          <div className="space-y-3">
            <Button
              onClick={handleResend}
              disabled={loading}
              className="w-full h-12 bg-slate-900 hover:bg-slate-800 text-white"
            >
              {loading ? "Sending..." : "Resend Verification Email"}
            </Button>
            <Button
              variant="link"
              onClick={handleLogout}
              className="w-full"
            >
              Log Out
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}