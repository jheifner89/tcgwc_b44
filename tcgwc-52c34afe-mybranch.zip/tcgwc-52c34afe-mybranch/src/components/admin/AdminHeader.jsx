import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Shield, ClipboardList, Receipt, FileText, Package, Users, Hammer, Truck } from 'lucide-react';

const adminTabs = [
  { name: 'Dashboard', href: createPageUrl('AdminDashboard'), icon: Shield },
  { name: 'Requests', href: createPageUrl('AdminRequests'), icon: ClipboardList },
  { name: 'Invoices', href: createPageUrl('AdminInvoices'), icon: Receipt },
  { name: 'Orders', href: createPageUrl('AdminOrders'), icon: FileText },
  { name: 'Shipments', href: createPageUrl('AdminShipments'), icon: Truck },
  { name: 'Products', href: createPageUrl('AdminProducts'), icon: Package },
  { name: 'Users', href: createPageUrl('AdminUsers'), icon: Users },
  { name: 'Tools', href: createPageUrl('AdminTools'), icon: Hammer },
];

export default function AdminHeader() {
  const location = useLocation();

  return (
    <div className="mb-8">
      <div className="border-b border-slate-200">
        <nav className="-mb-px flex space-x-6" aria-label="Tabs">
          {adminTabs.map((tab) => (
            <Link
              key={tab.name}
              to={tab.href}
              className={`whitespace-nowrap pb-4 px-1 border-b-2 font-medium text-sm flex items-center gap-2 ${
                location.pathname === tab.href
                  ? 'border-slate-900 text-slate-900'
                  : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.name}
            </Link>
          ))}
        </nav>
      </div>
    </div>
  );
}