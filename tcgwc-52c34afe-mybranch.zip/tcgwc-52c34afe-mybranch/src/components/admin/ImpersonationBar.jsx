import React from 'react';
import { Button } from '@/components/ui/button';
import { UserCheck, X } from 'lucide-react';
import { toast } from 'sonner';
import { endImpersonation } from '@/api/functions';

export default function ImpersonationBar({ targetUser, onExit }) {
  
  const handleExit = async () => {
    toast.info("Ending impersonation session...");
    try {
      await endImpersonation();
      onExit();
    } catch (error) {
      console.error("Error ending impersonation:", error);
      toast.error("Could not end session. Reloading page to fix.");
      // Force exit even if backend call fails
      onExit();
    }
  };

  return (
    <div className="bg-yellow-400 text-yellow-900 px-4 py-3 flex items-center justify-between shadow-lg">
      <div className="flex items-center gap-3">
        <UserCheck className="w-5 h-5" />
        <span className="text-sm font-semibold">
          Viewing as <strong className="font-bold">{targetUser}</strong>
        </span>
      </div>
      <Button
        onClick={handleExit}
        variant="ghost"
        size="sm"
        className="text-yellow-900 hover:bg-yellow-500/50 hover:text-yellow-900 h-auto px-3 py-1"
      >
        <X className="w-4 h-4 mr-2" />
        Exit View
      </Button>
    </div>
  );
}