
import React, { useState, useEffect } from "react";
import { Order } from "@/api/entities";
import { User } from "@/api/entities";
import { Shipment } from "@/api/entities";
import { ShipmentItem } from "@/api/entities";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"; // Added Tooltip imports
import { Loader2, Save, Search, Info } from "lucide-react"; // Added Info import
import { toast } from "sonner";

export default function EditShipmentModal({ shipment, onClose, onShipmentUpdated }) {
  const [availableOrders, setAvailableOrders] = useState([]);
  const [currentShipmentItems, setCurrentShipmentItems] = useState([]);
  const [shipmentItems, setShipmentItems] = useState({}); // { orderId: quantity }
  const [breakdownSelections, setBreakdownSelections] = useState({});
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [user, setUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    if (shipment) {
      loadData();
    }
  }, [shipment]);

  const loadData = async () => {
    setLoading(true);
    try {
      const userData = await User.me();
      setUser(userData);

      // Load current shipment items
      const currentItems = await ShipmentItem.filter({ shipment_id: shipment.id });
      setCurrentShipmentItems(currentItems);

      // Load available orders (In Inventory status)
      const ordersInInventory = await Order.filter({
        member_id: userData.id,
        status: "In Inventory"
      });

      // Also include orders that already have items in this shipment
      const orderIdsInShipment = [...new Set(currentItems.map(item => item.order_id))];
      const ordersWithItemsInShipment = await Promise.all(
        orderIdsInShipment.map(async (orderId) => {
          try {
            return await Order.get(orderId);
          } catch (error) {
            console.warn(`Could not load order ${orderId}`);
            return null;
          }
        })
      );
      
      const validOrdersWithItems = ordersWithItemsInShipment.filter(Boolean);
      
      // Combine and deduplicate orders
      const allPossibleOrders = [...ordersInInventory, ...validOrdersWithItems];
      const uniqueOrders = allPossibleOrders.filter((order, index, self) => 
        index === self.findIndex(o => o.id === order.id)
      );

      setAvailableOrders(uniqueOrders);

      // Pre-populate shipment items with current quantities and breakdowns
      const initialItems = {};
      const initialBreakdowns = {};
      currentItems.forEach(item => {
        initialItems[item.order_id] = item.quantity;
        initialBreakdowns[item.order_id] = item.breakdown || 'No';
      });
      setShipmentItems(initialItems);
      setBreakdownSelections(initialBreakdowns);

    } catch (error) {
      console.error("Error loading edit data:", error);
      toast.error("Failed to load shipment data.");
    } finally {
      setLoading(false);
    }
  };

  const handleQuantityChange = (orderId, value) => {
    const order = availableOrders.find(o => o.id === orderId);
    if (!order) return;

    const currentInShipment = currentShipmentItems.find(item => item.order_id === orderId)?.quantity || 0;
    const availableQty = (order.quantity - (order.shipped_quantity || 0)) + currentInShipment;
    
    const newQty = Math.max(0, Math.min(availableQty, Number(value) || 0));
    setShipmentItems(prev => ({ ...prev, [orderId]: newQty }));
  };

  const handleBreakdownChange = (orderId, value) => {
    setBreakdownSelections(prev => ({ ...prev, [orderId]: value }));
  };

  const handleSubmit = async () => {
    setSubmitting(true);
    toast.info("Updating shipment...");

    try {
      const originalItems = await ShipmentItem.filter({ shipment_id: shipment.id });
      
      // 1. Revert quantities on all original orders
      await Promise.all(
        originalItems.map(async (item) => {
          const order = await Order.get(item.order_id);
          const restoredShippedQty = (order.shipped_quantity || 0) - item.quantity;
          await Order.update(order.id, {
            shipped_quantity: Math.max(0, restoredShippedQty),
            status: "In Inventory"
          });
        })
      );
      
      // 2. Delete all existing shipment items from the database
      await Promise.all(originalItems.map(item => ShipmentItem.delete(item.id)));

      // 3. Create new shipment items and update orders based on the final desired state
      const itemsToShip = Object.entries(shipmentItems).filter(([_, qty]) => qty > 0);
      
      if (itemsToShip.length > 0) {
        await Promise.all(
          itemsToShip.map(async ([orderId, quantity]) => {
            const order = await Order.get(orderId);
            const newShippedQuantity = (order.shipped_quantity || 0) + quantity;
            const newStatus = newShippedQuantity >= order.quantity ? "Complete" : "In Inventory";
            
            await Promise.all([
              ShipmentItem.create({
                shipment_id: shipment.id,
                order_id: orderId,
                product_name: order.product_name,
                quantity: quantity,
                breakdown: breakdownSelections[orderId] || 'No',
              }),
              Order.update(orderId, {
                shipped_quantity: newShippedQuantity,
                status: newStatus
              })
            ]);
          })
        );
      }

      toast.success("Shipment updated successfully!");
      onShipmentUpdated();
      onClose();

    } catch (error) {
      console.error("Shipment update error:", error);
      toast.error("Failed to update shipment. Quantities have been reverted. Please try again.");
       // Reload data to reflect reverted state
      onShipmentUpdated();
    } finally {
      setSubmitting(false);
    }
  };

  const filteredAvailableOrders = availableOrders.filter(order => {
    if (!order) return false;
    const currentInShipment = currentShipmentItems.find(item => item.order_id === order.id)?.quantity || 0;
    const availableQty = (order.quantity - (order.shipped_quantity || 0)) + currentInShipment;
    // Only show if there's something to ship, or if it's already in the shipment
    return (availableQty > 0 || currentInShipment > 0 || (shipmentItems[order.id] && shipmentItems[order.id] > 0)) && order.product_name.toLowerCase().includes(searchTerm.toLowerCase());
  });

  return (
    <Dialog open={!!shipment} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle>Edit Shipment</DialogTitle>
          <DialogDescription>
            Modify items in shipment {shipment?.shipment_id}. Only items with available quantity are shown.
          </DialogDescription>
        </DialogHeader>

        <div className="relative my-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
          <Input
            placeholder="Search available products..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9"
            disabled={loading}
          />
        </div>
        
        <div className="max-h-[50vh] overflow-y-auto pr-4">
          {loading ? (
            <div className="flex justify-center items-center h-48"><Loader2 className="w-8 h-8 animate-spin"/></div>
          ) : filteredAvailableOrders.length > 0 ? (
            <TooltipProvider> {/* Wrapped Table with TooltipProvider */}
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Product</TableHead>
                    <TableHead className="text-center">Available</TableHead>
                    <TableHead className="w-32 text-center">Qty in Shipment</TableHead>
                    <TableHead className="w-48 text-center">
                      <div className="flex items-center justify-center gap-2"> {/* Added flex container */}
                        Breakdown
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Info className="w-4 h-4 text-slate-400 cursor-help" />
                          </TooltipTrigger>
                          <TooltipContent className="max-w-sm text-left">
                            <div className="space-y-2 text-sm font-normal">
                              <div><span className="font-medium">No:</span> No breakdown, will ship as sold</div>
                              <div><span className="font-medium">To Each:</span> Broken down to each unit (i.e. booster cases down to booster boxes)</div>
                              <div><span className="font-medium">Fully:</span> Broken down to smallest saleable unit size (i.e. ETBs down to packs, Commander decks down to the shrink wrapped bricks)</div>
                            </div>
                          </TooltipContent>
                        </Tooltip>
                      </div>
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAvailableOrders.map(order => {
                    const currentInShipment = currentShipmentItems.find(item => item.order_id === order.id)?.quantity || 0;
                    const availableQty = (order.quantity - (order.shipped_quantity || 0)) + currentInShipment;
                    
                    return (
                      <TableRow key={order.id}>
                        <TableCell>{order.product_name}</TableCell>
                        <TableCell className="text-center">{availableQty}</TableCell>
                        <TableCell>
                          <div className="flex items-center justify-center gap-2">
                            <Input
                              type="number"
                              className="w-24 text-center"
                              value={shipmentItems[order.id] || ""}
                              onChange={(e) => handleQuantityChange(order.id, e.target.value)}
                              placeholder="0"
                              max={availableQty}
                              min={0}
                            />
                          </div>
                        </TableCell>
                        <TableCell>
                          <Select
                            value={breakdownSelections[order.id] || 'No'}
                            onValueChange={(value) => handleBreakdownChange(order.id, value)}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Select breakdown" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="No">No</SelectItem>
                              <SelectItem value="To Each">To Each</SelectItem>
                              <SelectItem value="Fully">Fully</SelectItem>
                            </SelectContent>
                          </Select>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </TooltipProvider>
          ) : (
            <div className="text-center py-12">
              <p className="text-slate-500">No products available for this shipment.</p>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={submitting}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={loading || submitting}>
            {submitting ? <Loader2 className="w-4 h-4 animate-spin mr-2"/> : <Save className="w-4 h-4 mr-2" />}
            Update Shipment
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
