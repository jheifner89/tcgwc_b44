
import React, { useState, useEffect } from "react";
import { ShipmentItem } from "@/api/entities";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Loader2, Package, Truck, Hash, Calendar, Copy } from "lucide-react";
import { toast } from "sonner";

export default function ShipmentDetailsModal({ shipment, onClose }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (shipment) {
      loadShipmentItems();
    }
  }, [shipment]);

  const loadShipmentItems = async () => {
    setLoading(true);
    try {
      const shipmentItems = await ShipmentItem.filter({ shipment_id: shipment.id });
      setItems(shipmentItems);
    } catch (error) {
      console.error("Failed to load shipment items:", error);
      toast.error("Could not load shipment details.");
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadgeVariant = (status) => {
    switch (status) {
      case "Pending": return "bg-yellow-100 text-yellow-800";
      case "Preparing": return "bg-blue-100 text-blue-800";
      case "Shipped": return "bg-purple-100 text-purple-800";
      case "Cancelled": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast.success("Copied to clipboard!");
  };

  const trackingNumbers = shipment?.tracking_number ? 
    shipment.tracking_number.split(/[,\n]+/).map(t => t.trim()).filter(Boolean) : [];

  return (
    <Dialog open={!!shipment} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Shipment Details</DialogTitle>
          <DialogDescription>
            Viewing items for shipment ID: {shipment?.shipment_id}
          </DialogDescription>
        </DialogHeader>

        {/* Basic Info Section */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-4 p-4 bg-slate-50 rounded-lg">
          <div className="flex items-start gap-3">
            <Package className="w-5 h-5 text-slate-500 mt-1" />
            <div>
              <p className="text-xs text-slate-500">Status</p>
              <Badge className={`mt-1 ${getStatusBadgeVariant(shipment?.status)}`}>
                {shipment?.status}
              </Badge>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Calendar className="w-5 h-5 text-slate-500 mt-1" />
            <div>
              <p className="text-xs text-slate-500">Created</p>
              <p className="font-medium text-slate-800">{new Date(shipment?.created_date).toLocaleDateString()}</p>
            </div>
          </div>
          {shipment?.ship_date && (
            <div className="flex items-start gap-3">
              <Truck className="w-5 h-5 text-slate-500 mt-1" />
              <div>
                <p className="text-xs text-slate-500">Shipped</p>
                <p className="font-medium text-slate-800">{new Date(shipment.ship_date).toLocaleDateString()}</p>
              </div>
            </div>
          )}
        </div>

        {/* Tracking Section */}
        {trackingNumbers.length > 0 && (
          <div className="mb-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-center gap-2 mb-3">
              <Hash className="w-5 h-5 text-blue-600" />
              <h3 className="font-semibold text-blue-900">Tracking Numbers</h3>
            </div>
            <div className="space-y-2">
              {trackingNumbers.map((trackingNumber, index) => (
                <div key={index} className="flex items-center justify-between bg-white rounded-md p-2 border border-blue-100">
                  <code className="text-sm font-mono text-slate-800 break-all">
                    {trackingNumber}
                  </code>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => copyToClipboard(trackingNumber)}
                    className="ml-2 flex-shrink-0 text-blue-600 hover:text-blue-700 hover:bg-blue-100"
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Items Section */}
        <div className="max-h-[40vh] overflow-y-auto pr-2">
          {loading ? (
            <div className="flex justify-center items-center h-32"><Loader2 className="w-8 h-8 animate-spin"/></div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Product</TableHead>
                  <TableHead className="text-center">Quantity</TableHead>
                  <TableHead className="text-right">Breakdown</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.length > 0 ? (
                  items.map(item => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium">{item.product_name}</TableCell>
                      <TableCell className="text-center">{item.quantity}</TableCell>
                      <TableCell className="text-right">{item.breakdown}</TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan="3" className="text-center py-8">
                      No items found in this shipment.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </div>

        <DialogFooter className="mt-4">
          <Button variant="outline" onClick={onClose}>Close</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
