import React, { useState, useEffect } from "react";
import { Order } from "@/api/entities";
import { User } from "@/api/entities";
import { Shipment } from "@/api/entities";
import { ShipmentItem } from "@/api/entities";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Loader2, Truck, PackageCheck, Search, Info } from "lucide-react";
import { toast } from "sonner";
import { US_STATES } from "@/components/utils/tax";

export default function CreateDropShipmentModal({ isOpen, onClose, onShipmentCreated }) {
  const [availableOrders, setAvailableOrders] = useState([]);
  const [shipmentItems, setShipmentItems] = useState({}); // { orderId: quantity }
  const [breakdownSelections, setBreakdownSelections] = useState({}); // { orderId: 'No' | 'To Each' | 'Fully' }
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [user, setUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [address, setAddress] = useState({ name: '', street: '', suite: '', city: '', state: '', zip: '' });
  const [currentStep, setCurrentStep] = useState(1); // 1 for address, 2 for items

  useEffect(() => {
    if (isOpen) {
      loadUserData();
      // Reset all state on open
      setCurrentStep(1);
      setAddress({ name: '', street: '', suite: '', city: '', state: '', zip: '' });
      setSearchTerm("");
      setShipmentItems({});
      setBreakdownSelections({});
    }
  }, [isOpen]);

  const loadUserData = async () => {
    setLoading(true);
    try {
      const userData = await User.me();
      setUser(userData);
    } catch (e) {
      toast.error("Failed to load user data.");
    } finally {
      setLoading(false);
    }
  };
  
  const loadAvailableOrders = async () => {
    setLoading(true);
    try {
      const orders = await Order.filter({
        member_id: user.id,
        status: "In Inventory"
      });
      const available = orders.filter(o => (o.quantity - (o.shipped_quantity || 0)) > 0);
      setAvailableOrders(available);
    } catch (error) {
      toast.error("Failed to load available items.");
    } finally {
      setLoading(false);
    }
  };

  const handleNextStep = () => {
      // Basic validation for address
      if (!address.name || !address.street || !address.city || !address.state || !address.zip) {
          toast.error("Please fill out all required address fields.");
          return;
      }
      loadAvailableOrders(); // Load items only when proceeding to step 2
      setCurrentStep(2);
  };

  const handleQuantityChange = (orderId, value) => {
    const order = availableOrders.find(o => o.id === orderId);
    const availableQty = order.quantity - (order.shipped_quantity || 0);
    const newQty = Math.max(0, Math.min(availableQty, Number(value) || 0));
    setShipmentItems(prev => ({ ...prev, [orderId]: newQty }));
  };

  const handleBreakdownChange = (orderId, value) => {
    setBreakdownSelections(prev => ({ ...prev, [orderId]: value }));
  };

  const handleSubmit = async () => {
    const itemsToShip = Object.entries(shipmentItems).filter(([_, qty]) => qty > 0);
    
    if (itemsToShip.length === 0) {
      toast.error("Please add at least one item to the shipment.");
      return;
    }

    setSubmitting(true);
    toast.info("Creating drop shipment...");

    try {
      const newShipment = await Shipment.create({
        shipment_id: `SHP-${Date.now()}`,
        member_id: user.id,
        status: "Pending",
        is_dropship: true,
        shipping_address: address,
      });

      const updatePromises = itemsToShip.map(([orderId, quantity]) => {
        const order = availableOrders.find(o => o.id === orderId);
        const newShippedQuantity = (order.shipped_quantity || 0) + quantity;
        const newStatus = newShippedQuantity >= order.quantity ? "Complete" : "In Inventory";
        
        return Promise.all([
          ShipmentItem.create({
            shipment_id: newShipment.id,
            order_id: orderId,
            product_name: order.product_name,
            quantity: quantity,
            breakdown: breakdownSelections[orderId] || 'No',
          }),
          Order.update(orderId, {
            shipped_quantity: newShippedQuantity,
            status: newStatus
          })
        ]);
      });

      await Promise.all(updatePromises.flat());

      toast.success("Drop shipment created successfully!");
      onShipmentCreated();
      onClose();

    } catch (error) {
      console.error("Shipment creation error:", error);
      toast.error("Failed to create shipment.");
    } finally {
      setSubmitting(false);
    }
  };

  const handleAddressChange = (e) => {
    const { id, value } = e.target;
    setAddress(prev => ({ ...prev, [id]: value }));
  };

  const filteredAvailableOrders = availableOrders.filter(order => 
    order.product_name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle>Create New Drop Shipment</DialogTitle>
          <DialogDescription>
            {currentStep === 1 
              ? "Enter the destination address for this shipment."
              : "Select items from your inventory to include."
            }
          </DialogDescription>
        </DialogHeader>

        {currentStep === 1 && (
            <div className="space-y-4 py-4">
                <div>
                    <Label htmlFor="name">Recipient Name</Label>
                    <Input id="name" value={address.name} onChange={handleAddressChange} />
                </div>
                <div>
                    <Label htmlFor="street">Street Address</Label>
                    <Input id="street" value={address.street} onChange={handleAddressChange} />
                </div>
                <div>
                    <Label htmlFor="suite">Apartment, suite, etc. (optional)</Label>
                    <Input id="suite" value={address.suite} onChange={handleAddressChange} />
                </div>
                <div className="grid grid-cols-3 gap-4">
                    <div>
                        <Label htmlFor="city">City</Label>
                        <Input id="city" value={address.city} onChange={handleAddressChange} />
                    </div>
                    <div>
                        <Label htmlFor="state">State</Label>
                         <Select value={address.state} onValueChange={(value) => setAddress(p => ({...p, state: value}))}>
                            <SelectTrigger id="state">
                                <SelectValue placeholder="Select state" />
                            </SelectTrigger>
                            <SelectContent>
                                {US_STATES.map(s => <SelectItem key={s.abbreviation} value={s.abbreviation}>{s.name}</SelectItem>)}
                            </SelectContent>
                        </Select>
                    </div>
                    <div>
                        <Label htmlFor="zip">ZIP Code</Label>
                        <Input id="zip" value={address.zip} onChange={handleAddressChange} />
                    </div>
                </div>
            </div>
        )}

        {currentStep === 2 && (
            <>
                <div className="relative my-4">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
                  <Input
                    placeholder="Search available products..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9"
                    disabled={loading}
                  />
                </div>
                
                <div className="max-h-[50vh] overflow-y-auto pr-4">
                  {loading ? (
                    <div className="flex justify-center items-center h-48"><Loader2 className="w-8 h-8 animate-spin"/></div>
                  ) : filteredAvailableOrders.length > 0 ? (
                    <TooltipProvider>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Product</TableHead>
                            <TableHead className="text-center">Available</TableHead>
                            <TableHead className="w-32 text-center">Qty to Ship</TableHead>
                            <TableHead className="w-48 text-center">Breakdown</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredAvailableOrders.map(order => {
                            const availableQty = order.quantity - (order.shipped_quantity || 0);
                            return (
                              <TableRow key={order.id}>
                                <TableCell>{order.product_name}</TableCell>
                                <TableCell className="text-center">{availableQty}</TableCell>
                                <TableCell>
                                  <Input type="number" className="w-24 text-center" value={shipmentItems[order.id] || ""} onChange={(e) => handleQuantityChange(order.id, e.target.value)} placeholder="0" max={availableQty} min={0} />
                                </TableCell>
                                <TableCell>
                                  <Select value={breakdownSelections[order.id] || 'No'} onValueChange={(value) => handleBreakdownChange(order.id, value)}>
                                    <SelectTrigger><SelectValue /></SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="No">No</SelectItem>
                                      <SelectItem value="To Each">To Each</SelectItem>
                                      <SelectItem value="Fully">Fully</SelectItem>
                                    </SelectContent>
                                  </Select>
                                </TableCell>
                              </TableRow>
                            )
                          })}
                        </TableBody>
                      </Table>
                    </TooltipProvider>
                  ) : (
                    <div className="text-center py-12"><p>No items available in inventory.</p></div>
                  )}
                </div>
            </>
        )}

        <DialogFooter>
            {currentStep === 1 ? (
                <>
                  <Button variant="outline" onClick={onClose}>Cancel</Button>
                  <Button onClick={handleNextStep}>Next</Button>
                </>
            ) : (
                <>
                  <Button variant="outline" onClick={() => setCurrentStep(1)} disabled={submitting}>Back to Address</Button>
                  <Button onClick={handleSubmit} disabled={loading || submitting}>
                    {submitting ? <Loader2 className="w-4 h-4 animate-spin mr-2"/> : <Truck className="w-4 h-4 mr-2" />}
                    Create Shipment
                  </Button>
                </>
            )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}