
import React, { useState, useEffect } from "react";
import { Order } from "@/api/entities";
import { User } from "@/api/entities";
import { Shipment } from "@/api/entities";
import { ShipmentItem } from "@/api/entities";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Loader2, Truck, PackageCheck, Search, Info } from "lucide-react";
import { toast } from "sonner";

export default function CreateShipmentModal({ isOpen, onClose, onShipmentCreated }) {
  const [availableOrders, setAvailableOrders] = useState([]);
  const [shipmentItems, setShipmentItems] = useState({}); // { orderId: quantity }
  const [breakdownSelections, setBreakdownSelections] = useState({}); // { orderId: 'No' | 'To Each' | 'Fully' }
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [user, setUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    if (isOpen) {
      loadAvailableOrders();
      setSearchTerm(""); // Reset search on open
      setShipmentItems({}); // Reset selections on open
      setBreakdownSelections({}); // Reset breakdowns on open
    }
  }, [isOpen]);

  const loadAvailableOrders = async () => {
    setLoading(true);
    try {
      const userData = await User.me();
      setUser(userData);
      const orders = await Order.filter({
        member_id: userData.id,
        status: "In Inventory"
      });
      // Filter out orders that are fully shipped
      const available = orders.filter(o => (o.quantity - (o.shipped_quantity || 0)) > 0);
      setAvailableOrders(available);
    } catch (error) {
      toast.error("Failed to load available items.");
    } finally {
      setLoading(false);
    }
  };

  const handleQuantityChange = (orderId, value) => {
    const order = availableOrders.find(o => o.id === orderId);
    const availableQty = order.quantity - (order.shipped_quantity || 0);
    const newQty = Math.max(0, Math.min(availableQty, Number(value) || 0));
    setShipmentItems(prev => ({ ...prev, [orderId]: newQty }));
  };

  const handleBreakdownChange = (orderId, value) => {
    setBreakdownSelections(prev => ({ ...prev, [orderId]: value }));
  };

  const handleSubmit = async () => {
    const itemsToShip = Object.entries(shipmentItems).filter(([_, qty]) => qty > 0);
    
    if (itemsToShip.length === 0) {
      toast.error("Please add at least one item to the shipment.");
      return;
    }

    setSubmitting(true);
    toast.info("Creating shipment...");

    try {
      // 1. Create Shipment
      const newShipment = await Shipment.create({
        shipment_id: `SHP-${Date.now()}`,
        member_id: user.id,
        status: "Pending",
      });

      // 2. Create ShipmentItems and Update Orders
      const updatePromises = itemsToShip.map(([orderId, quantity]) => {
        const order = availableOrders.find(o => o.id === orderId);
        const newShippedQuantity = (order.shipped_quantity || 0) + quantity;
        
        // Determine new status - if fully shipped, mark as Complete
        const newStatus = newShippedQuantity >= order.quantity ? "Complete" : "In Inventory";
        
        return Promise.all([
          ShipmentItem.create({
            shipment_id: newShipment.id,
            order_id: orderId,
            product_name: order.product_name,
            quantity: quantity,
            breakdown: breakdownSelections[orderId] || 'No',
          }),
          Order.update(orderId, {
            shipped_quantity: newShippedQuantity,
            status: newStatus
          })
        ]);
      });

      await Promise.all(updatePromises);

      toast.success("Shipment created successfully!");
      onShipmentCreated();
      onClose();

    } catch (error) {
      console.error("Shipment creation error:", error);
      toast.error("Failed to create shipment.");
    } finally {
      setSubmitting(false);
    }
  };

  const filteredAvailableOrders = availableOrders.filter(order => 
    order.product_name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle>Create New Shipment</DialogTitle>
          <DialogDescription>
            Select items from your inventory to include in this shipment.
          </DialogDescription>
        </DialogHeader>

        <div className="relative my-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
          <Input
            placeholder="Search available products..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9"
            disabled={loading}
          />
        </div>
        
        <div className="max-h-[50vh] overflow-y-auto pr-4">
          {loading ? (
            <div className="flex justify-center items-center h-48"><Loader2 className="w-8 h-8 animate-spin"/></div>
          ) : availableOrders.length === 0 ? (
             <div className="text-center py-12">
              <PackageCheck className="w-12 h-12 text-slate-300 mx-auto mb-4" />
              <h3 className="font-semibold text-slate-800">No Items Available</h3>
              <p className="text-slate-500 text-sm">You have no orders with an "In Inventory" status.</p>
            </div>
          ) : filteredAvailableOrders.length > 0 ? (
            <TooltipProvider>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Product</TableHead>
                    <TableHead className="text-center">Available</TableHead>
                    <TableHead className="w-32 text-center">Qty to Ship</TableHead>
                    <TableHead className="w-48 text-center">
                      <div className="flex items-center justify-center gap-2">
                        Breakdown
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Info className="w-4 h-4 text-slate-400 cursor-help" />
                          </TooltipTrigger>
                          <TooltipContent className="max-w-sm">
                            <div className="space-y-2 text-sm text-left font-normal">
                              <div><span className="font-medium">No:</span> No breakdown, will ship as sold</div>
                              <div><span className="font-medium">To Each:</span> Broken down to each unit (i.e. booster cases down to booster boxes)</div>
                              <div><span className="font-medium">Fully:</span> Broken down to smallest saleable unit size (i.e. ETBs down to packs, Commander decks down to the shrink wrapped bricks)</div>
                            </div>
                          </TooltipContent>
                        </Tooltip>
                      </div>
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAvailableOrders.map(order => {
                    const availableQty = order.quantity - (order.shipped_quantity || 0);
                    return (
                      <TableRow key={order.id}>
                        <TableCell>{order.product_name}</TableCell>
                        <TableCell className="text-center">{availableQty}</TableCell>
                        <TableCell>
                          <div className="flex items-center justify-center gap-2">
                            <Input
                              type="number"
                              className="w-24 text-center"
                              value={shipmentItems[order.id] || ""}
                              onChange={(e) => handleQuantityChange(order.id, e.target.value)}
                              placeholder="0"
                              max={availableQty}
                              min={0}
                            />
                          </div>
                        </TableCell>
                        <TableCell>
                          <Select
                            value={breakdownSelections[order.id] || 'No'}
                            onValueChange={(value) => handleBreakdownChange(order.id, value)}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Select" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="No">No</SelectItem>
                              <SelectItem value="To Each">To Each</SelectItem>
                              <SelectItem value="Fully">Fully</SelectItem>
                            </SelectContent>
                          </Select>
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </TooltipProvider>
          ) : (
            <div className="text-center py-12">
              <Search className="w-12 h-12 text-slate-300 mx-auto mb-4" />
              <h3 className="font-semibold text-slate-800">No Matches Found</h3>
              <p className="text-slate-500 text-sm">No products in your inventory match your search.</p>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={submitting}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={loading || submitting || availableOrders.length === 0}>
            {submitting ? <Loader2 className="w-4 h-4 animate-spin mr-2"/> : <Truck className="w-4 h-4 mr-2" />}
            Create Shipment
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
