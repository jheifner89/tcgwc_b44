import { Message } from "@/api/entities";

/**
 * Creates a new message for a specific user.
 * @param {object} params - The message parameters.
 * @param {string} params.userId - The ID of the user to receive the message.
 * @param {string} params.title - The title of the message.
 * @param {string} params.content - The body content of the message.
 */
export const createMessage = async ({ userId, title, content }) => {
  try {
    await Message.create({
      user_id: userId,
      title,
      content
    });
    return { success: true };
  } catch (error) {
    console.error("Failed to create message:", error);
    return { success: false, error };
  }
};