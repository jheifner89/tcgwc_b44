
import React from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Trash2, X, CheckCircle } from "lucide-react";

export default function ConfirmationDialog({
  open,
  onOpenChange,
  title,
  description,
  confirmText = "Confirm",
  cancelText = "Cancel",
  onConfirm,
  variant = "default", // "destructive" or "default"
  icon: CustomIcon
}) {
  const handleConfirm = () => {
    if (onConfirm) {
      onConfirm();
    }
    onOpenChange(false);
  };

  const IconComponent = CustomIcon || (variant === "destructive" ? Trash2 : AlertTriangle);
  const iconColor = variant === "destructive" ? "text-red-500" : "text-slate-500";
  const iconBgColor = variant === "destructive" ? "bg-red-50" : "bg-slate-50";
  const buttonClass = variant === "destructive" ? "bg-red-600 hover:bg-red-700" : "bg-slate-900 hover:bg-slate-800";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <div className="flex items-center gap-4">
            <div className={`w-12 h-12 rounded-full ${iconBgColor} flex items-center justify-center`}>
              <IconComponent className={`w-6 h-6 ${iconColor}`} />
            </div>
            <div className="flex-1">
              <DialogTitle className="text-lg font-semibold text-slate-900">
                {title}
              </DialogTitle>
              <DialogDescription className="text-sm text-slate-600 mt-1">
                {description}
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>
        <DialogFooter className="flex gap-2 sm:gap-2">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="flex-1"
          >
            <X className="w-4 h-4 mr-2" />
            {cancelText}
          </Button>
          <Button
            onClick={handleConfirm}
            className={`flex-1 text-white ${buttonClass}`}
          >
            <IconComponent className="w-4 h-4 mr-2" />
            {confirmText}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
