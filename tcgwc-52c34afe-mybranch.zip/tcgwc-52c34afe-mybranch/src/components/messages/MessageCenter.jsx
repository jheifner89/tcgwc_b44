import React, { useState, useEffect } from "react";
import { Message } from "@/api/entities";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bell, Check, MailOpen } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { toast } from "sonner";

export default function MessageCenter({ userId }) {
  const [messages, setMessages] = useState([]);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    if (userId) {
      loadMessages();
    }
    const interval = setInterval(() => {
      if (userId) loadMessages();
    }, 60000);
    return () => clearInterval(interval);
  }, [userId]);

  const loadMessages = async () => {
    if (!userId) return;
    try {
      const allMessages = await Message.filter({ user_id: userId }, "-created_date", 10);
      setMessages(allMessages);
    } catch (error) {
      console.error("Failed to load messages:", error);
    }
  };

  const markAsReadAndDelete = async (messageId) => {
    try {
      await Message.delete(messageId);
      await loadMessages();
      toast.success("Message marked as read.");
    } catch (error) {
      console.error("Failed to delete message:", error);
      toast.error("Failed to mark message as read.");
    }
  };

  const handleMarkAllRead = async () => {
    if (messages.length === 0) return;

    const deletePromises = messages.map(msg => Message.delete(msg.id));

    try {
      await Promise.all(deletePromises);
      await loadMessages();
      toast.success("All messages marked as read.");
    } catch (error) {
      console.error("Failed to mark all messages as read:", error);
      toast.error("Could not mark all as read.");
    }
  };

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" size="icon" className="relative">
          <Bell className="w-5 h-5" />
          {messages.length > 0 && (
            <Badge className="absolute -top-2 -right-2 px-1.5 py-0.5 text-xs bg-red-500 text-white">
              {messages.length}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0" align="end">
        <div className="p-4 border-b flex justify-between items-center">
          <div>
            <h3 className="font-semibold text-slate-900">Notifications</h3>
            <p className="text-sm text-slate-500">{messages.length} new messages</p>
          </div>
          {messages.length > 0 && (
            <Button 
              variant="link" 
              size="sm" 
              className="p-0 h-auto text-sm"
              onClick={handleMarkAllRead}
            >
              Mark all as read
            </Button>
          )}
        </div>
        <div className="max-h-80 overflow-y-auto">
          {messages.length === 0 ? (
            <div className="p-4 text-center">
              <MailOpen className="w-8 h-8 text-slate-300 mx-auto mb-2" />
              <p className="text-sm text-slate-500">No new messages</p>
            </div>
          ) : (
            messages.map((message) => (
              <div key={message.id} className="p-4 border-b border-slate-100 last:border-b-0 hover:bg-slate-50">
                <h4 className="font-medium text-sm text-slate-900 mb-1">{message.title}</h4>
                <p className="text-sm text-slate-600 mb-2">{message.content}</p>
                <div className="flex justify-between items-center">
                  <p className="text-xs text-slate-400">
                    {formatDistanceToNow(Date.parse(message.created_date), { addSuffix: true })}
                  </p>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-auto px-2 py-1 text-green-600 hover:text-green-700 hover:bg-green-50"
                    onClick={() => markAsReadAndDelete(message.id)}
                    title="Mark as read"
                  >
                    <Check className="w-4 h-4 mr-1" />
                    Mark as read
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}