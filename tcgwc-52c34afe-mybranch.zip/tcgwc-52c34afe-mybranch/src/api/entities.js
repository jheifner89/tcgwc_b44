import { base44 } from './base44Client';


export const Product = base44.entities.Product;

export const Request = base44.entities.Request;

export const Invoice = base44.entities.Invoice;

export const InvoiceLineItem = base44.entities.InvoiceLineItem;

export const Order = base44.entities.Order;

export const Message = base44.entities.Message;

export const Shipment = base44.entities.Shipment;

export const ShipmentItem = base44.entities.ShipmentItem;

export const Settings = base44.entities.Settings;



// auth sdk:
export const User = base44.auth;